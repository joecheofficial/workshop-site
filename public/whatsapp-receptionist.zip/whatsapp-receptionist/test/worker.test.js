import { test, afterEach } from "node:test";
import assert from "node:assert/strict";
import worker from "../src/index.js";
import {
  makeEnv,
  makeCtx,
  inboundPayload,
  postRequest,
  installFetch,
  claudeMessage,
  VERIFY_TOKEN,
  PHONE_ID,
  OWNER,
  CUSTOMER,
} from "./helpers.js";

let calls;
afterEach(() => calls?.restore());

async function deliver(env, payload, opts) {
  const ctx = makeCtx();
  const res = await worker.fetch(postRequest(payload, opts), env, ctx);
  await ctx.drain();
  return res;
}

const lastUserContent = (body) => body.messages[body.messages.length - 1].content;

// ---------- webhook verification ----------

test("GET /webhook with the right verify token echoes hub.challenge", async () => {
  const env = makeEnv();
  const url = `https://bot.example.workers.dev/webhook?hub.mode=subscribe&hub.verify_token=${VERIFY_TOKEN}&hub.challenge=1158201444`;
  const res = await worker.fetch(new Request(url), env, makeCtx());
  assert.equal(res.status, 200);
  assert.equal(await res.text(), "1158201444");
});

test("GET /webhook with a wrong verify token is refused", async () => {
  const env = makeEnv();
  const url = "https://bot.example.workers.dev/webhook?hub.mode=subscribe&hub.verify_token=nope&hub.challenge=42";
  const res = await worker.fetch(new Request(url), env, makeCtx());
  assert.equal(res.status, 403);
});

// ---------- signature ----------

test("POST with a valid signature: replies via Graph API using Claude's answer", async () => {
  calls = installFetch({ claude: () => claudeMessage([{ type: "text", text: "Hi Sara, I'm the AI assistant for Sunrise Coaching. How can I help?" }]) });
  const env = makeEnv();
  const res = await deliver(env, inboundPayload({ text: "Hi there" }));
  assert.equal(res.status, 200);
  assert.equal(await res.text(), "EVENT_RECEIVED");

  assert.equal(calls.claude.length, 1);
  const c = calls.claude[0];
  assert.equal(c.headers.get("x-api-key"), "sk-ant-test");
  assert.ok(c.headers.get("anthropic-version"));
  assert.equal(c.body.model, "claude-haiku-5-5");
  assert.deepEqual(c.body.output_config, { effort: "low" });
  assert.match(c.body.system, /Sunrise Coaching/);
  assert.equal(lastUserContent(c.body), "Hi there");

  const sent = calls.sent();
  assert.equal(sent.length, 1);
  assert.equal(sent[0].url, `https://graph.facebook.com/v25.0/${PHONE_ID}/messages`);
  assert.equal(sent[0].headers.get("authorization"), "Bearer EAATESTTOKEN");
  assert.equal(sent[0].body.messaging_product, "whatsapp");
  assert.equal(sent[0].body.to, CUSTOMER);
  assert.equal(sent[0].body.type, "text");
  assert.match(sent[0].body.text.body, /AI assistant/);

  // mark-as-read + typing indicator sent first
  const read = calls.graph.find((g) => g.body?.status === "read");
  assert.equal(read.body.message_id, "wamid.TEST1");
});

test("POST with a bad signature is rejected and nothing is called", async () => {
  calls = installFetch();
  const env = makeEnv();
  const res = await deliver(env, inboundPayload(), { signature: "sha256=" + "0".repeat(64) });
  assert.equal(res.status, 401);
  assert.equal(calls.claude.length + calls.graph.length, 0);
});

test("POST with no signature header, or a body changed after signing, is rejected", async () => {
  calls = installFetch();
  const env = makeEnv();
  assert.equal((await deliver(env, inboundPayload(), { signature: null })).status, 401);
  const original = JSON.stringify(inboundPayload({ text: "Hi" }));
  const tampered = original.replace('"Hi"', '"Book me for free"');
  const res = await worker.fetch(postRequest(null, { raw: tampered, signature: (await import("./helpers.js")).sign(original) }), env, makeCtx());
  assert.equal(res.status, 401);
  assert.equal(calls.claude.length + calls.graph.length, 0);
});

// ---------- duplicates and 24h window ----------

test("the same webhook delivered twice is answered only once", async () => {
  calls = installFetch();
  const env = makeEnv();
  const payload = inboundPayload({ id: "wamid.DUP" });
  assert.equal((await deliver(env, payload)).status, 200);
  assert.equal((await deliver(env, payload)).status, 200);
  assert.equal(calls.claude.length, 1);
  assert.equal(calls.sent().length, 1);
});

test("a message older than 24 hours is not answered (would need a template)", async () => {
  calls = installFetch();
  const env = makeEnv();
  const old = Math.floor(Date.now() / 1000) - 25 * 3600;
  await deliver(env, inboundPayload({ id: "wamid.OLD", ts: old }));
  assert.equal(calls.claude.length, 0);
  assert.equal(calls.sent().length, 0);
});

test("status updates (delivered/read) are ignored", async () => {
  calls = installFetch();
  const env = makeEnv();
  const payload = inboundPayload();
  delete payload.entry[0].changes[0].value.messages;
  payload.entry[0].changes[0].value.statuses = [{ id: "wamid.X", status: "delivered" }];
  const res = await deliver(env, payload);
  assert.equal(res.status, 200);
  assert.equal(calls.claude.length + calls.graph.length, 0);
});

// ---------- booking conversation ----------

function seedSlots(env) {
  env.STORE.map.set(
    "slots",
    JSON.stringify([
      { id: "20200101-1000", start: "2020-01-01 10:00", booked_by: null }, // in the past, must never be offered
      { id: "20990106-1000", start: "2099-01-06 10:00", booked_by: null },
      { id: "20990106-1400", start: "2099-01-06 14:00", booked_by: null },
    ]),
  );
}

test("booking conversation: lists open slots, books one, remembers context, tells the owner", async () => {
  let offered;
  calls = installFetch({
    claude: (body, i) => {
      const last = lastUserContent(body);
      if (i === 0) {
        assert.equal(last, "Hi, can I book a session?");
        return claudeMessage([{ type: "tool_use", id: "tu_1", name: "get_open_slots", input: {} }], "tool_use");
      }
      if (i === 1) {
        assert.equal(last[0].type, "tool_result");
        assert.equal(last[0].tool_use_id, "tu_1");
        offered = JSON.parse(last[0].content).open_slots;
        return claudeMessage([{ type: "text", text: `Hi, I'm the AI assistant. Open: ${offered.map((s) => s.time).join(" or ")}. Which suits you, and what's your name?` }]);
      }
      if (i === 2) {
        // second customer message: earlier turns must be in the history
        assert.equal(body.messages[0].content, "Hi, can I book a session?");
        assert.equal(body.messages[1].role, "assistant");
        assert.equal(last, "The 10:00 one please, I'm Sara");
        return claudeMessage([{ type: "tool_use", id: "tu_2", name: "book_slot", input: { slot_id: "20990106-1000", customer_name: "Sara" } }], "tool_use");
      }
      if (i === 3) {
        const result = JSON.parse(last[0].content);
        assert.equal(result.ok, true);
        return claudeMessage([{ type: "text", text: `You're booked, Sara: ${result.booked}.` }]);
      }
      throw new Error("unexpected Claude call " + i);
    },
  });
  const env = makeEnv();
  seedSlots(env);
  env.STORE.map.set("owner:last", String(Date.now() - 60_000)); // owner wrote 1 minute ago

  await deliver(env, inboundPayload({ id: "wamid.B1", text: "Hi, can I book a session?" }));
  assert.equal(offered.length, 2, "past slot must not be offered");
  assert.ok(offered.every((s) => !s.slot_id.startsWith("2020")));

  await deliver(env, inboundPayload({ id: "wamid.B2", text: "The 10:00 one please, I'm Sara" }));

  const slots = JSON.parse(env.STORE.map.get("slots"));
  const booked = slots.find((s) => s.id === "20990106-1000");
  assert.equal(booked.booked_by.name, "Sara");
  assert.equal(booked.booked_by.wa_id, CUSTOMER);

  const sent = calls.sent();
  assert.equal(sent.length, 3); // offer, confirmation, owner note
  assert.match(sent[1].body.text.body, /booked, Sara: Tue 6 Jan, 10:00-11:00/);
  assert.equal(sent[2].body.to, OWNER);
  assert.match(sent[2].body.text.body, /New booking: Sara/);
});

test("owner is NOT messaged about a booking when their 24h window is closed", async () => {
  calls = installFetch({
    claude: (body, i) =>
      i === 0
        ? claudeMessage([{ type: "tool_use", id: "t", name: "book_slot", input: { slot_id: "20990106-1400", customer_name: "Ana" } }], "tool_use")
        : claudeMessage([{ type: "text", text: "Booked." }]),
  });
  const env = makeEnv();
  seedSlots(env);
  await deliver(env, inboundPayload({ id: "wamid.C1", text: "Yes book 14:00, Ana" }));
  const sent = calls.sent();
  assert.equal(sent.length, 1);
  assert.equal(sent[0].body.to, CUSTOMER);
});

test("a slot that is already booked cannot be booked twice", async () => {
  let toolResult;
  calls = installFetch({
    claude: (body, i) => {
      if (i === 0) return claudeMessage([{ type: "tool_use", id: "t", name: "book_slot", input: { slot_id: "20990106-1000", customer_name: "Bob" } }], "tool_use");
      toolResult = JSON.parse(lastUserContent(body)[0].content);
      return claudeMessage([{ type: "text", text: "Sorry, that time was just taken." }]);
    },
  });
  const env = makeEnv();
  seedSlots(env);
  const slots = JSON.parse(env.STORE.map.get("slots"));
  slots[1].booked_by = { wa_id: "999", name: "Someone" };
  env.STORE.map.set("slots", JSON.stringify(slots));
  await deliver(env, inboundPayload({ id: "wamid.D1", text: "10:00 please" }));
  assert.equal(toolResult.ok, false);
  assert.equal(JSON.parse(env.STORE.map.get("slots"))[1].booked_by.name, "Someone");
});

// ---------- errors and edge cases ----------

test("if the Claude API fails, the customer still gets a polite fallback reply", async () => {
  calls = installFetch({ claude: () => ({ __status: 500 }) });
  const env = makeEnv();
  await deliver(env, inboundPayload({ id: "wamid.E1" }));
  const sent = calls.sent();
  assert.equal(sent.length, 1);
  assert.match(sent[0].body.text.body, /technical problem/);
});

test("a refusal from Claude becomes a safe hand-off reply", async () => {
  calls = installFetch({ claude: () => claudeMessage([], "refusal") });
  const env = makeEnv();
  await deliver(env, inboundPayload({ id: "wamid.R1" }));
  assert.match(calls.sent()[0].body.text.body, /owner will get back to you/);
});

test("a WhatsApp send error (number not in test allow-list) is logged, not thrown", async () => {
  calls = installFetch({ graphStatus: 400, graphBody: { error: { code: 131030, message: "Recipient phone number not in allowed list" } } });
  const env = makeEnv();
  const res = await deliver(env, inboundPayload({ id: "wamid.F1" }));
  assert.equal(res.status, 200);
  assert.equal(calls.sent().length, 1);
});

test("images and voice notes get a short text-only reply without calling Claude", async () => {
  calls = installFetch();
  const env = makeEnv();
  await deliver(env, inboundPayload({ id: "wamid.I1", type: "image" }));
  assert.equal(calls.claude.length, 0);
  assert.match(calls.sent()[0].body.text.body, /only read text/);
});

test("STOP opts a person out, later messages are ignored, START opts back in", async () => {
  calls = installFetch();
  const env = makeEnv();
  await deliver(env, inboundPayload({ id: "wamid.S1", text: "stop" }));
  assert.match(calls.sent()[0].body.text.body, /will not get more messages/);
  await deliver(env, inboundPayload({ id: "wamid.S2", text: "hello?" }));
  assert.equal(calls.sent().length, 1);
  assert.equal(calls.claude.length, 0);
  await deliver(env, inboundPayload({ id: "wamid.S3", text: "START" }));
  assert.equal(calls.claude.length, 1);
  assert.equal(calls.sent().length, 2);
});

test("owner manages slots from WhatsApp: /add, /slots, /remove, /bookings", async () => {
  calls = installFetch();
  const env = makeEnv();
  await deliver(env, inboundPayload({ id: "wamid.O1", from: OWNER, text: "/add 2099-02-03 09:00, 2099-02-03 11:00, 2099-13-40 10:00" }));
  assert.match(calls.sent()[0].body.text.body, /Could not read: 2099-13-40 10:00/);
  await deliver(env, inboundPayload({ id: "wamid.O2", from: OWNER, text: "/add 2099-02-03 09:00, 2099-02-03 11:00" }));
  assert.match(calls.sent()[1].body.text.body, /Added 2 times/);
  await deliver(env, inboundPayload({ id: "wamid.O3", from: OWNER, text: "/slots" }));
  assert.match(calls.sent()[2].body.text.body, /Tue 3 Feb, 09:00-10:00  open/);
  await deliver(env, inboundPayload({ id: "wamid.O4", from: OWNER, text: "/remove 2099-02-03 09:00" }));
  assert.match(calls.sent()[3].body.text.body, /Removed Tue 3 Feb, 09:00-10:00/);
  await deliver(env, inboundPayload({ id: "wamid.O5", from: OWNER, text: "/bookings" }));
  assert.match(calls.sent()[4].body.text.body, /No upcoming bookings/);
  assert.equal(calls.claude.length, 0, "owner commands never cost Claude tokens");
  assert.equal(JSON.parse(env.STORE.map.get("slots")).length, 1);
});

test("/health lists missing settings by name only", async () => {
  const env = makeEnv({ ANTHROPIC_API_KEY: "", WHATSAPP_PHONE_NUMBER_ID: "REPLACE_WITH_PHONE_NUMBER_ID" });
  const res = await worker.fetch(new Request("https://bot.example.workers.dev/health"), env, makeCtx());
  const json = await res.json();
  assert.equal(json.ok, false);
  assert.deepEqual(json.missing, ["WHATSAPP_PHONE_NUMBER_ID", "ANTHROPIC_API_KEY"]);
});

test("KV writes per normal customer message stay at 2 (free plan budget)", async () => {
  calls = installFetch();
  const env = makeEnv();
  await deliver(env, inboundPayload({ id: "wamid.K1" }));
  assert.equal(env.STORE.writes, 2);
});
