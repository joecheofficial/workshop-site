// Local stand-in for api.anthropic.com and graph.facebook.com, used only by test/e2e-local.sh.
// Nothing here talks to the internet.
import http from "node:http";

const port = Number(process.argv[2] || 8798);
const log = [];

function claudeReply(body) {
  const last = body.messages[body.messages.length - 1];
  const msg = (content, stop_reason = "end_turn") => ({
    id: "msg_mock",
    type: "message",
    role: "assistant",
    model: body.model,
    content,
    stop_reason,
    stop_sequence: null,
    usage: { input_tokens: 50, output_tokens: 10 },
  });
  if (Array.isArray(last.content) && last.content[0]?.type === "tool_result") {
    const r = JSON.parse(last.content[0].content);
    if (r.open_slots) return msg([{ type: "text", text: `I'm the AI assistant. Open: ${r.open_slots.map((s) => s.time).join(", ")}. Which one, and your name?` }]);
    if (r.booked) return msg([{ type: "text", text: `Booked: ${r.booked}.` }]);
    return msg([{ type: "text", text: "Hmm: " + JSON.stringify(r) }]);
  }
  const text = String(last.content).toLowerCase();
  if (text.includes("book")) return msg([{ type: "tool_use", id: "tu_a", name: "get_open_slots", input: {} }], "tool_use");
  if (text.includes("yes")) {
    return msg([{ type: "tool_use", id: "tu_b", name: "book_slot", input: { slot_id: "20990106-1000", customer_name: "Sara" } }], "tool_use");
  }
  return msg([{ type: "text", text: "Hello from mock Claude." }]);
}

http
  .createServer(async (req, res) => {
    let raw = "";
    for await (const chunk of req) raw += chunk;
    if (req.method === "GET" && req.url === "/log") {
      res.writeHead(200, { "content-type": "application/json" });
      return res.end(JSON.stringify(log, null, 2));
    }
    const body = raw ? JSON.parse(raw) : null;
    if (req.url.startsWith("/v1/messages")) {
      log.push({ to: "anthropic", model: body.model, apiKeyPresent: Boolean(req.headers["x-api-key"]), version: req.headers["anthropic-version"], lastUser: body.messages.at(-1).content });
      res.writeHead(200, { "content-type": "application/json", "request-id": "req_mock" });
      return res.end(JSON.stringify(claudeReply(body)));
    }
    if (req.url.includes("/messages")) {
      log.push({ to: "meta", path: req.url, auth: req.headers.authorization?.slice(0, 12), body });
      res.writeHead(200, { "content-type": "application/json" });
      return res.end(JSON.stringify(body.status === "read" ? { success: true } : { messaging_product: "whatsapp", messages: [{ id: "wamid.MOCK" + log.length }] }));
    }
    res.writeHead(404);
    res.end();
  })
  .listen(port, "127.0.0.1", () => console.log(`mock listening on ${port}`));
