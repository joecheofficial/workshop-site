// Test helpers: fake KV, fake ctx, fake Meta + Anthropic HTTP. No network is used.
import { createHmac } from "node:crypto";

export const APP_SECRET = "test-app-secret";
export const VERIFY_TOKEN = "verify-me-123";
export const PHONE_ID = "1112223334445";
export const OWNER = "6281111111111";
export const CUSTOMER = "15551234567";

export function makeKV() {
  const map = new Map();
  return {
    map,
    writes: 0,
    async get(key, type) {
      if (!map.has(key)) return null;
      const v = map.get(key);
      return type === "json" ? JSON.parse(v) : v;
    },
    async put(key, value) {
      this.writes++;
      map.set(key, String(value));
    },
    async delete(key) {
      map.delete(key);
    },
  };
}

export function makeEnv(overrides = {}) {
  return {
    WHATSAPP_TOKEN: "EAATESTTOKEN",
    WHATSAPP_APP_SECRET: APP_SECRET,
    WHATSAPP_VERIFY_TOKEN: VERIFY_TOKEN,
    WHATSAPP_PHONE_NUMBER_ID: PHONE_ID,
    ANTHROPIC_API_KEY: "sk-ant-test",
    GRAPH_VERSION: "v25.0",
    CLAUDE_MODEL: "claude-haiku-5-5",
    CLAUDE_EFFORT: "low",
    CLAUDE_MAX_RETRIES: "0",
    BUSINESS_NAME: "Sunrise Coaching",
    BUSINESS_TIMEZONE: "Asia/Makassar",
    BUSINESS_INFO: "1:1 coaching, 60 minutes, 150 USD, online.",
    SLOT_MINUTES: "60",
    OWNER_NUMBER: OWNER,
    BOOKING_LINK: "",
    STORE: makeKV(),
    ...overrides,
  };
}

export function makeCtx() {
  const pending = [];
  return {
    pending,
    waitUntil(p) {
      pending.push(p);
    },
    async drain() {
      await Promise.all(pending);
    },
  };
}

export function sign(body, secret = APP_SECRET) {
  return "sha256=" + createHmac("sha256", secret).update(body).digest("hex");
}

export function inboundPayload({ id = "wamid.TEST1", from = CUSTOMER, text = "Hi", name = "Sara", ts = Math.floor(Date.now() / 1000), type = "text" } = {}) {
  const msg = { from, id, timestamp: String(ts), type };
  if (type === "text") msg.text = { body: text };
  if (type === "image") msg.image = { id: "img1", mime_type: "image/jpeg" };
  return {
    object: "whatsapp_business_account",
    entry: [
      {
        id: "WABA_ID",
        changes: [
          {
            field: "messages",
            value: {
              messaging_product: "whatsapp",
              metadata: { display_phone_number: "15550000000", phone_number_id: PHONE_ID },
              contacts: [{ profile: { name }, wa_id: from }],
              messages: [msg],
            },
          },
        ],
      },
    ],
  };
}

export function postRequest(payload, { signature, raw } = {}) {
  const body = raw ?? JSON.stringify(payload);
  const headers = { "Content-Type": "application/json" };
  const sig = signature === undefined ? sign(body) : signature;
  if (sig !== null) headers["X-Hub-Signature-256"] = sig;
  return new Request("https://bot.example.workers.dev/webhook", { method: "POST", headers, body });
}

export function claudeMessage(content, stop_reason = "end_turn") {
  return {
    id: "msg_test_" + Math.random().toString(36).slice(2),
    type: "message",
    role: "assistant",
    model: "claude-haiku-5-5",
    content,
    stop_reason,
    stop_sequence: null,
    usage: { input_tokens: 100, output_tokens: 20 },
  };
}

// Installs a fake global fetch. `claude` is a function (requestBody, callIndex) -> response JSON
// (or { __status, __body } for an error). Records every call.
export function installFetch({ claude, graphStatus = 200, graphBody } = {}) {
  const calls = { claude: [], graph: [], other: [] };
  const original = globalThis.fetch;
  globalThis.fetch = async (input, init = {}) => {
    const url = typeof input === "string" ? input : input.url;
    const headers = new Headers(init.headers || (typeof input === "object" ? input.headers : undefined));
    const bodyText = init.body ? (typeof init.body === "string" ? init.body : await new Response(init.body).text()) : "";
    const body = bodyText ? JSON.parse(bodyText) : null;
    if (url.startsWith("https://api.anthropic.com/v1/messages")) {
      calls.claude.push({ url, headers, body });
      const out = claude ? await claude(body, calls.claude.length - 1) : claudeMessage([{ type: "text", text: "Hello!" }]);
      if (out && out.__status) {
        return new Response(JSON.stringify(out.__body || { type: "error", error: { type: "api_error", message: "boom" } }), {
          status: out.__status,
          headers: { "content-type": "application/json" },
        });
      }
      return new Response(JSON.stringify(out), { status: 200, headers: { "content-type": "application/json", "request-id": "req_test" } });
    }
    if (url.startsWith("https://graph.facebook.com/")) {
      calls.graph.push({ url, headers, body });
      if (body?.status === "read") return Response.json({ success: true });
      const status = graphStatus;
      const resBody = graphBody || { messaging_product: "whatsapp", contacts: [{ input: body?.to, wa_id: body?.to }], messages: [{ id: "wamid.OUT" + calls.graph.length }] };
      return new Response(JSON.stringify(resBody), { status, headers: { "content-type": "application/json" } });
    }
    calls.other.push({ url });
    return new Response("unexpected", { status: 599 });
  };
  calls.restore = () => {
    globalThis.fetch = original;
  };
  calls.sent = () => calls.graph.filter((c) => c.body?.type === "text");
  return calls;
}
