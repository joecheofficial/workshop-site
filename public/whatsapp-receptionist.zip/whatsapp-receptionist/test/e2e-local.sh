#!/usr/bin/env bash
# End-to-end test inside the real Workers runtime (wrangler dev, local mode).
# Claude and Meta are replaced by test/mock-server.mjs. No login, no deploy, no real messages.
set -euo pipefail
cd "$(dirname "$0")/.."

MOCK=8798
DEV=8799
SECRET=e2e-secret
OWNER=6281111111111
CUSTOMER=15551234567
OUT=$(mktemp -d)

cleanup() { kill "${MOCK_PID:-}" "${DEV_PID:-}" 2>/dev/null || true; rm -f .dev.vars.e2e; }
trap cleanup EXIT

node test/mock-server.mjs $MOCK >"$OUT/mock.log" 2>&1 &
MOCK_PID=$!

# Fresh local KV with two open slots (one in the past, one in the future).
rm -rf .wrangler/state
npx wrangler kv key put --binding STORE --local slots \
  '[{"id":"20200101-1000","start":"2020-01-01 10:00","booked_by":null},{"id":"20990106-1000","start":"2099-01-06 10:00","booked_by":null}]' >/dev/null

npx wrangler dev --port $DEV --ip 127.0.0.1 --env-file /dev/null \
  --var WHATSAPP_TOKEN:fake-token --var WHATSAPP_APP_SECRET:$SECRET --var WHATSAPP_VERIFY_TOKEN:v \
  --var ANTHROPIC_API_KEY:sk-ant-fake --var WHATSAPP_PHONE_NUMBER_ID:PHONEID \
  --var OWNER_NUMBER:$OWNER \
  --var ANTHROPIC_BASE_URL:http://127.0.0.1:$MOCK --var GRAPH_BASE_URL:http://127.0.0.1:$MOCK \
  >"$OUT/dev.log" 2>&1 &
DEV_PID=$!
for _ in $(seq 1 60); do curl -s -o /dev/null http://127.0.0.1:$DEV/health && break; sleep 1; done

post() { # id from text
  local ts body sig
  ts=$(date +%s)
  body=$(printf '{"object":"whatsapp_business_account","entry":[{"id":"W","changes":[{"field":"messages","value":{"messaging_product":"whatsapp","metadata":{"phone_number_id":"PHONEID"},"contacts":[{"profile":{"name":"Sara"},"wa_id":"%s"}],"messages":[{"from":"%s","id":"%s","timestamp":"%s","type":"text","text":{"body":"%s"}}]}}]}]}' "$2" "$2" "$1" "$ts" "$3")
  sig="sha256=$(printf '%s' "$body" | openssl dgst -sha256 -hmac "$SECRET" -hex | awk '{print $NF}')"
  curl -s -w " [HTTP %{http_code}]\n" -X POST -H "Content-Type: application/json" -H "X-Hub-Signature-256: $sig" --data-binary "$body" http://127.0.0.1:$DEV/webhook
  sleep 1.5
}

echo "health: $(curl -s http://127.0.0.1:$DEV/health)"
echo -n "owner says /add      -> "; post wamid.e1 $OWNER "/add 2099-01-07 15:00"
echo -n "customer: book       -> "; post wamid.e2 $CUSTOMER "Hi, I want to book a session"
echo -n "customer: yes        -> "; post wamid.e3 $CUSTOMER "yes the 6 Jan one, I am Sara"
echo -n "duplicate of e3      -> "; post wamid.e3 $CUSTOMER "yes the 6 Jan one, I am Sara"
echo -n "owner says /bookings -> "; post wamid.e4 $OWNER "/bookings"

echo "--- WhatsApp texts the Worker sent (via mock Meta) ---"
curl -s http://127.0.0.1:$MOCK/log | node -e '
  const log = JSON.parse(require("fs").readFileSync(0, "utf8"));
  for (const e of log) {
    if (e.to === "meta" && e.body.type === "text") console.log(`to ${e.body.to}: ${e.body.text.body.replace(/\n/g, " | ")}`);
  }
  const claude = log.filter((e) => e.to === "anthropic");
  console.log(`--- Claude calls: ${claude.length}, model ${claude[0]?.model}, key sent: ${claude.every((c) => c.apiKeyPresent)}, anthropic-version: ${claude[0]?.version}`);
  console.log(`--- mark-read calls: ${log.filter((e) => e.to === "meta" && e.body.status === "read").length}`);
'
echo "--- slots in local KV ---"
npx wrangler kv key get --binding STORE --local slots
