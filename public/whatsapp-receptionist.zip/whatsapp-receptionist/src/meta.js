// Talking to Meta's official WhatsApp Cloud API. No third-party tool in between.

const enc = new TextEncoder();

function hexToBytes(hex) {
  if (!/^[0-9a-f]+$/i.test(hex) || hex.length % 2 !== 0) return null;
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

// Meta signs every webhook POST with your App Secret:
//   X-Hub-Signature-256: sha256=<hex HMAC-SHA256 of the raw body>
// crypto.subtle.verify does a constant-time comparison for us.
export async function verifySignature(rawBody, header, appSecret) {
  if (!header || !appSecret || !header.startsWith("sha256=")) return false;
  const sig = hexToBytes(header.slice("sha256=".length));
  if (!sig) return false;
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(appSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"],
  );
  return crypto.subtle.verify("HMAC", key, sig, enc.encode(rawBody));
}

// Pull the customer messages out of a webhook payload.
// Status updates (sent, delivered, read) are ignored.
export function extractMessages(payload) {
  const found = [];
  if (!payload || payload.object !== "whatsapp_business_account") return found;
  for (const entry of payload.entry || []) {
    for (const change of entry.changes || []) {
      if (change.field !== "messages") continue;
      const value = change.value || {};
      const names = {};
      for (const c of value.contacts || []) names[c.wa_id] = c.profile?.name || "";
      for (const m of value.messages || []) {
        let text = null;
        if (m.type === "text") text = m.text?.body ?? "";
        else if (m.type === "button") text = m.button?.text ?? "";
        else if (m.type === "interactive") {
          text = m.interactive?.button_reply?.title ?? m.interactive?.list_reply?.title ?? null;
        }
        found.push({
          id: m.id,
          from: m.from,
          name: names[m.from] || "",
          timestamp: Number(m.timestamp) || 0,
          type: m.type,
          text,
        });
      }
    }
  }
  return found;
}

function graphUrl(env) {
  const v = env.GRAPH_VERSION || "v25.0";
  // GRAPH_BASE_URL is only for local testing against a mock server. Leave unset in production.
  const base = env.GRAPH_BASE_URL || "https://graph.facebook.com";
  return `${base}/${v}/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`;
}

// Send a plain text reply. Only ever called as an answer to someone who wrote
// to us in the last 24 hours (the customer service window), so no template is needed.
export async function sendText(env, to, body) {
  const res = await fetch(graphUrl(env), {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.WHATSAPP_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body: String(body).slice(0, 4096) },
    }),
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  if (!res.ok) {
    const err = data?.error || {};
    let hint = "";
    if (err.code === 131030) hint = " (test number: add this phone to the allowed list in API Setup)";
    if (err.code === 190) hint = " (access token expired or wrong: make a permanent System User token)";
    if (err.code === 131047) hint = " (more than 24 hours since the customer wrote: a template is required)";
    console.error(`WhatsApp send failed: HTTP ${res.status} code ${err.code} ${err.message || ""}${hint}`);
    return { ok: false, status: res.status, code: err.code };
  }
  return { ok: true, id: data?.messages?.[0]?.id };
}

// Blue ticks + "typing..." while Claude thinks. Nice to have, never fatal.
export async function markReadAndTyping(env, messageId) {
  try {
    await fetch(graphUrl(env), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.WHATSAPP_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        status: "read",
        message_id: messageId,
        typing_indicator: { type: "text" },
      }),
    });
  } catch (e) {
    console.warn("mark-read failed (ignored):", e?.message);
  }
}
