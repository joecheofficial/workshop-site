// The owner manages the calendar from their own WhatsApp. No dashboard needed.
import { getSlots, saveSlots, isValidStart, slotLabel, localNow } from "./store.js";

export const OWNER_HELP = `Owner commands:
/slots  see open and booked times
/add 2026-10-20 10:00  open a time (add more with commas)
/remove 2026-10-20 10:00  remove a time
/bookings  upcoming bookings
/help  this list`;

export function slotId(start) {
  return start.replace(/[-:]/g, "").replace(" ", "-");
}

export async function handleOwnerCommand(env, text) {
  const tz = env.BUSINESS_TIMEZONE || "UTC";
  const minutes = Number(env.SLOT_MINUTES) || 60;
  const [cmd, ...rest] = text.trim().split(/\s+/);
  const arg = rest.join(" ");
  const slots = await getSlots(env);
  const now = localNow(tz);
  const upcoming = slots.filter((s) => s.start > now);

  switch (cmd.toLowerCase()) {
    case "/slots": {
      if (!upcoming.length) return "No upcoming times. Add one with /add 2026-10-20 10:00";
      return upcoming
        .map((s) => `${slotLabel(s.start, minutes)}  ${s.booked_by ? `BOOKED by ${s.booked_by.name}` : "open"}`)
        .join("\n");
    }
    case "/add": {
      const starts = arg.split(",").map((x) => x.trim()).filter(Boolean);
      const bad = starts.filter((s) => !isValidStart(s));
      if (!starts.length || bad.length) return `Use this format: /add 2026-10-20 10:00${bad.length ? `\nCould not read: ${bad.join(", ")}` : ""}`;
      let added = 0;
      for (const start of starts) {
        if (slots.some((s) => s.start === start)) continue;
        slots.push({ id: slotId(start), start, booked_by: null });
        added++;
      }
      await saveSlots(env, slots);
      return `Added ${added} time${added === 1 ? "" : "s"}. Send /slots to check.`;
    }
    case "/remove": {
      const i = slots.findIndex((s) => s.start === arg.trim() || s.id === arg.trim());
      if (i < 0) return "I could not find that time. Send /slots to see them.";
      const [gone] = slots.splice(i, 1);
      await saveSlots(env, slots);
      const who = gone.booked_by ? ` It was booked by ${gone.booked_by.name}, please let them know.` : "";
      return `Removed ${slotLabel(gone.start, minutes)}.${who}`;
    }
    case "/bookings": {
      const booked = upcoming.filter((s) => s.booked_by);
      if (!booked.length) return "No upcoming bookings yet.";
      return booked.map((s) => `${slotLabel(s.start, minutes)}  ${s.booked_by.name} (+${s.booked_by.wa_id})`).join("\n");
    }
    default:
      return OWNER_HELP;
  }
}
