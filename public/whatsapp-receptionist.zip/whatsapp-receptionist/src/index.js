// WhatsApp receptionist: Meta WhatsApp Cloud API -> this Cloudflare Worker -> Claude API -> reply.
//
//   GET  /webhook  Meta's one-time check (hub.challenge)
//   POST /webhook  incoming WhatsApp messages (signed by Meta)
//   GET  /health   shows which settings are missing (names only, never values)

import { verifySignature, extractMessages, sendText, markReadAndTyping } from "./meta.js";
import {
  alreadySeen,
  markSeen,
  getHistory,
  saveHistory,
  isOptedOut,
  setOptOut,
  noteOwnerMessage,
  ownerWindowOpen,
} from "./store.js";
import { askClaude, FALLBACK_REPLY } from "./agent.js";
import { handleOwnerCommand } from "./owner.js";

const WINDOW_SECONDS = 24 * 60 * 60 - 5 * 60; // 24h customer service window, minus a safety margin

const REQUIRED = [
  "WHATSAPP_TOKEN",
  "WHATSAPP_APP_SECRET",
  "WHATSAPP_VERIFY_TOKEN",
  "WHATSAPP_PHONE_NUMBER_ID",
  "ANTHROPIC_API_KEY",
];

function missingSettings(env) {
  const missing = REQUIRED.filter((k) => !env[k] || String(env[k]).startsWith("REPLACE_"));
  if (!env.STORE) missing.push("STORE (KV namespace)");
  return missing;
}

const digits = (s) => String(s || "").replace(/\D/g, "");

export async function handleMessage(env, msg, nowMs = Date.now()) {
  if (await alreadySeen(env, msg.id)) return "duplicate";
  await markSeen(env, msg.id);

  // Only answer inside the 24h window. A very late webhook retry is skipped,
  // because a free-form reply would be rejected (templates only after 24h).
  if (msg.timestamp && nowMs / 1000 - msg.timestamp > WINDOW_SECONDS) return "outside-window";

  const isOwner = digits(env.OWNER_NUMBER) !== "" && digits(msg.from) === digits(env.OWNER_NUMBER);
  if (isOwner) await noteOwnerMessage(env, nowMs);

  if (msg.text === null) {
    await sendText(env, msg.from, "Thanks! I can only read text messages for now. Please type your question.");
    return "non-text";
  }

  const text = msg.text.trim();
  if (isOwner && text.startsWith("/")) {
    await sendText(env, msg.from, await handleOwnerCommand(env, text));
    return "owner-command";
  }

  const upper = text.toUpperCase();
  if (upper === "STOP") {
    await setOptOut(env, msg.from, true);
    await sendText(env, msg.from, "Done. You will not get more messages from us. Send START anytime to chat again.");
    return "opt-out";
  }
  if (upper === "START") {
    await setOptOut(env, msg.from, false);
  } else if (await isOptedOut(env, msg.from)) {
    return "opted-out";
  }

  await markReadAndTyping(env, msg.id);

  const history = await getHistory(env, msg.from);
  const customer = { waId: msg.from, name: msg.name };
  let reply = FALLBACK_REPLY;
  try {
    const result = await askClaude(env, history, text, customer);
    reply = result.text;
  } catch (e) {
    console.error("Claude call failed:", e?.status || "", e?.message);
  }

  await sendText(env, msg.from, reply);
  await saveHistory(env, msg.from, [
    ...history,
    { role: "user", content: text },
    { role: "assistant", content: reply },
  ]);

  // Tell the owner about a new booking, but only if the owner wrote in the last 24h
  // (otherwise WhatsApp would require a paid template). Owner can always send /bookings.
  if ((customer.booked || customer.cancelled) && !isOwner && digits(env.OWNER_NUMBER)) {
    if (await ownerWindowOpen(env, nowMs)) {
      const note = customer.booked
        ? `New booking: ${customer.booked.name} (+${msg.from}) on ${customer.booked.time}.`
        : `Cancelled: +${msg.from} cancelled ${customer.cancelled}.`;
      await sendText(env, digits(env.OWNER_NUMBER), note);
    }
  }
  return "replied";
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === "/health" && request.method === "GET") {
      const missing = missingSettings(env);
      return Response.json({ ok: missing.length === 0, missing });
    }

    if (url.pathname !== "/webhook") return new Response("Not found", { status: 404 });

    // 1. Meta's verification handshake when you paste the Callback URL in the dashboard.
    if (request.method === "GET") {
      const mode = url.searchParams.get("hub.mode");
      const token = url.searchParams.get("hub.verify_token");
      const challenge = url.searchParams.get("hub.challenge");
      if (mode === "subscribe" && env.WHATSAPP_VERIFY_TOKEN && token === env.WHATSAPP_VERIFY_TOKEN) {
        return new Response(challenge ?? "", { status: 200, headers: { "Content-Type": "text/plain" } });
      }
      return new Response("Forbidden", { status: 403 });
    }

    if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });

    // 2. Incoming messages. Check Meta's signature on the raw body before trusting anything.
    if (!env.WHATSAPP_APP_SECRET) {
      console.error("WHATSAPP_APP_SECRET is not set");
      return new Response("Server not configured", { status: 500 });
    }
    const raw = await request.text();
    const ok = await verifySignature(raw, request.headers.get("X-Hub-Signature-256"), env.WHATSAPP_APP_SECRET);
    if (!ok) return new Response("Bad signature", { status: 401 });

    let payload;
    try {
      payload = JSON.parse(raw);
    } catch {
      return new Response("Bad JSON", { status: 400 });
    }

    const messages = extractMessages(payload);
    // 3. Answer Meta right away (it retries slow or failed deliveries),
    //    then do the Claude work in the background.
    if (messages.length) {
      ctx.waitUntil(
        (async () => {
          for (const m of messages) {
            try {
              await handleMessage(env, m);
            } catch (e) {
              console.error("message handling failed:", e?.message);
            }
          }
        })(),
      );
    }
    return new Response("EVENT_RECEIVED", { status: 200 });
  },
};
