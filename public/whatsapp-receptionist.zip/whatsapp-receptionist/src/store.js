// Everything the receptionist remembers lives in one Workers KV namespace (env.STORE).
//   slots            -> list of appointment slots the owner opened
//   seen:<msgId>     -> marks a webhook message as handled (Meta can deliver twice)
//   chat:<waId>      -> last few messages with this person (expires after 24h)
//   optout:<waId>    -> person sent STOP
//   owner:last       -> when the owner last wrote (owner's own 24h window)
//
// Free plan note: KV allows 1,000 writes a day. Each customer message uses about 2
// writes (duplicate check + chat memory), so roughly 400-500 messages a day for free.

const DAY = 24 * 60 * 60;

export async function alreadySeen(env, msgId) {
  return (await env.STORE.get(`seen:${msgId}`)) !== null;
}

export async function markSeen(env, msgId) {
  // Meta retries failed deliveries for several days, so remember ids for 7 days.
  await env.STORE.put(`seen:${msgId}`, "1", { expirationTtl: 7 * DAY });
}

export async function getHistory(env, waId) {
  const rec = await env.STORE.get(`chat:${waId}`, "json");
  return Array.isArray(rec?.turns) ? rec.turns : [];
}

export async function saveHistory(env, waId, turns) {
  const trimmed = turns.slice(-12);
  // Expire with the 24h customer service window.
  await env.STORE.put(`chat:${waId}`, JSON.stringify({ turns: trimmed }), { expirationTtl: DAY });
}

export async function isOptedOut(env, waId) {
  return (await env.STORE.get(`optout:${waId}`)) !== null;
}

export async function setOptOut(env, waId, out) {
  if (out) await env.STORE.put(`optout:${waId}`, String(Date.now()));
  else await env.STORE.delete(`optout:${waId}`);
}

export async function getSlots(env) {
  const slots = await env.STORE.get("slots", "json");
  return Array.isArray(slots) ? slots : [];
}

export async function saveSlots(env, slots) {
  slots.sort((a, b) => a.start.localeCompare(b.start));
  await env.STORE.put("slots", JSON.stringify(slots));
}

export async function noteOwnerMessage(env, nowMs) {
  await env.STORE.put("owner:last", String(nowMs), { expirationTtl: DAY });
}

export async function ownerWindowOpen(env, nowMs) {
  const last = Number(await env.STORE.get("owner:last"));
  return Boolean(last) && nowMs - last < DAY * 1000 - 5 * 60 * 1000;
}

// ---- time helpers (slots are stored as local business time "YYYY-MM-DD HH:MM") ----

export function localNow(timeZone, nowMs = Date.now()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date(nowMs));
  const p = Object.fromEntries(parts.map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}`;
}

export function isValidStart(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/.exec(s || "");
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]));
  return d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3] && +m[4] < 24 && +m[5] < 60;
}

export function slotLabel(start, minutes = 60) {
  const [date, time] = start.split(" ");
  const [y, mo, d] = date.split("-").map(Number);
  const [h, mi] = time.split(":").map(Number);
  const begin = new Date(Date.UTC(y, mo - 1, d, h, mi));
  const end = new Date(begin.getTime() + minutes * 60000);
  const day = begin.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" });
  const hhmm = (dt) => dt.toISOString().slice(11, 16);
  return `${day}, ${hhmm(begin)}-${hhmm(end)}`;
}

export function openSlots(slots, timeZone, nowMs = Date.now()) {
  const now = localNow(timeZone, nowMs);
  return slots.filter((s) => !s.booked_by && s.start > now);
}
