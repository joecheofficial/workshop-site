# WhatsApp receptionist (Claude + Meta WhatsApp Cloud API + Cloudflare Worker)

A small program that gives Claude its own WhatsApp number. It answers questions about your
business and books appointments into a list of open times you control. It talks straight to
Meta's official WhatsApp Cloud API. No Kapso, Twilio, Wassenger, Zapier or any other middleman.

```
Customer's WhatsApp -> Meta Cloud API -> this Worker (free Cloudflare plan) -> Claude API
                                       <- reply sent back through the Cloud API <-
```

## What it does

- Passes Meta's webhook check (`hub.challenge`) and checks Meta's signature (`X-Hub-Signature-256`) on every message, so nobody else can fake messages.
- Answers Meta within milliseconds, then does the Claude work in the background (`ctx.waitUntil`), so Meta does not retry.
- Ignores a message it has already handled (Meta sometimes delivers the same one twice).
- Only replies to people who wrote first, and only inside the 24 hour customer service window. It never starts conversations, so it never needs paid templates.
- Books, lists and cancels appointments with Claude tool calls. Only times you opened can be booked, never past times, never the same time twice.
- Owner commands from your own WhatsApp: `/help`, `/slots`, `/add 2026-10-20 10:00`, `/remove 2026-10-20 10:00`, `/bookings`.
- Tells you about new bookings on WhatsApp if you have written to the number in the last 24 hours (otherwise send `/bookings`).
- STOP opts someone out, START opts them back in.
- Images and voice notes get a polite "please type" reply.
- If Claude or WhatsApp has a problem, the customer gets a polite fallback and the error goes to the Worker log with a plain hint.
- No secrets in code. They live in Cloudflare secrets.

## Files

| File | What it is |
|---|---|
| `wrangler.toml` | Worker settings: KV store, your business info, model, owner number |
| `src/index.js` | Webhook routes, duplicate check, 24h window, STOP/START, owner notice |
| `src/meta.js` | Signature check, reading Meta's payload, sending replies |
| `src/agent.js` | Claude call, receptionist instructions, booking tools |
| `src/owner.js` | Owner slash commands |
| `src/store.js` | Workers KV helpers and time helpers |
| `scripts/make-slots.mjs` | Builds a starting list of open times from your hours |
| `test/worker.test.js` | 19 tests with fake Meta and fake Claude (no network) |
| `test/e2e-local.sh` | Full run inside the real Workers runtime with a local mock server |

## Settings

Secrets (set with `npx wrangler secret put NAME`, never in a file you share):

| Name | Where it comes from |
|---|---|
| `WHATSAPP_TOKEN` | Meta: a permanent System User access token |
| `WHATSAPP_APP_SECRET` | Meta: App settings > Basic > App secret |
| `WHATSAPP_VERIFY_TOKEN` | Any long random word. You paste the same word into Meta's webhook form |
| `ANTHROPIC_API_KEY` | platform.claude.com > API keys |

Plain settings in `wrangler.toml`: `WHATSAPP_PHONE_NUMBER_ID`, `GRAPH_VERSION`, `CLAUDE_MODEL`,
`CLAUDE_EFFORT`, `BUSINESS_NAME`, `BUSINESS_TIMEZONE`, `SLOT_MINUTES`, `BUSINESS_INFO`,
`OWNER_NUMBER`, `BOOKING_LINK`.

## Run the tests

```
npm install
npm test          # 19 unit/integration tests, fake Meta + fake Claude
npm run e2e       # real Workers runtime, local mock server, no login needed
```

## Deploy (you do this once)

```
npx wrangler login
npx wrangler kv namespace create STORE     # paste the id into wrangler.toml
npx wrangler secret put WHATSAPP_TOKEN
npx wrangler secret put WHATSAPP_APP_SECRET
npx wrangler secret put WHATSAPP_VERIFY_TOKEN
npx wrangler secret put ANTHROPIC_API_KEY
node scripts/make-slots.mjs --days 14 --weekdays 1,2,3,4,5 --times 10:00,11:00,14:00,15:00 --tz Asia/Makassar > slots.json
npx wrangler kv key put --binding STORE --remote slots "$(cat slots.json)"
npx wrangler deploy
curl https://<your-worker>.workers.dev/health
```

Then in Meta: WhatsApp > Configuration > Webhook > Edit. Callback URL
`https://<your-worker>.workers.dev/webhook`, Verify token = your `WHATSAPP_VERIFY_TOKEN`.
Verify and save, then subscribe to the `messages` field.

## Honest limits

- On Meta's free test number, only up to 5 phone numbers you verify can chat with it. To go public you add a real business number.
- Free Workers KV allows 1,000 writes a day. Each customer message uses about 2, so roughly 400-500 messages a day free. Beyond that, Cloudflare Workers Paid is 5 USD a month.
- KV is not a bank vault. Two people booking the same time in the same second could, very rarely, both get it. Fine for a small practice; check `/bookings`.
- Chat memory lasts 24 hours and keeps the last 12 messages per person.
- `ANTHROPIC_BASE_URL` and `GRAPH_BASE_URL` exist only for the local e2e test. Never set them in production.
