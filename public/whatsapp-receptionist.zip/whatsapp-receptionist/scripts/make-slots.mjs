// Make a starting list of open slots from simple business hours.
//
//   node scripts/make-slots.mjs --days 14 --weekdays 1,2,3,4,5 --times 10:00,11:00,14:00,15:00 --tz Asia/Makassar > slots.json
//   npx wrangler kv key put --binding STORE --remote slots "$(cat slots.json)"
//
// weekdays: 1 = Monday ... 7 = Sunday. Slots start tomorrow (business time zone).
import { localNow } from "../src/store.js";

const args = Object.fromEntries(
  process.argv.slice(2).reduce((acc, cur, i, all) => (cur.startsWith("--") ? [...acc, [cur.slice(2), all[i + 1]]] : acc), []),
);
const days = Number(args.days || 14);
const weekdays = String(args.weekdays || "1,2,3,4,5").split(",").map(Number);
const times = String(args.times || "10:00,11:00,14:00,15:00").split(",").map((t) => t.trim());
const tz = args.tz || "UTC";

if (times.some((t) => !/^\d{2}:\d{2}$/.test(t))) {
  console.error("Times must look like 09:00,14:30");
  process.exit(1);
}

const today = localNow(tz).slice(0, 10);
const [y, m, d] = today.split("-").map(Number);
const slots = [];
for (let i = 1; i <= days; i++) {
  const day = new Date(Date.UTC(y, m - 1, d + i));
  const iso = day.toISOString().slice(0, 10);
  const weekday = ((day.getUTCDay() + 6) % 7) + 1; // Monday = 1
  if (!weekdays.includes(weekday)) continue;
  for (const t of times) {
    const start = `${iso} ${t}`;
    slots.push({ id: start.replace(/[-:]/g, "").replace(" ", "-"), start, booked_by: null });
  }
}
process.stdout.write(JSON.stringify(slots));
