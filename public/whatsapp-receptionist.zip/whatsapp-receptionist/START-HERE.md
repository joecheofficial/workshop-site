# Start here

This folder gives Claude its own WhatsApp number: a receptionist that answers your clients and books appointments, even at midnight. It talks straight to WhatsApp's official API. No third-party WhatsApp tool.

1. Keep this folder in your home folder (or leave the zip in Downloads, Claude will find it).
2. Open Claude Code.
3. Copy everything in the box below and paste it into Claude Code as one message. It walks you through the rest, about 45 to 60 minutes the first time.

```text
You are going to build and launch a WhatsApp receptionist for my business, and walk me through every click. I am not technical. Explain things in plain, short sentences. Ask me one question at a time and wait for my answer. Never assume I know a term; say it simply.

WHAT WE ARE BUILDING
A small program on Cloudflare Workers (free plan) that gives Claude its own WhatsApp number. The code is already written and tested in the folder I downloaded; your job is to set it up for my business and put it online. Clients text the number, Claude answers questions about my business and books appointments into a list of open times that I control. It talks directly to Meta's official WhatsApp Cloud API. Do NOT use any third-party WhatsApp service or SDK (no Kapso, Twilio, Wassenger, 360dialog, Zapier, Make, ManyChat or similar). The only outside services are Meta's Graph API, the Claude API, and Cloudflare.

HARD RULES FOR YOU
- Never message anyone on WhatsApp yourself. The program only replies to people who text first.
- Never ask me to paste a secret (token, App secret, API key) into this chat. Secrets go into a local file I fill in (see Phase 5). Never print secret values back to me or into logs.
- Do not put secrets in code or in wrangler.toml. Use Cloudflare secrets.
- If a step in Meta looks different from what you describe, ask me for a screenshot and adapt.
- Before each phase, tell me in one sentence what happens next and roughly how long it takes.

PHASE 0: CHECK MY COMPUTER AND FIND THE DOWNLOAD (3 min)
Check that Node.js 20 or newer is installed (node --version). If not, tell me exactly how to install it from nodejs.org for my system, then check again.
I downloaded a file called whatsapp-receptionist.zip (usually in my Downloads folder). Find it, unzip it into my home folder so I have a folder called whatsapp-receptionist, and work inside that folder from now on. If you can't find the zip, ask me where it is. If there is no zip at all, stop and tell me to download it again from the link I was sent.

PHASE 1: CHECK THE CODE WORKS BEFORE WE TOUCH ANY ACCOUNT (you do this, about 3 min)
The folder already contains the finished, tested receptionist (Meta's official WhatsApp Cloud API + the Claude API on a free Cloudflare Worker, no third-party WhatsApp tool). Do NOT rewrite it and do NOT add any third-party WhatsApp service. Read README.md first so you know how it works.
Run "npm install", then "npm test". Show me a one-line summary like "19 of 19 tests pass". If anything fails, read the error and fix only what is broken, then run the tests again. Do not continue until every test passes. Then run "npx wrangler deploy --dry-run" to make sure it bundles.

PHASE 2: MY BUSINESS (5 min)
Ask me, one at a time: my business name; what I offer, with prices and session length; my working days and hours; my time zone (suggest one from my city); my own WhatsApp number with country code (this becomes OWNER_NUMBER, digits only); an optional booking page link. Put the answers into wrangler.toml. Show me the BUSINESS_INFO text and ask if it is right.

PHASE 3: META SETUP (I click, you guide me, about 25 min)
Ask me if I already have, from Meta: a Phone number ID, an App secret, and a permanent System User token. If yes, skip to the Phone number ID question. If not, walk me through these one step at a time, waiting for "done" after each:
  a) developers.facebook.com: log in with Facebook, click Get Started, finish developer registration.
  b) developers.facebook.com/apps: Create App, name and email, use case "Connect with customers through WhatsApp", pick or create a business portfolio, Next, Create app.
  c) On Quickstart click "Start using the API" (API Setup page). Connect or create a WhatsApp Business account if asked. Click "Generate access token" (temporary, only for this test). From: the free +1 555 test number. To: "Manage phone number list", add my mobile, enter the WhatsApp code. Click "Send message". Reply "hi" to the Hello World message on my phone. Copy the "Phone number ID" (not the phone number itself) into a note.
  d) App settings > Basic > App secret > Show (Facebook password) > copy into the note.
  e) business.facebook.com/settings > Users > System users > + Add > name "receptionist", role Admin > Create. Assign assets > Apps > my app > Manage app (Full control) > Assign. Reload (may take minutes). Generate token > my app > expiration Never if offered > permissions business_management, whatsapp_business_management, whatsapp_business_messaging > Generate token > copy into the note (shown once).
  f) platform.claude.com > Settings > Billing: add 5 USD credit. Settings > API keys > Create key > copy into the note (shown once). Remind me this is billed separately from my Claude plan.
Then ask me for the Phone number ID only (it is not secret) and put it in wrangler.toml.

PHASE 4: PUT IT ONLINE (you do this, 5 min)
Run "npx wrangler login". Tell me a browser window will open: I should sign up for a free Cloudflare account (or log in) and click Allow. Then create the KV store ("npx wrangler kv namespace create STORE"), put its id in wrangler.toml, and run "npx wrangler deploy". Note the workers.dev URL.

PHASE 5: SECRETS, WITHOUT THE CHAT (5 min)
Generate a long random verify token yourself (for example 24 random bytes as hex). Create a file secrets.env in the project with exactly these lines:
WHATSAPP_APP_SECRET=PASTE_HERE
WHATSAPP_TOKEN=PASTE_HERE
ANTHROPIC_API_KEY=PASTE_HERE
WHATSAPP_VERIFY_TOKEN=<the token you generated>
Open it for me in a plain text editor (Mac: open -e secrets.env, Windows: notepad secrets.env). Tell me to replace each PASTE_HERE with the value from my note, with no spaces or quotes, save, close, and type "done". Then check the file WITHOUT showing me any values: print only "ok" or which line is still empty or looks wrong (the Claude key starts with sk-ant-, the Meta token usually starts with EA). When ok, run "npx wrangler secret bulk secrets.env", then delete secrets.env. Then open https://<my worker>/health and confirm ok is true.

PHASE 6: OPEN TIMES (2 min)
Use scripts/make-slots.mjs with my working days and hours to create open times for the next 14 days, and upload them with "npx wrangler kv key put --binding STORE --remote slots '<json>'". Tell me how many times you opened.

PHASE 7: CONNECT META (I click, 6 min)
Show me, clearly, on separate lines: the Callback URL (https://<my worker>/webhook) and the Verify token. Then guide me: my app > left menu WhatsApp > Configuration (or Use cases > Customize > Configuration) > Webhook > Edit > paste both > Verify and save. Then Webhook fields > Manage > "messages" > Subscribe on > Done. Wait for my "done".

PHASE 8: TEST IT TOGETHER (3 min)
Start "npx wrangler tail" so you can see the live log. Ask me to text the +1 555 test number from my phone: "Hi, can I book a session?". Watch the log. If no request arrives within a minute, guide me to publish the app (left menu Publish, or App Mode Development to Live; add a Privacy Policy URL in App settings > Basic if Meta asks) and try again. If a request arrives but there is an error, read it and fix it (wrong secret, expired token, phone not on the allowed list, no Claude credit). When it works, ask me to try /slots and /bookings from my phone. Stop the tail when done.

PHASE 9: HANDOVER
Give me a short summary in plain words:
- my Worker URL and that /health shows if anything is missing,
- the owner commands,
- the rules: it only replies to people who text first; free replies only within 24 hours of their last message; never connect my personal WhatsApp number to the API (it gets removed from the WhatsApp app); keep it a receptionist for my business,
- the costs: Cloudflare free plan (about 400-500 client messages a day), Claude Haiku about a tenth of a cent per reply, and once on a real number Meta gives 1,000 free replies a month per number since 1 October 2026 and then charges a small per-reply fee by country,
- that the test number only talks to the up to 5 phones I added, and the 5 steps to go live with a new number (add phone number in API Setup, display name review, payment method in Meta Business settings, tell you the new Phone number ID to redeploy, share a wa.me link),
- how to change my business info later (tell you, you edit wrangler.toml and redeploy).
```
