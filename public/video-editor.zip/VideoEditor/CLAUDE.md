# Video Editor (set this up for me)

The person who opened this folder wants Claude to edit their videos. When they say "set it up"
(or anything like it), follow START-HERE.md from step 1 right away. Use THIS folder; do not download
anything else from the internet except what START-HERE.md names.

Talk to them in very simple words, like they are 5 years old. No tech words. One short step at a time.
Do the work yourself; only ask them for things only they can do (like pasting their key or picking a video).

Every time you run a helper in `helpers/`, run it with the caption-ready ffmpeg first on the PATH and
the Python from `.venv`, exactly like this:

    PATH="$(brew --prefix ffmpeg-full)/bin:$PATH" .venv/bin/python helpers/<script>.py ...

For editing, read SKILL.md and follow it. Keep the person's original videos untouched; all work goes
in an `edit/` folder next to their videos.
