# Video Editor: start here

Put your raw videos in a folder, tell Claude what you want, and get a finished video back.
It keeps your best take, cuts the umms, the restarts and the long pauses, and adds captions.
Your sound stays in sync with your lips at every cut.

Works in Claude Code (paid Claude plan) on a Mac.

## For Claude: setup, in order

1. **Homebrew.** Run `brew --version`. No Homebrew: install it from https://brew.sh first.
   Tell the person in one simple line what you are installing and why.
2. **The video tools.** Run `brew install ffmpeg-full python@3.12`.
   It must be `ffmpeg-full`: plain `ffmpeg` from Homebrew cannot draw captions.
   Check it: `"$(brew --prefix ffmpeg-full)/bin/ffmpeg" -hide_banner -filters | grep -w subtitles`
   must print a line.
3. **The Python part.** In this folder run
   `"$(brew --prefix python@3.12)/bin/python3.12" -m venv .venv` and then
   `.venv/bin/pip install requests librosa matplotlib pillow numpy`.
4. **The listening key.** The editor uses ElevenLabs to write down every word you say, with exact times.
   Ask the person to make a free account at https://elevenlabs.io, open
   https://elevenlabs.io/app/settings/api-keys, create a key and paste it in the chat.
   Write it to a file called `.env` in this folder as `ELEVENLABS_API_KEY=<their key>`. Never print it back.
   The free ElevenLabs plan includes speech to text minutes every month (check their pricing page for today's amount).
5. **Prove it works.** Run the tests:
   `PATH="$(brew --prefix ffmpeg-full)/bin:$PATH" .venv/bin/python -m unittest discover -s tests`
   They must all pass. Then say: "Ready. Put your videos in a folder and tell me where it is."

## For Claude: every edit

Follow SKILL.md. In short: write down the words (transcribe), read them, tell the person in plain words
what you plan to keep and cut, wait for their OK, render, then check every cut yourself before showing it.
For Instagram or TikTok, offer a phone-shaped (9:16) version.

## If something goes wrong

- "No module named ...": run the step 3 install line again.
- Captions missing or "No such filter: subtitles": you used plain ffmpeg. Use the PATH line from CLAUDE.md.
- "401" or "invalid api key": the ElevenLabs key is wrong or was not saved. Ask for it again.
- Colours look grey: the video is iPhone HDR. Export it again from Photos as "Most Compatible".

## Good to know

- It does not add music. If you add music, use music you have the rights to.
- Your words are sent to ElevenLabs to be written down. Your video files stay on your Mac.
- Built on video-use by Browser Use (MIT licence, see LICENSE), with a sync fix tested by Joe Che's team
  at Masterminds HQ.
