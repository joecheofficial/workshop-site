"""MHQ patch: off-frame EDL ranges must not shorten the audio (needs ffmpeg; skipped without it).

Real edits put cut points on word boundaries, which almost never land on a frame. Video can
only stop on a frame, PCM audio stops on the sample, so without snapping each segment's audio
came out shorter than its video and the gap grew at every cut (-560 ms after 25 cuts).
"""
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HELPERS = Path(__file__).resolve().parent.parent / "helpers"
RANGES = [(0.517, 2.233), (3.311, 5.129), (6.207, 7.913), (8.401, 9.587), (10.333, 11.801)]  # all off-frame at 30 fps


def durations(media: Path) -> dict:
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,duration",
                          "-of", "json", str(media)], capture_output=True, check=True, text=True).stdout
    return {s["codec_type"]: float(s["duration"]) for s in json.loads(out)["streams"]}


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "ffmpeg not installed")
class OffFrameRangesKeepAudioLength(unittest.TestCase):
    def test_audio_matches_video_after_many_off_frame_cuts(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            src = d / "src.mov"
            subprocess.run([
                "ffmpeg", "-v", "error", "-y",
                "-f", "lavfi", "-i", "testsrc2=s=320x180:r=30:d=12",
                "-f", "lavfi", "-i", "sine=f=440:r=48000:d=12",
                "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "pcm_s16le", "-shortest", str(src),
            ], check=True)
            edit = d / "edit"
            edit.mkdir()
            edl = {"version": 1, "sources": {"S": str(src)},
                   "ranges": [{"source": "S", "start": a, "end": b} for a, b in RANGES]}
            (edit / "edl.json").write_text(json.dumps(edl), encoding="utf-8")
            out = edit / "out.mp4"
            subprocess.run([sys.executable, str(HELPERS / "render.py"), str(edit / "edl.json"), "-o", str(out),
                            "--draft", "--no-loudnorm", "--fps", "30"], check=True, capture_output=True)
            dur = durations(out)
            self.assertAlmostEqual(dur["audio"], dur["video"], delta=0.035,
                                   msg=f"audio {dur['audio']:.3f}s vs video {dur['video']:.3f}s")


if __name__ == "__main__":
    unittest.main()
