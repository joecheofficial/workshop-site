# Opening-line shapes

Twelve ways to start a post. Each one is a shape, not a fill-in-the-blank: the words come from the user's real story and their voice. The examples are made up to show the shape. Never use them as written.

Pick three different shapes for each idea. If none fits, write the plainest true sentence you can. That often wins anyway.

---

### 1. The moment
Start in the middle of something that happened. Time, place, what was said.
- Example: "Tuesday, 11pm, and my best client just emailed me a one-word message."
- Good for: stories, lessons, turning points.
- Goes wrong when: the moment is invented or the payoff is tiny.

### 2. The honest mistake
Admit something you got wrong, plainly. No humble-brag.
- Example: "I undercharged my first 20 clients and told myself it was generosity."
- Good for: pricing, hiring, lessons that cost money.
- Goes wrong when: the "mistake" is secretly a boast.

### 3. The number that surprised you
A real number from your work, and why it surprised you.
- Example: "I counted how many emails I answer a week. 312. Most of them were the same six questions."
- Good for: time, money, systems, anything you measured.
- Goes wrong when: the number isn't real. Never make one up.

### 4. The before and after
Two short sentences: how it was, how it is now. Let the gap do the work.
- Example: "Last year I wrote proposals at midnight. Now they go out the same afternoon, and I close more of them."
- Good for: a change you made, a client result (with permission).
- Goes wrong when: the "after" is vague or too good to believe.

### 5. The thing most people in your field get wrong
Name a common belief in your industry and say what you see instead.
- Example: "Most restaurant owners think they have a sales problem. Nine times out of ten it's a menu problem."
- Good for: showing expertise, starting a real discussion.
- Goes wrong when: it's contrarian just for attention, or insults your readers.

### 6. The question your clients ask
Open with a question you get asked all the time, word for word.
- Example: "\"Do I really need a website if I'm on Instagram?\" I get this every week."
- Good for: FAQs, teaching posts, beginners.
- Goes wrong when: nobody actually asked it.

### 7. The small rule
A rule you live by in your business, said in one line.
- Example: "I don't send a proposal until the client has said the price out loud."
- Good for: process, boundaries, how you work.
- Goes wrong when: it reads like a poster instead of a habit.

### 8. The list with a reason
A short numbered promise, when the post really is a list.
- Example: "Three questions I ask before I take on any new client."
- Good for: checklists, frameworks, saves.
- Goes wrong when: the number is padding. Three good items beat ten thin ones.

### 9. The overheard line
Something a client, colleague or kid said that stuck with you.
- Example: "My accountant said one sentence last March that changed how I run my week."
- Good for: lessons from other people, warmth.
- Goes wrong when: the quote is invented, or the person wouldn't want it shared.

### 10. The plain opinion
State what you think, with no "I think" in front.
- Example: "Most networking events are a waste of a good evening."
- Good for: getting the right people to nod and the wrong people to scroll.
- Goes wrong when: you can't back it up in the next three lines.

### 11. The cost of waiting
What it costs someone to keep doing it the old way. Specific, not scary.
- Example: "Every week you put off a simple booking page, you're answering the same five messages by hand."
- Good for: gentle nudges toward your offer.
- Goes wrong when: it turns into fear or pressure.

### 12. The behind the scenes
Show the unglamorous part of your work.
- Example: "Here's the spreadsheet I check every Monday before I talk to anyone."
- Good for: trust, process, showing you do the work.
- Goes wrong when: there's nothing to actually show.

---

## Rules for every opening line

- Under 140 characters, so it isn't cut off on a phone.
- It has to be true.
- Plain words. No long dashes. No exclamation marks unless the user talks that way.
- Line 2 must pay it off straight away.
