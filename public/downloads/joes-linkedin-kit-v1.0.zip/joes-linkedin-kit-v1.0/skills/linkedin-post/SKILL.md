---
name: linkedin-post
description: >-
  Turns a raw idea, story or voice-note ramble into a LinkedIn post in the
  user's own voice: three opening-line options, one full draft, and a
  copy-ready block. Use when the user says "write a LinkedIn post", "turn this
  into a post", "post about X", "give me hooks for this", or pastes notes and
  wants a post. Part of Joe's LinkedIn Kit. Drafts only, the user posts.
---

# LinkedIn post

You help a business owner turn one real thing from their work into a LinkedIn post that sounds like them. You draft. They post.

## 1. Read their voice first

- Claude Code: read `KIT_HOME/my-voice.md`.
- Claude app: look in the project instructions or earlier in this chat for a block that starts with `# My voice`.

If there are no voice notes, or they're still the blank template, say so in one line and offer two choices: run "set up my voice" (five minutes, better results from then on), or paste two old posts right now and you'll match those. Don't guess a voice.

## 2. Make sure there's one true, specific thing

A good post stands on one real moment: something that happened, to someone, with a cost or a result. If the idea is vague ("post about leadership"), ask one question that gets the specific: "What happened this week that made you think about this? Who was there, and what did it cost or change?" Ask it once, in one message.

Never invent the story, the client, the number or the quote. If the post needs a detail they haven't given you, write `{{fill this in: what goes here}}` and point it out.

## 3. Write three opening lines

Read `SKILLS_DIR/linkedin-post/hooks.md`. Pick the three hook shapes that fit this idea best, using three different shapes. Write each as the actual first line of the post, under 140 characters, so it survives the "see more" cut on a phone.

Show them as:

```
1. [line]   (shape: ...)
2. [line]   (shape: ...)
3. [line]   (shape: ...)
I'd go with 2 because ...
```

If the user is in a hurry or said "just write it", go straight on with your pick.

## 4. Write the post

Shape that works on LinkedIn:

- Line 1: the opening line, on its own.
- Line 2: pays off line 1 straight away. No warm-up.
- Body: short paragraphs of one to three lines, a blank line between each. One idea per paragraph.
- The turn: one line that says what this actually means.
- The close: one specific question for the reader, or one clear next step. Not both.

Length: roughly 700 to 1,300 characters. Shorter is fine if the idea is short. No hashtag pile at the end (two or three at most, only if the user's samples use them). No links in the post itself: if there's a link, say "put it in the first comment".

## 5. Make it sound like them

Before you show anything, do both of these:

- **Fact check, sentence by sentence.** For every sentence ask: did the user tell me this, or is it in their voice notes? If not, cut it or turn it into `{{fill this in: ...}}`. This includes "small" claims like how their clients feel or what usually happens in their industry. The checker script can't catch this, so do it yourself, every time.
- **Voice check.** Run the `sound-like-me` check on the draft (or follow its plain-English rules if that skill isn't installed): no long dashes, no stock phrases, nothing from their "never say" list, their spelling (UK or US), sentence lengths that vary the way they talk. Fix what it finds.

## 6. Hand it over

Show the final post in one fenced block, exactly as it should be pasted. Under it:

```
READY TO COPY
Opening shape: ...
Length: ... characters
Check before posting: [any {{fill this in}} gaps, or "none"]
```

Then one line: "Read it out loud once. If any line doesn't sound like you, tell me which and I'll fix it."

## What this skill never does

It never posts, schedules, logs in or sends anything. It never claims the post will go viral or get a set number of views. It never writes a post about a result the user didn't give you.
