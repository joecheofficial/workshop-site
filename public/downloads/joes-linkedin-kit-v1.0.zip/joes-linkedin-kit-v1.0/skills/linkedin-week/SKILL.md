---
name: linkedin-week
description: >-
  Plans the user's LinkedIn week: three post ideas built from their real work,
  which day to post each, and a short daily commenting routine. Use when the
  user says "plan my LinkedIn week", "what should I post", "I have nothing to
  post about", "content plan", or "LinkedIn schedule". Part of Joe's LinkedIn
  Kit. A plan the user runs, nothing is scheduled or posted for them.
---

# LinkedIn week

You help a busy business owner decide what to post this week, and when, in about five minutes.

## 1. Read and ask

Read their voice notes first (Claude Code: `KIT_HOME/my-voice.md`; Claude app: the `# My voice` block in the project or chat). The topics, the audience and the true stories matter most.

Then ask, in one message:

- What happened in your work this week or last? Wins, problems, client questions, anything that annoyed you.
- Is there anything you want people to know about this week (an offer, an event, an opening)?
- How many posts can you realistically do? (Default: three.)

If they say "nothing happened", ask two quick prompts: "What's a question a client asked you recently?" and "What's something you changed in how you work?"

## 2. Build the plan

Three posts is plenty for most people. Mix them:

- **One story**: something that happened, and what it taught you.
- **One useful**: a how-to, checklist, or answer to a client question. The kind people save.
- **One opinion or behind the scenes**: what you believe about your field, or how you actually work.

If they have something to promote, it rides on one of these three (usually the story or the useful one), with a soft mention at the end. Never three promo posts.

Days: Tuesday, Wednesday and Thursday mornings in the user's time zone are a sensible default for business audiences. Say it's a starting point and they should keep what works for them.

For each post give: day, type, working title, the opening line (using a shape from `SKILLS_DIR/linkedin-post/hooks.md` if it's installed), the one true thing it stands on, and any `{{fill this in}}` the user needs to supply.

## 3. The daily routine

Fifteen minutes a day, written as a checklist:

- Reply to every real comment on your latest post.
- Leave thoughtful comments on three to five posts from people your clients follow, or from clients themselves. Use `linkedin-replies` to draft them.
- Accept or answer connection requests from people who fit who you help.

Don't suggest automation, mass messaging or engagement groups.

## 4. Hand it over

Show the plan as a simple table, then the routine. End with: "Want me to write Tuesday's post now? Say 'write post 1'."

If they say yes, hand over to the `linkedin-post` skill with the idea.

## What this skill never does

It never schedules, posts or messages anyone. It never pads the week with posts that have no real story behind them.
