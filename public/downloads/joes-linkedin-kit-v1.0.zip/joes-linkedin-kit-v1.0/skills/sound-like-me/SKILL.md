---
name: sound-like-me
description: >-
  Sets up the user's voice notes with a short interview, and checks any draft
  (LinkedIn post, comment, reply, email) for lines that don't sound like the
  user, then rewrites them. Use when the user says "set up my voice", "does
  this sound like me", "make this sound more like me", "this sounds like AI",
  "check this before I post", or before any other LinkedIn kit skill shows a
  draft. Part of Joe's LinkedIn Kit.
---

# Sound like me

This skill has two jobs. Setup writes the user's voice notes once. Check reads a draft and fixes the lines that don't sound like them. The goal is writing the user would be happy to sign. It is not about hiding that AI helped, and you never promise anything about AI detectors.

## Where the voice notes live

- Claude Code: `KIT_HOME/my-voice.md`.
- Claude app: the user's project instructions, or earlier in this chat, in a block that starts with `# My voice`.

The notes count as empty if they're missing or still full of `[Example: ...]` lines.

## Job 1: Setup ("set up my voice")

Keep it light. One message of questions, not ten rounds.

1. If the user already answered these in their message, skip straight to step 2. Otherwise ask them together, in one message:
   - What do you do, and who do you do it for?
   - Who do you want reading your LinkedIn, and what do you want them to do after?
   - Paste two or three things you wrote yourself. Old posts, emails, a long text to a friend. Unedited is better.
   - Any words or habits you can't stand in other people's posts?
   - One or two true results or stories you're happy to share in public.
2. From the answers, work out how they actually sound: sentence length and rhythm, how formal, humour or none, words they repeat, UK or US spelling, how they open and close, emoji or not. Base this on the samples, not on what they say about themselves. If the two disagree, trust the samples and mention it.
3. Fill in the voice notes using the headings of the template (`KIT_HOME/my-voice.md` in Claude Code). Write it in plain words. Put only what they told you under "True stories and numbers". Never add any.
4. Save it:
   - Claude Code: write the file to `KIT_HOME/my-voice.md`. Show a short summary of what you saved.
   - Claude app: show the whole thing in one copyable block and say: "Paste this into your Claude Project's instructions, so every chat in that project knows your voice."
5. Offer one next step: "Want to try it? Give me any idea and I'll turn it into a LinkedIn post."

## Job 2: Check ("does this sound like me")

1. Read the voice notes. If they're empty, check against the plain-English rules below and suggest setup afterwards.
2. If you can run code, run the checker next to this file on the draft. Save the draft to a temporary text file first, then:
   ```
   python3 SKILLS_DIR/sound-like-me/check.py draft.txt
   ```
   It flags long dashes, hidden characters that come along with copy and paste, stock phrases, exclamation marks, and sentences that are all the same length. If you can't run code, do the same checks by reading.
3. Then read the draft as the user's voice notes describe them. Mark every line that:
   - uses a word or habit from their "never say" list,
   - sounds like a brochure, a motivational poster or a press release,
   - claims something they didn't tell you (a number, a client, a result),
   - is a fancier version of something they'd say plainly.
4. Show the result like this:

```
SOUNDS LIKE YOU: mostly / partly / not yet

Lines to change:
1. "original line" -> "rewritten line" (why, in five words or less)
2. ...

Facts to check: anything that needs a real number or name from you, marked {{fill this in}}
```

5. Then show the full fixed draft in a fenced block, ready to copy. Never say it is "safe", "undetectable" or "human-proof". Say what you changed.

## Plain-English rules (always on)

- No long dashes. Use a comma, a full stop, or rewrite the sentence.
- Use the word a person would say out loud. "Use" not "utilize". "Help" not "empower".
- Vary sentence length the way people do when they talk.
- One idea per paragraph. Short paragraphs on LinkedIn.
- No stock openers like "In today's fast-paced world" or "Let's dive in". No stock closers like "What are your thoughts?" unless the question is specific.
- No exclamation marks unless the user's samples use them.
- Never invent facts, quotes, clients or numbers. Leave `{{fill this in}}` instead.

## What this skill never does

It never posts, sends or logs in anywhere. The user copies the text and posts it themselves.
