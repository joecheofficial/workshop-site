#!/usr/bin/env python3
"""Joe's LinkedIn Kit: a plain-English check for a draft.

Usage:
    python3 check.py draft.txt            # report
    python3 check.py draft.txt --clean    # also print the draft with dashes
                                          # and hidden characters fixed

It looks for things that make writing read as generic: long dashes, hidden
characters picked up by copy and paste, stock phrases, exclamation marks and
sentences that are all the same length. It reads one file and prints to the
screen. It makes no network calls and changes no files.

This is a writing aid. It does not and cannot tell you whether a text will be
labelled as AI by anyone else.
"""

import re
import statistics
import sys
import unicodedata

LONG_DASHES = {"\u2014": "em dash", "\u2013": "en dash", "\u2015": "horizontal bar"}

# Characters you can't see that often ride along with copied text.
HIDDEN = {
    "\u200b": "zero-width space",
    "\u200c": "zero-width non-joiner",
    "\u200d": "zero-width joiner",
    "\u2060": "word joiner",
    "\ufeff": "byte order mark",
    "\u00ad": "soft hyphen",
    "\u202f": "narrow no-break space",
    "\u00a0": "no-break space",
}

# Phrases that make a post sound like a brochure. Kept short on purpose:
# the user's own "never say" list matters more than this one.
STOCK = [
    "in today's fast-paced world", "let's dive in", "dive into", "delve",
    "game-changer", "game changer", "unlock your", "unleash", "elevate your",
    "in the ever-evolving", "navigate the complexities", "it's important to note",
    "at the end of the day", "the power of", "a testament to", "seamless",
    "leverage", "utilize", "robust", "cutting-edge", "synergy", "tapestry",
    "embark on", "journey", "here's the thing", "let that sink in",
    "i'm thrilled to announce", "excited to share", "humbled to",
    "what are your thoughts?", "agree?", "thoughts?",
]


def sentences(text):
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [p.strip() for p in parts if len(p.strip().split()) >= 2]


def check(text):
    findings = []
    for ch, name in LONG_DASHES.items():
        n = text.count(ch)
        if n:
            findings.append(f"{n} x {name}: use a comma or full stop, or rewrite the sentence")
    for ch, name in HIDDEN.items():
        n = text.count(ch)
        if n:
            findings.append(f"{n} x hidden character ({name}): remove it")
    other = sorted({c for c in text if unicodedata.category(c) == "Cf" and c not in HIDDEN})
    if other:
        findings.append("hidden formatting characters: " + ", ".join(f"U+{ord(c):04X}" for c in other))
    low = text.lower().replace("\u2019", "'").replace("\u2018", "'")
    for phrase in STOCK:
        if phrase in low:
            findings.append(f'stock phrase: "{phrase}"')
    gaps = re.findall(r"\{\{[^}]*\}\}", text)
    if gaps:
        findings.append(f"{len(gaps)} x gap still to fill in, e.g. {gaps[0]}: replace it before you post")
    bangs = text.count("!")
    if bangs:
        findings.append(f"{bangs} x exclamation mark: keep only if you really talk like that")
    lens = [len(s.split()) for s in sentences(text)]
    if len(lens) >= 5:
        spread = statistics.pstdev(lens)
        if spread < 4:
            findings.append(
                f"sentences are all about the same length (spread {spread:.1f} words): "
                "mix a few short ones with a few longer ones"
            )
    return findings, lens


def clean(text):
    for ch in HIDDEN:
        text = text.replace(ch, " " if ch in ("\u00a0", "\u202f") else "")
    text = re.sub(r"\s*[\u2014\u2015]\s*", ", ", text)
    text = re.sub(r"(?<=\d)\u2013(?=\d)", "-", text)
    text = re.sub(r"\s*\u2013\s*", ", ", text)
    text = "".join(c for c in text if unicodedata.category(c) != "Cf")
    return text


def main(argv):
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print(__doc__)
        return 0
    with open(argv[1], encoding="utf-8") as f:
        text = f.read()
    findings, lens = check(text)
    words = len(text.split())
    print(f"Words: {words}   Characters: {len(text)}   Sentences: {len(lens)}")
    if findings:
        print("Things to look at:")
        for item in findings:
            print(f"  - {item}")
    else:
        print("Nothing flagged. Now read it out loud: would you say it like that?")
    if "--clean" in argv:
        print("\n--- cleaned draft (dashes and hidden characters only; read it before using) ---")
        print(clean(text))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
