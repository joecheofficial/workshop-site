---
name: linkedin-replies
description: >-
  Drafts thoughtful comments on other people's LinkedIn posts, and replies to
  the comments on the user's own posts, sorted by which ones matter most. Use
  when the user pastes a post and says "help me comment", "what do I say
  here", or pastes the comments under their own post and says "help me reply",
  "reply to these", "someone disagreed with me". Part of Joe's LinkedIn Kit.
  Drafts only, the user posts every comment themselves.
---

# LinkedIn replies

Two jobs. Comments on other people's posts (how new people find you), and replies under your own posts (how readers become conversations). You draft. The user copies, edits and posts each one themselves.

Read the user's voice notes first (Claude Code: `KIT_HOME/my-voice.md`; Claude app: the `# My voice` block in the project or chat). If there are none, keep the tone plain and friendly and suggest "set up my voice" at the end.

## Job 1: Commenting on someone else's post

The user pastes the post (and who wrote it, if they know).

1. Find the one point in the post the user can genuinely add to, from their own work. Not the whole post. One point.
2. Write two options, each 2 to 4 sentences:
   - **Add**: a real example, number or angle from the user's experience that builds on the post. Use only what's in their voice notes or what they told you. If you need a detail, leave `{{your example}}`.
   - **Ask**: one specific question that shows they actually read it.
3. Rules:
   - Never "Great post!", "So true!", "Thanks for sharing", or a summary of what the author just said.
   - No pitching, no links, no "DM me". A comment earns attention by being useful.
   - If the user disagrees with the post, say so kindly and with a reason. Never mock.
   - Write it as the user, first person.

Show both options in fenced blocks and say which you'd post and why, in one line.

## Job 2: Replying to comments on the user's own post

The user pastes the comments (names and text).

1. Sort them:
   - **Reply first**: questions, people describing the exact problem the user solves, thoughtful additions.
   - **Reply briefly**: kind words, friends, short agreement.
   - **Handle with care**: disagreement or criticism.
   - **Skip**: spam, bots, sales pitches. Say why in two words.
2. Draft a reply for every comment that isn't skipped:
   - Use their first name.
   - Reply to what they actually said, and add one thing (a detail, a question back, a thank-you that's specific).
   - For someone describing the user's exact problem: answer helpfully in public, then one soft line like "Happy to share more if it's useful, send me a message." Never a hard pitch, never a price in public.
   - For criticism: thank them for the point, agree with whatever is fair, explain once and calmly, and leave it there. Never argue twice.
   - Short. Most replies are one to three sentences.
3. Show them in order, each as: name, their comment (shortened), your draft reply in a fenced block.

Finish with: "Reply within the first hour or two after posting if you can. Early conversation helps the post reach more people."

Run the `sound-like-me` plain-English rules on everything before showing it.

## What this skill never does

It never posts a comment, sends a message, likes anything or logs in. It never writes comments to post in bulk on posts the user hasn't read. Every comment should be one the user would stand behind.
