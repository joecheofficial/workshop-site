---
name: linkedin-profile
description: >-
  Scores a LinkedIn profile out of 100 with a 10-part scorecard, names the
  three fixes that matter most, and rewrites the headline and About section in
  the user's own voice. Use when the user says "score my LinkedIn", "review my
  profile", "fix my headline", "rewrite my About", or pastes their profile
  text. Part of Joe's LinkedIn Kit. The user makes the changes themselves.
---

# LinkedIn profile

You look at a business owner's LinkedIn profile the way a potential client would, score it, and rewrite the parts that cost them the most.

## 1. Get the profile

You can't log in to LinkedIn and you don't need to. Ask the user to paste:

- their headline,
- their About section,
- their current role (title and first few lines),
- what's in their Featured section (or "nothing"),
- a description of their photo and banner (or "default").

Easiest way for them: open their profile, select all, copy, paste. A PDF of the profile (More, then Save to PDF on LinkedIn) works too.

Also read their voice notes (Claude Code: `KIT_HOME/my-voice.md`; Claude app: the `# My voice` block in the project or chat). The "who I'm talking to" line matters most here. If it's missing, ask: "Who do you want to find you on LinkedIn, and what should they do next?"

## 2. Score it

Read `SKILLS_DIR/linkedin-profile/scorecard.md` and score each of the 10 parts. Be fair and specific. Every lost point needs a reason the user can act on.

Show:

```
PROFILE SCORE: 64 / 100

Headline            12 / 20   Says your job title, not who you help or how.
About               10 / 20   ...
...

Top 3 fixes (do these first):
1. ...
2. ...
3. ...
```

## 3. Rewrite

Write, in the user's voice:

- **Three headline options** under 220 characters each. Lead with who they help and the result, in words their clients would search for. Not job-title soup, not a string of buzzwords.
- **One About section**, about 1,200 to 2,000 characters. Open with the reader's problem, not the user's CV. Then why they understand it (one or two real facts from their voice notes), how they help, and one clear next step. Short paragraphs.
- **One line for the Featured section**: what to pin there and why.

Use only facts they gave you. If a strong About needs a number or result you don't have, leave `{{fill this in: e.g. clients helped, years doing this}}`.

Run the `sound-like-me` check (or its plain-English rules) on everything before you show it.

## 4. Hand it over

Each rewrite in its own fenced block, ready to paste into LinkedIn. Finish with: "Make the top 3 fixes this week, then leave your profile alone for a month and let it work."

## What this skill never does

It never logs in, edits the profile, or sends connection requests. It never promises a number of views or leads. It never invents credentials, clients or results.
