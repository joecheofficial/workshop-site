# Profile scorecard (100 points)

Score from the point of view of one ideal client who just landed on the profile. They give it about ten seconds. Would they know who this person helps, trust them, and know what to do next?

| # | Part | Points | Full marks when |
|---|---|---|---|
| 1 | Headline | 20 | Says who they help and the result, in words a client would search for. Readable in the first 60 characters on a phone. |
| 2 | About: first three lines | 10 | The opening (what shows before "see more") speaks to the reader's problem, not the user's history. |
| 3 | About: the rest | 10 | Shows why they understand the problem (real facts), how they help, and one clear next step. Short paragraphs. Sounds like a person. |
| 4 | Photo | 8 | Recent, face clearly visible, looking at the camera, plain background. Looks like them on a video call. |
| 5 | Banner | 7 | Not the default. Says or shows what they do, or reinforces the headline. |
| 6 | Featured | 10 | One to three items that help a client decide: a post that explains the offer, a case study, a booking or contact link. |
| 7 | Current role | 10 | Title plus two to four lines on who they help and how. Not a copy of the headline. |
| 8 | Proof | 10 | Somewhere on the profile: a real result, a recommendation, a client name (with permission) or a number. |
| 9 | Clear next step | 10 | It's obvious how to work with them or contact them: website, booking link, "send me a message about X". |
| 10 | Consistency | 5 | Headline, About and role tell the same story to the same person. |

## How to score

- Give partial points. A headline that names the audience but not the result might get 12 of 20.
- Every lost point gets one plain sentence the user can act on.
- The top 3 fixes are the three that win back the most points for the least effort.
- Don't take points off for things outside this list (skills, endorsements, number of connections).
