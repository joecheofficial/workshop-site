#!/usr/bin/env bash
# Joe's LinkedIn Kit installer for Claude Code.
#
#   bash install.sh              install or update the five skills
#   bash install.sh --uninstall  remove the skills (keeps your voice file)
#   bash install.sh --uninstall --purge   also delete your voice file
#   bash install.sh --force      replace skills with the same names that
#                                did not come from this kit
#
# Copies skills into ~/.claude/skills/ and creates ~/.claude/linkedin-kit/my-voice.md
# (never overwrites a voice file that already exists). No downloads, no sudo,
# nothing outside ~/.claude/ is touched.

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DEST="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"
KIT_HOME="${LINKEDIN_KIT_HOME:-$HOME/.claude/linkedin-kit}"
SKILLS="sound-like-me linkedin-post linkedin-profile linkedin-replies linkedin-week"
MARKER=".joe-linkedin-kit"

MODE="install"; FORCE=0; PURGE=0
for arg in "$@"; do
  case "$arg" in
    --uninstall) MODE="uninstall" ;;
    --force) FORCE=1 ;;
    --purge) PURGE=1 ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    *) echo "Unknown option: $arg (try --help)"; exit 1 ;;
  esac
done

if [ "$MODE" = "uninstall" ]; then
  for s in $SKILLS; do
    if [ -f "$SKILLS_DEST/$s/$MARKER" ]; then
      rm -rf "${SKILLS_DEST:?}/$s"; echo "removed  $s"
    elif [ -e "$SKILLS_DEST/$s" ]; then
      echo "skipped  $s (not from this kit, left alone)"
    fi
  done
  if [ "$PURGE" = 1 ] && [ -d "$KIT_HOME" ]; then
    rm -rf "${KIT_HOME:?}"; echo "removed  your voice file and $KIT_HOME"
  else
    echo "Your voice file is still at $KIT_HOME/my-voice.md (use --purge to delete it)."
  fi
  exit 0
fi

[ -d "$SRC/skills" ] || { echo "Can't find the skills folder next to install.sh. Run this from inside the unzipped kit."; exit 1; }

mkdir -p "$SKILLS_DEST" "$KIT_HOME"

# Escape a path for use on the right-hand side of sed s|||.
esc() { printf '%s' "$1" | sed -e 's/[\\|&]/\\&/g'; }
K="$(esc "$KIT_HOME")"
S="$(esc "$SKILLS_DEST")"

for s in $SKILLS; do
  dest="$SKILLS_DEST/$s"
  if [ -e "$dest" ] && [ ! -f "$dest/$MARKER" ] && [ "$FORCE" != 1 ]; then
    echo "skipped  $s: you already have a different skill with this name (use --force to replace it)"
    continue
  fi
  rm -rf "${dest:?}"
  cp -R "$SRC/skills/$s" "$dest"
  # Point the skill at this computer's folders (portable: works with macOS and GNU sed).
  for f in "$dest"/*.md; do
    sed -e "s|KIT_HOME|$K|g" -e "s|SKILLS_DIR|$S|g" "$f" > "$f.tmp" && mv "$f.tmp" "$f"
  done
  echo "kit v1.0" > "$dest/$MARKER"
  echo "installed $s"
done

if [ -f "$KIT_HOME/my-voice.md" ]; then
  echo "kept     your existing voice file: $KIT_HOME/my-voice.md"
else
  cp "$SRC/my-voice.md" "$KIT_HOME/my-voice.md"
  echo "created  $KIT_HOME/my-voice.md (blank, Claude fills it in with you)"
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "Note: python3 isn't installed, so the optional draft checker won't run. Everything else works."
fi

cat <<'EOF'

Done. Next:
  1. Open Claude Code (restart it if it was already open).
  2. Say: Set up my voice
  3. Then: Turn this into a LinkedIn post: <your idea>

Claude drafts. You read it, edit it, and post it yourself.
EOF
