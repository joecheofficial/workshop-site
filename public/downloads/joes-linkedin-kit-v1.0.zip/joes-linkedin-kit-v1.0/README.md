# Joe's LinkedIn Kit

Five Claude skills that help you show up on LinkedIn in your own voice. Claude drafts. You read it, change what you want, and post it yourself. Nothing in this kit logs into LinkedIn, and nothing posts for you.

I've been teaching since 1998, and the thing I see over and over is that people don't need more content. They need content that sounds like them, so the right people recognise them. That's what this kit is for.

## What's inside

| Skill | What you say to Claude | What you get |
|---|---|---|
| `sound-like-me` | "Set up my voice" or "Does this sound like me?" | First run: a short interview that writes your voice notes. After that: a check on any draft, with the lines that don't sound like you rewritten. |
| `linkedin-post` | "Turn this into a LinkedIn post: ..." | Three opening lines to pick from, one full draft in your voice, ready to copy. |
| `linkedin-profile` | "Score my LinkedIn profile" (paste it in) | A score out of 100, the three fixes that matter most, and a rewritten headline and About section. |
| `linkedin-replies` | "Help me comment on this post" or "Help me reply to these comments" | Comments that add something real, and replies to people on your own posts, sorted by which ones matter. |
| `linkedin-week` | "Plan my LinkedIn week" | Three posts for the week, the day for each, and a short daily routine for commenting. |

## Before anything else: your voice

Every skill reads your voice notes first. Start with:

> Set up my voice

Claude asks you a few questions and for two or three things you've written (old posts, emails, even voice notes typed out). It writes your voice notes from those. Five minutes, once.

## Install

### Option 1: Claude Code (Mac or Linux)

1. Unzip the kit.
2. Open Terminal in the unzipped folder and run:

```
bash install.sh
```

3. Open Claude Code and say "Set up my voice".

The installer copies the five skills into `~/.claude/skills/` and creates your voice file at `~/.claude/linkedin-kit/my-voice.md`. It never overwrites a voice file you've already filled in. To remove everything, run `bash install.sh --uninstall`.

### Option 2: the Claude app (claude.ai or desktop)

1. Go to Settings, then Capabilities, and turn on Skills (it needs a paid Claude plan).
2. In the `claude-app` folder of the kit there's one zip per skill. Upload each one under Skills.
3. Start a chat and say "Set up my voice". The app can't save files on your computer, so Claude gives you your voice notes as text. Paste them into a Claude Project's instructions (or keep them handy and paste them at the start of a chat). Every skill looks for them there.

### Option 3: no install at all

Open `START-HERE-PROMPT.md`, copy the prompt into any Claude chat, and go. It does the voice interview and then writes posts with you. You lose the shortcuts, not the results.

## How I'd use it

- Do the voice setup first and be honest in it. The better your examples, the more the drafts sound like you.
- Run `linkedin-profile` once, fix the top three things, then leave your profile alone for a month.
- Every Monday, `linkedin-week`. Every post, `linkedin-post`. Ten minutes a day of `linkedin-replies` on other people's posts does more than a fourth post would.
- Always read the draft out loud before you post. If you wouldn't say it, change it.

## Good to know

- Claude never posts, sends, or logs in anywhere. You copy and paste.
- The skills never make up numbers, clients or stories. If a draft needs a fact only you know, it leaves a `{{fill this in}}` gap for you.
- This kit helps you sound like yourself. It is not a tool for hiding that you used AI, and it makes no promise about AI detectors. Use it to get to a draft faster, then make it yours.

## Credits

The idea for a LinkedIn skill pack comes from Jake Schincariol's open-source LinkedIn agent skill (MIT license). The words in this kit are written fresh. See `CREDITS.md`.

If you make something good with this, reply to the email it came in and tell me. I read them.

Joe Che
