# Credits

Joe's LinkedIn Kit was inspired by **The LinkedIn agent skill** by **Jake Schincariol**
(https://github.com/Jakeschincariol/linkedin-agent-skill), released under the MIT license.

Jake's pack showed how useful a small set of focused LinkedIn skills for Claude can be. This kit
takes that idea and rebuilds it for business owners: five skills instead of eleven, every
instruction rewritten from scratch, a different hook list, a different profile scorecard, a voice
interview, and a simpler checker script. No text or code from the original is copied into this
kit. We keep Jake's notice below anyway, with thanks.

```
MIT License

Copyright (c) 2026 Jake Schincariol

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
