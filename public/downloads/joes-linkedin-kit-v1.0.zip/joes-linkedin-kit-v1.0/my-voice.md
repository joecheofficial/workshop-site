# My voice

<!--
This is your voice file. Every skill in the kit reads it before it writes anything.
The easiest way to fill it: open Claude and say "Set up my voice". Claude interviews you and
fills this in for you. You can also fill it by hand. Delete the example lines in brackets.
-->

## Who I am, in one or two sentences
[Example: I run a small bookkeeping firm for restaurants. I started it after 10 years as a chef.]

## Who I'm talking to on LinkedIn
[Example: restaurant owners with 1 to 3 locations who do their own books at midnight.]

## What I want them to do after reading
[Example: send me a message, book a call, or just remember me when the problem shows up.]

## How I sound
- Sentence length: [short and punchy / medium / long and flowing / a mix]
- Formality: [casual / friendly-professional / formal]
- Humour: [none / dry / playful]
- Words and phrases I actually use: [list a few]
- Spelling: [US / UK / Australian / other]
- Emoji: [never / rarely / often]

## What I never say
[Words, phrases or habits that make you cringe. Example: "game-changer", "let that sink in", exclamation marks, hashtags at the end.]

## True stories and numbers I'm happy to share
[Only real things. Claude will never make up a number or a client, so put the good ones here.
Example: "Cut a client's month-end close from 9 days to 3." "Got my first 10 clients from one post."]

## Topics I can talk about all day
[3 to 5 themes. Example: cash flow, hiring your first person, why restaurants fail in year two.]

## Samples of my writing
[Paste two or three things you wrote yourself: posts, emails, a message to a friend. These matter
more than anything else on this page.]
