# My offer

Salesman reads this page before it finds customers or writes an email. Keep it up to date. Anything still in [Example: ...] form counts as empty.

## What I sell
[Example: Websites for family dentists, from $2,000, live in 3 weeks.]

## What customers get (their words)
[Example: More new-patient bookings without extra phone calls.]

## True results I'm happy to mention
[Example: A dental office in Leeds went from 4 to 11 online bookings a week. Only results that really happened.]

## Dream customer
- Type of business: [Example: independent family dental practices]
- Size: [Example: 1 to 3 dentists]
- Who says yes: [Example: the practice owner or office manager]
- Where: [Example: Austin, Texas and 30 miles around]

## Great fit
- [Example: phone-only booking]
- [Example: footer copyright year more than 2 years old]

## Rule out
- [Example: chains and groups]
- [Example: already has online booking]

## How I write
- [Example: short sentences, friendly, no jargon, signs off "Cheers, Sam"]

## Footer
- Name: [Example: Sam Lee]
- Business: [Example: Bright Smile Web]
- Postal address: [Example: 12 Main St, Austin, TX 78701]
- Booking link (optional): [Example: https://cal.com/samlee/intro]
