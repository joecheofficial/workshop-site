#!/usr/bin/env bash
# Joe's Salesman kit installer for Claude Code.
#
#   bash install.sh              install or update the four skills
#   bash install.sh --uninstall  remove the skills (keeps your offer and prospect list)
#   bash install.sh --uninstall --purge   also delete your offer and prospect list
#   bash install.sh --force      replace skills with the same names that
#                                did not come from this kit
#
# Copies skills into ~/.claude/skills/ and creates ~/.claude/salesman/my-offer.md and prospects.md
# (never overwrites files that already exist). No downloads, no sudo,
# nothing outside ~/.claude/ is touched.

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DEST="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"
KIT_HOME="${SALESMAN_HOME:-$HOME/.claude/salesman}"
SKILLS="salesman-setup find-customers write-emails handle-replies"
MARKER=".joe-salesman-kit"

MODE="install"; FORCE=0; PURGE=0
for arg in "$@"; do
  case "$arg" in
    --uninstall) MODE="uninstall" ;;
    --force) FORCE=1 ;;
    --purge) PURGE=1 ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    *) echo "Unknown option: $arg (try --help)"; exit 1 ;;
  esac
done

if [ "$MODE" = "uninstall" ]; then
  for s in $SKILLS; do
    if [ -f "$SKILLS_DEST/$s/$MARKER" ]; then
      rm -rf "${SKILLS_DEST:?}/$s"; echo "removed  $s"
    elif [ -e "$SKILLS_DEST/$s" ]; then
      echo "skipped  $s (not from this kit, left alone)"
    fi
  done
  if [ "$PURGE" = 1 ] && [ -d "$KIT_HOME" ]; then
    rm -rf "${KIT_HOME:?}"; echo "removed  your offer, prospect list and $KIT_HOME"
  else
    echo "Your offer and prospect list are still in $KIT_HOME (use --purge to delete them)."
  fi
  exit 0
fi

[ -d "$SRC/skills" ] || { echo "Can't find the skills folder next to install.sh. Run this from inside the unzipped kit."; exit 1; }

mkdir -p "$SKILLS_DEST" "$KIT_HOME"

# Escape a path for use on the right-hand side of sed s|||.
esc() { printf '%s' "$1" | sed -e 's/[\\|&]/\\&/g'; }
K="$(esc "$KIT_HOME")"
S="$(esc "$SKILLS_DEST")"

for s in $SKILLS; do
  dest="$SKILLS_DEST/$s"
  if [ -e "$dest" ] && [ ! -f "$dest/$MARKER" ] && [ "$FORCE" != 1 ]; then
    echo "skipped  $s: you already have a different skill with this name (use --force to replace it)"
    continue
  fi
  rm -rf "${dest:?}"
  cp -R "$SRC/skills/$s" "$dest"
  # Point the skill at this computer's folders (portable: works with macOS and GNU sed).
  for f in "$dest"/*.md; do
    sed -e "s|KIT_HOME|$K|g" -e "s|SKILLS_DIR|$S|g" "$f" > "$f.tmp" && mv "$f.tmp" "$f"
  done
  echo "salesman v1.0" > "$dest/$MARKER"
  echo "installed $s"
done

for f in my-offer.md prospects.md; do
  if [ -f "$KIT_HOME/$f" ]; then
    echo "kept     your existing $KIT_HOME/$f"
  else
    cp "$SRC/$f" "$KIT_HOME/$f"
    echo "created  $KIT_HOME/$f"
  fi
done

if ! command -v python3 >/dev/null 2>&1; then
  echo "Note: python3 isn't installed, so the optional email checker won't run. Everything else works."
fi

cat <<'EOF'

Done. Next:
  1. Open Claude Code (restart it if it was already open).
  2. Say: Set up Salesman
  3. Then: Find me customers

Salesman finds and drafts. You read every email and send it yourself.
EOF
