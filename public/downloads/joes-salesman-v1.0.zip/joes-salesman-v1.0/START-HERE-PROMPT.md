# No-install version: paste this into any Claude chat

Copy everything inside the box below into a new chat in Claude. Turn on web search first if your Claude has it (it works without it too, you just paste in the businesses yourself).

```
You're going to help me find customers for my small business and write the first email to each one. I will read every email and send it myself from my own inbox, so I only need research and drafts. Only use information businesses publish on their own public websites.

Step 1. Learn my offer. Ask me these in one message, then wait:
- What I sell and roughly what it costs.
- What customers get out of it, plus one or two true results I'm happy to mention.
- My dream customer: type of business, size, who says yes, and where they are.
- What makes a business a great fit, and what rules one out.
- One or two emails I wrote myself, so you can match how I write.
- My name, business name and business postal address for the email footer.
Then show my answers back as short "My offer" notes in one block so I can save them.

Step 2. Find 10 businesses that fit. If you can search the web, find them yourself, preferring each business's own website over directories. If you can't, ask me to paste a list of names or websites. For each one, read its website and give me one table: business, website, who decides (only if named on the site), fit score out of 100, why it fits in one line, one specific detail from their site worth mentioning, and the contact email or form published on the site. Never guess an email address and never invent a detail. If a site won't load, say so.

Step 3. When I pick businesses, write for each one:
- Email 1, under 75 words: start with them, not "I" or "We", mention the specific detail, ask one real question, no pitch and no link.
- Email 2 for 3 to 4 days later, under 75 words: one new angle and one clear next step.
- Email 3 for a week after that, under 40 words: polite, and make "no" easy.
Subject lines lowercase, 2 to 5 words, never a fake "re:". Plain text, no long dashes, no exclamation marks, and none of these: free, guarantee, act now, limited time, click here, game-changer, unlock, leverage, "hope this finds you well", "just following up". Never make up a client, number or result. End every email with my name, business, postal address and this line: Not the right fit? Reply "no thanks" and I won't email again.
Before showing each email, check it against those rules and fix anything that fails. Give each email in its own block, ready to copy.

Step 4. When I paste a reply, tell me in one line what they meant (interested, question, objection, wrong person, not now, no, unsubscribe, or upset), then draft a short reply that answers them first and moves toward a call. If it's a no or an unsubscribe, tell me not to reply and never to email them again. If they're upset or mention a complaint, tell me to handle it myself.
```

Save your "My offer" notes from step 1. Next time, paste them in first so you don't have to answer the questions again.
