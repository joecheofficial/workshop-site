# Credits

The idea for Salesman (find businesses that fit, read their sites, score them, write a specific email, handle replies, nothing sends without you) comes from **Harvey** by Ethan Rogers: https://github.com/ethanplusai/harvey

Harvey is a full autonomous sales agent that runs on your own computer. Salesman is a much smaller, beginner-friendly rework for people who don't want to run software: four Claude skills you can use in the Claude app or Claude Code, and you send every email yourself. No code or text was copied from Harvey. Every skill, the checker and the templates were written fresh for this kit. Harvey's licence is kept below as thanks and to be safe.

If you want the full autonomous version, with a dashboard and sending built in, go and look at Harvey.

---

MIT License

Copyright (c) 2026 Ethan Rogers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
