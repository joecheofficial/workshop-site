# My prospect list

Salesman adds new businesses here and updates the status as you go. It never deletes a row, so nobody gets emailed twice.

Statuses: ruled out, found, drafted, sent, replied, call booked, not now: check back <date>, no, do not contact

| Date | Business | Website | Who decides | Fit | Why it fits | Detail to mention | How to reach | Status | Notes |
|---|---|---|---|---|---|---|---|---|---|
