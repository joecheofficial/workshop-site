---
name: write-emails
description: >-
  Writes short, specific first emails and two follow-ups for businesses on the
  user's prospect list, in the user's own voice, then runs a pre-send check
  that catches spammy words, AI-sounding phrases, made-up details and missing
  legal lines. The user reads and sends every email themselves. Use when the
  user says "write emails for 1, 2 and 3", "write a cold email to", "follow up
  with", "check this email before I send it", or pastes an email to check.
  Part of Joe's Salesman kit.
---

# Write emails

A good first email sounds like one person who looked at the business for two minutes and noticed something real. It starts a conversation. It does not try to close a sale.

The user sends every email themselves, from their own inbox, after reading it. Never say or imply that you sent anything.

## Before you start

Read the offer notes (`KIT_HOME/my-offer.md` or the `# My offer` block) and the prospect rows (`KIT_HOME/prospects.md` or the table in this chat). If a prospect's "How to reach" is a contact form or phone only, still write email 1 so they can paste it into the form, and say so. If a prospect has no "Detail to mention", say so and offer to read their site first with `find-customers`. Never write a generic email to fill the gap.

## What to write, per business

1. **Email 1** (under 75 words). Open with them, not with "I" or "We". Mention the one specific detail from their site. Ask one real question about it. Don't pitch, don't name the product, no link.
2. **Email 2** (under 75 words, for 3 to 4 days later if there's no reply). One new angle: what the offer does about that detail, in plain words, with one true result from the offer notes if there is one. One clear question or next step.
3. **Email 3** (under 40 words, for about a week after email 2). Short and polite. Ask if it's worth talking or if they'd like you to stop. Make "no" easy.

Each email gets a subject line: lowercase, 2 to 5 words, no "quick question", no fake "re:" or "fwd:".

## Rules for every email

- Write in the user's voice from the offer notes. Plain text only: no bold, no bullets, no emoji.
- One point and one question per email. Not two.
- Never make anything up: no invented clients, numbers, mutual friends, or "I saw your post" unless it's in the notes. If you need something only the user knows, write `{{fill this in}}`.
- No long dashes, no exclamation marks, no all-caps words.
- Avoid words spam filters and readers hate: "free", "guarantee", "act now", "limited time", "special offer", "click here", "100%", "game-changer", "unlock", "leverage", "supercharge", "hope this finds you well", "just following up", "I'd love to", "touching base".
- Sign off the way the user normally does (first name is fine), then the footer lines below. Don't repeat the name and business twice.

## Footer (every email)

```
{{Your name}}, {{Business name}}
{{Business postal address}}
Not the right fit? Reply "no thanks" and I won't email again.
```

Fill these in from the offer notes. Keep the opt-out line. It's what makes a cold email legal in many places, and it's simply polite.

## Pre-send check

Before showing any email, check it against this list and fix anything that fails:

- [ ] Under the word limit (75, 75, 40), not counting the footer.
- [ ] Starts with them, not "I" or "We".
- [ ] Mentions the real detail from their site (email 1).
- [ ] Exactly one question or next step.
- [ ] No link in email 1.
- [ ] None of the banned words above, no long dashes, no exclamation marks.
- [ ] Nothing made up. Every fact traces to their website or the offer notes.
- [ ] No `{{gaps}}` left, except ones the user must fill in themselves (point these out).
- [ ] Footer present with a postal address and the opt-out line.

The checker catches wording and footer problems. It can't tell whether a fact is true, so the "Nothing made up" box is always yours to check by eye.

In Claude Code, also run the checker on the drafts and fix whatever it flags:

```
python3 SKILLS_DIR/write-emails/check.py drafts.txt
```

(Save the emails to a text file first, separated by a line with `---`. It's optional. If Python isn't installed, the list above is enough.)

## Show and save

For each business, show the three emails in one copyable block each, with the subject line on top. Under them, one line: "Read it, change anything that doesn't sound like you, then send email 1 from your own inbox."

In Claude Code, set the prospect's status in `KIT_HOME/prospects.md` to `drafted`. When the user says they sent it, set it to `sent` with the date.

## Sending advice (say this once, the first time)

- Send a handful a day from your normal inbox, by hand. 10 to 20 a day is plenty.
- If you ever want to send many more, use a separate domain set up for it (with SPF, DKIM and DMARC) and warm it up for a few weeks first, or your normal email can end up in spam.
- If someone asks whether AI helped write it, tell the truth.
