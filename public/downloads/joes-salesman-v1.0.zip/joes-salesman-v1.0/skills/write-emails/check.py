#!/usr/bin/env python3
"""Salesman pre-send check.

    python3 check.py drafts.txt          check emails in a file
    python3 check.py < drafts.txt        same, from a pipe

Emails are separated by a line containing only ---. Put the subject on the
first line as "Subject: ...". Number them in order (first email, follow-up 1,
follow-up 2) by separating each business's set with a line containing ===.

It checks wording and the footer. It can't tell whether a fact is true:
that part is always yours to check. It only flags things. It never sends anything and never changes your file.
Exit code 0 = all clear, 1 = something to fix.
"""
import re
import sys

BANNED = [
    "free", "guarantee", "guaranteed", "risk-free", "no risk", "act now",
    "limited time", "special offer", "exclusive deal", "discount", "% off",
    "click here", "click below", "buy now", "sign up now", "100%", "$$$",
    "winner", "congratulations", "last chance", "double your",
    "game-changer", "game changer", "unlock", "supercharge", "leverage",
    "elevate", "seamless", "delve", "synergy", "cutting-edge",
    "hope this finds you well", "hope you're doing well", "hope you are well",
    "just following up", "just checking in", "touching base", "circle back",
    "i'd love to", "i would love to", "just wanted to", "reaching out because",
    "i know you're busy", "quick question", "picture this", "imagine if",
    "what if i told you", "no pressure", "no obligation",
]
LIMITS = [75, 75, 40]
LONG_DASH = "\u2014"
EN_DASH = "\u2013"
GAP = re.compile(r"\{\{[^}]*\}\}")
URL = re.compile(r"https?://\S+|www\.\S+", re.I)
FOOTER_START = re.compile(r"^not the right fit\?", re.I | re.M)


def split_body(text):
    """Return (subject, body without footer, full text)."""
    lines = text.strip().splitlines()
    subject = ""
    if lines and lines[0].lower().startswith("subject:"):
        subject = lines[0].split(":", 1)[1].strip()
        lines = lines[1:]
    body = "\n".join(lines).strip()
    # Footer = the sign-off block: everything from the last blank-line-separated
    # chunk that contains the opt-out line.
    chunks = re.split(r"\n\s*\n", body)
    core = [c for c in chunks if not FOOTER_START.search(c)]
    if len(core) > 1 and len(core) < len(chunks):
        core = core[:-1]  # drop the name/business sign-off that sits above it
    return subject, "\n\n".join(core).strip(), body


def check_email(text, position):
    problems = []
    subject, core, full = split_body(text)
    low = (subject + "\n" + full).lower().replace("\u2019", "'").replace("\u2018", "'")
    words = len(re.findall(r"[A-Za-z0-9'$%]+", core))
    limit = LIMITS[min(position, 2)]
    if words > limit:
        problems.append(f"{words} words, limit is {limit} (footer not counted)")
    opening = core.strip()
    # Skip a greeting line ("Hi Maria," / "Hey Dr. W,") and check the first real sentence.
    opening = re.sub(r"^(hi|hey|hello|dear|good (morning|afternoon))\b[^,\n]{0,40}[,\n]\s*", "", opening, flags=re.I)
    if re.match(r"^(i|we|i'm|i've|i'd|we're|we've)\b", opening.replace("\u2019", "'"), re.I):
        problems.append('starts with "I" or "We": start with them')
    for p in BANNED:
        if re.search(r"(?<![a-z-])" + re.escape(p) + r"(?![a-z-])", low):
            problems.append(f'uses "{p}"')
    if LONG_DASH in full or EN_DASH in full or "--" in full or re.search(r"\w - \w", full):
        problems.append("has a long dash: use a full stop or comma")
    if "!" in core:
        problems.append("has an exclamation mark")
    caps = [w for w in re.findall(r"\b[A-Z]{4,}\b", core) if w not in ("HVAC", "ASAP")]
    if caps:
        problems.append("all-caps words: " + ", ".join(sorted(set(caps))))
    questions = core.count("?")
    if questions == 0 and position == 0:
        problems.append("no question: email 1 should ask one real question")
    if questions > 1:
        problems.append(f"{questions} questions: keep it to one")
    if position == 0 and URL.search(core):
        problems.append("has a link: leave links out of the first email")
    gaps = GAP.findall(full)
    if gaps:
        problems.append("unfilled gaps: " + ", ".join(gaps))
    if not FOOTER_START.search(full):
        problems.append('no opt-out line ("Not the right fit? Reply ...")')
    else:
        tail = full[max(0, FOOTER_START.search(full).start() - 300):FOOTER_START.search(full).start()]
        if not re.search(r"\d", tail):
            problems.append("footer has no postal address above the opt-out line")
    if subject:
        s = subject.lower()
        if s.startswith(("re:", "fwd:", "fw:")):
            problems.append('subject fakes a "re:" or "fwd:"')
        if len(subject.split()) > 5:
            problems.append("subject over 5 words")
        if subject != subject.lower():
            problems.append("subject should be lowercase")
    else:
        problems.append("no subject line (first line: Subject: ...)")
    return words, problems


def main():
    if len(sys.argv) > 1:
        try:
            raw = open(sys.argv[1], encoding="utf-8").read()
        except OSError as e:
            print(f"Can't open {sys.argv[1]}: {e.strerror}. Save your emails to a text file first.")
            return 2
    else:
        raw = sys.stdin.read()
    sets = [s for s in re.split(r"^\s*===\s*$", raw, flags=re.M) if s.strip()]
    total_bad = 0
    n = 0
    for s in sets:
        emails = [e for e in re.split(r"^\s*---\s*$", s, flags=re.M) if e.strip()]
        for pos, e in enumerate(emails):
            n += 1
            words, problems = check_email(e, pos)
            label = ["email 1", "follow-up 1", "follow-up 2"][min(pos, 2)]
            first = e.strip().splitlines()[0][:60]
            if problems:
                total_bad += 1
                print(f"FIX  #{n} ({label}, {words} words): {first}")
                for p in problems:
                    print(f"     - {p}")
            else:
                print(f"OK   #{n} ({label}, {words} words): {first}")
    if n == 0:
        print("No emails found. Separate emails with a line of --- and businesses with ===.")
        return 1
    print(f"\n{n - total_bad} of {n} clear.")
    return 1 if total_bad else 0


if __name__ == "__main__":
    sys.exit(main())
