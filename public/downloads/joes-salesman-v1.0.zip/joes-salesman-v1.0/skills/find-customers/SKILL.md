---
name: find-customers
description: >-
  Finds real businesses that match the user's dream customer, reads each one's
  website, notes one or two specific things worth mentioning, and scores how
  well each fits, with the reason. Saves the list to the user's prospect list.
  Use when the user says "find me customers", "find me 10 businesses", "who
  should I email", "score these businesses", or pastes a list of businesses or
  websites to check. Part of Joe's Salesman kit.
---

# Find customers

The job: a short list of real businesses the user could honestly email today, each with a reason and one specific detail from their own website. Quality over volume. Ten good ones beat a hundred guesses.

## Before you start

Read the offer notes (`KIT_HOME/my-offer.md` in Claude Code, or the `# My offer` block in this chat or project). If they're empty, say so and run the `salesman-setup` interview first.

## Step 1: Find candidates

Default batch: 10 businesses. The user can ask for more, up to 25 at a time.

- If you have web search, search for businesses that match the dream customer and area (for example "family dentist Austin TX"). Prefer each business's own website over directories.
- If you don't have web search, ask the user to paste a list: business names, or a copy of Google Maps results, or website addresses. Then work from that.
- Skip directories and lists (Yelp, Yellow Pages, "top 10" articles), chains and franchises unless the user wants them, and anything in the "Rule out" list.
- Skip anything already in the prospect list (`KIT_HOME/prospects.md`), including ones marked `ruled out`, so nobody gets checked or emailed twice.
- Only open website addresses you found in search results or that the user gave you. Never guess a web address: a guessed domain can land on a spam site.
- Stick to the area rule in the offer notes. If a business is on the edge of the area, say so in "Why it fits" rather than deciding quietly.

## Step 2: Read each website

Open the homepage and, if they exist, the about, team, services, booking and contact pages. Look for things that connect to what the user sells, such as:

- Who runs it (an owner or manager named on the site).
- How customers book or buy (online booking, a form, phone only).
- Signs they spend on growth (a recent blog, job openings, an "as seen in" section, a new location).
- Gaps the user's offer fixes (no online booking, an old copyright year in the footer, no reviews on the site, a broken page).
- The best published way to reach them: an email address printed on the site, or the contact form address.

Rules:

- Only write down what you actually saw on the page. If a page didn't load, write "couldn't read the site" and move on. Never fill gaps with guesses.
- Never guess or make up an email address (no "info@ probably works"). If none is published, write "contact form: <page link>", "phone only" or "none found". Tell the user that these need a different first step (fill in the form, or call).
- Never use personal social media accounts or anything behind a login.

## Step 3: Score

Score each business 1 to 100 against the "Great fit" and "Rule out" lists in the offer notes:

- 80 to 100: matches the dream customer, and you found a specific detail the offer helps with.
- 60 to 79: good match, but weaker detail or no named person.
- 40 to 59: partial match. Worth a look, not a first email.
- Below 40: poor match. Leave it off the email list.

Score low (below 20) if it's a competitor, a big company with no clear person to reach, or the site looks abandoned.

Missing information lowers the score. Don't score high on a hunch.

## Step 4: Show and save

Show one table of the businesses that fit, best first. Don't pad the list: if only 3 of the 10 you checked fit, show 3 and say how many you ruled out and the main reason ("7 already have online booking"). Then offer to look for more.

| # | Business | Website | Who decides | Fit (1-100) | Why it fits | Detail to mention | How to reach |

"Why it fits" is one short line. "Detail to mention" is one specific, checkable thing from their site, written so it could go in an email.

Then save it:

- Claude Code: add the rows to `KIT_HOME/prospects.md` with status `found` and today's date, and add the ones you ruled out with status `ruled out` and the reason in Notes. Never delete rows that are already there.
- Claude app: give the table in one copyable block and say "Keep this somewhere safe. Paste it back in next time so I don't suggest the same businesses twice."

End with: "Want emails for the top ones? Say: write emails for 1, 2 and 3."
