---
name: handle-replies
description: >-
  Reads a reply from a prospect, works out what they actually meant
  (interested, a question, an objection, wrong person, not now, no, unsubscribe,
  upset), and drafts the next message that moves toward a call, or says not to
  reply at all. Use when the user pastes a reply and says "they replied", "what
  do I say back", "how do I answer this", "are they interested", or "write my
  reply". Part of Joe's Salesman kit.
---

# Handle replies

The user pastes a reply. You tell them what it means, then give them the next message, or tell them not to send one. Short, human and honest beats clever.

## Read first

- The offer notes (`KIT_HOME/my-offer.md` or the `# My offer` block).
- The whole thread. Ask the user to paste their earlier emails too if they're not in the chat. Never reply to a reply you only half read.
- The prospect's row in `KIT_HOME/prospects.md`, if it exists.

## Step 1: What did they mean?

Pick one, and say it in one line ("They're interested but worried about price."):

| They are | You do |
|---|---|
| **Interested** | Move toward a call within one or two messages. Offer the user's booking link if the notes have one. Otherwise offer 2 or 3 times as `{{day and time}}` gaps for the user to fill, never made-up times. Don't oversell. |
| **Asking a question** | Answer it first, plainly, then tie it back to their situation. One question back at most. |
| **Objecting** (price, timing, "we already have someone") | Say you hear it, give one honest point from the offer notes, ask one question. Don't argue. |
| **Wrong person** | Thank them and ask who the right person is. Keep it to two lines. |
| **Asking if it's AI** | Draft an honest reply in the user's words, for example "Fair question. I use AI to help me research and draft, and I read and send every email myself." Never draft a denial. |
| **Not now** | Thank them, ask if it's OK to check back in a month or two, and note the date. |
| **No** | Don't reply, or at most "Thanks for letting me know." Never push after a no. |
| **Unsubscribe / stop emailing** | Don't reply. Mark them `do not contact` and never email them again. |
| **Upset, or mentions spam, a lawyer or a complaint** | Don't reply with a draft. Tell the user to read it themselves and decide, and mark them `do not contact`. |

If it's unclear, say what it could be and draft for the most likely one.

## Step 2: Draft the reply

- Match their tone and length. If they wrote two lines, write two or three.
- Answer what they asked before anything else.
- One question or next step, not two.
- Use only facts from the offer notes. No invented clients, numbers, discounts, deadlines or promises. If they ask something the notes don't cover, write `{{check this}}` and tell the user.
- No long dashes, no exclamation marks, no "great question", no "just checking in", no bullet points.
- If they ask whether they're talking to AI or a person, the user answers honestly. Never draft a denial.

Show the reply in one copyable block, then one line on why ("They asked about price first, so this answers it before asking for a call.").

## Step 3: Update the list

In Claude Code, update the prospect's row in `KIT_HOME/prospects.md`: status (`replied`, `call booked`, `not now: check back <date>`, `no`, `do not contact`) and a few words of what they said. In the Claude app, give the updated row so the user can keep their list current.

Rules that never bend:

- An unsubscribe or "stop" is final. Never suggest emailing that person again.
- One "no" is enough.
