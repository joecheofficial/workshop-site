---
name: salesman-setup
description: >-
  Sets up Salesman: a short interview about what the user sells, who their
  dream customer is, where those customers are, and how the user writes. Saves
  it as the offer notes every other Salesman skill reads. Use when the user
  says "set up Salesman", "set up my offer", "who should I sell to", "change
  my dream customer", or when another Salesman skill finds the offer notes
  empty. Part of Joe's Salesman kit.
---

# Salesman setup

Salesman finds businesses that fit the user's dream customer, reads their websites, and drafts emails the user sends themselves. All of that depends on one page of notes. This skill writes that page once and updates it when the user's offer changes.

## Where the offer notes live

- Claude Code: `KIT_HOME/my-offer.md`.
- Claude app: the user's project instructions, or earlier in this chat, in a block that starts with `# My offer`.

The notes count as empty if they're missing or still full of `[Example: ...]` lines.

## The interview

Keep it to one message of questions, not ten rounds. If the user already answered some of these, skip those.

1. What do you sell, and roughly what does it cost? (One sentence is fine. "Websites for dentists, from $2,000.")
2. What does a customer get out of it, in their words, not yours?
3. Any true results you're happy to mention? ("None yet" is a fine answer.)
4. Who is your dream customer? Type of business, size, and the person who says yes (owner, office manager, marketing lead).
5. Where are they? A city, a region, or "anywhere online".
6. What makes a business a great fit, and what rules one out? (Examples: "they run ads but have no online booking", "no chains", "no one already working with an agency".)
7. Paste one or two emails you wrote yourself to a customer or a friend. Unedited is better.
8. Your name, business name, and the business address that goes at the bottom of your emails. (Many countries' email laws, including the US's CAN-SPAM, need a real postal address on a sales email.)

## Write the notes

Fill in the template headings (`KIT_HOME/my-offer.md` in Claude Code). Rules:

- Use the user's own words for the offer and the results. Never add a result, client name or number they didn't give you.
- If they have no results yet, write "None yet. Never mention a result." under results, so no email ever invents one.
- Turn question 6 into a short "Great fit" list and a "Rule out" list. These become the scoring rules in `find-customers`.
- From the pasted emails, write 3 to 5 plain lines on how they write: sentence length, how formal, how they open and sign off, words they use. Base it on the samples, not on what they say about themselves.
- Write the area as a clear rule (for example "Austin city limits plus 15 miles, Cedar Park yes, San Antonio no"), so `find-customers` knows what's in and out.
- If anything important is missing (no price, no area), write `{{ask me}}` there rather than guessing.

## Save it

- Claude Code: write the file to `KIT_HOME/my-offer.md` and show a short summary of what you saved.
- Claude app: show the whole thing in one copyable block and say: "Paste this into your Claude Project's instructions, so every chat in that project knows your offer."

Then offer one next step: "Want me to find your first 10 businesses? Say: find me customers."
