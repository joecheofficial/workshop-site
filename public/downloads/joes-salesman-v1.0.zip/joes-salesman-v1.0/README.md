# Joe's Salesman

A free Claude kit that helps you find customers and write the first email. It finds real businesses that fit your dream customer, reads their websites, tells you why each one fits, drafts a short email about something specific it found, and helps you answer every reply.

It drafts. You read every email and send it yourself, from your own inbox.

## What's inside

| Skill | Say this | What it does |
|---|---|---|
| `salesman-setup` | "Set up Salesman" | A one-message interview: what you sell, who your dream customer is, where they are, how you write. Saved as `my-offer.md`. |
| `find-customers` | "Find me customers" | Finds 10 businesses that fit, reads each website, scores the fit out of 100 with the reason and one detail worth mentioning. Saved to `prospects.md`. |
| `write-emails` | "Write emails for 1, 2 and 3" | A first email under 75 words plus two short follow-ups, in your voice, then a pre-send check for spammy and AI-sounding wording and the legal footer. You still check the facts yourself. |
| `handle-replies` | "They replied: ..." | Works out what they meant and drafts the next message, or tells you not to reply (a "no" or "unsubscribe" is final). |

## Three ways to use it

1. **Claude Code:** unzip, open a terminal in the folder, run `bash install.sh`, restart Claude Code, then say "Set up Salesman".
2. **Claude app (claude.ai or desktop):** go to Settings, Capabilities, Skills, and upload each zip in the `claude-app` folder. Turn on web search so it can find businesses. Then say "Set up Salesman".
3. **No install:** open `START-HERE-PROMPT.md`, copy the prompt into any new Claude chat.

## What it won't do

- It never sends an email for you, and never says it did.
- It never makes up a client, number, or email address. If it doesn't know, it asks you.
- It never emails someone twice by mistake: the prospect list keeps everyone it already found.
- It doesn't use LinkedIn or anything behind a login.

## Before you send

- Fill in your real postal address. Many countries' laws (including the US's CAN-SPAM) require it on a sales email, plus an easy way to say no. The footer handles both.
- Send 10 to 20 a day by hand from your normal inbox. To send a lot more, use a separate domain with SPF, DKIM and DMARC set up and warm it up for a few weeks first.
- Be honest if anyone asks whether AI helped.

This isn't legal advice. If you sell into a regulated industry, check the rules where you and your customers are.

Made by Joe Che, Masterminds HQ. Inspired by the open-source Harvey project (see CREDITS.md).
