# MHQ FX Pack: 20 video effects for your own talking video

The same 20 effects from Joe Che's "20 video effects in 20 seconds, built by Claude" reel.
You give it a video of you talking, it gives you that video back with all 20 effects on it.
Every effect is a short program Claude wrote. Free from Masterminds HQ, MIT licence.

## What you need
- A Mac (it uses Apple's own on-device tool to cut you out of the background).
- A vertical video of you talking: camera still, you in the middle, 20 to 40 seconds.
- Claude Code (easiest), or Terminal if you are happy typing commands.

## The easy way: let Claude do it
Open Claude Code in this folder and paste:

> Read SKILL.md and README.md in this folder. Check my Mac has what make.sh needs and install what is missing
> (ask me before installing anything). Then ask me for my name, Instagram handle and comment keyword, put them
> in config.json, and run ./make.sh on my video: (drag your video file here).

## The Terminal way
1. Install the tools once: Homebrew (brew.sh), then `brew install ffmpeg node python` and
   `python3 -m pip install numpy pillow scipy fonttools`. Xcode command line tools: `xcode-select --install`.
2. Open `config.json` and put in your name, handle, keyword and your own numbers.
3. Run `./make.sh my-video.mp4`. The first run installs Remotion (about a minute).
4. Your video is at `out/fx-video.mp4`. The sound is your original sound, untouched.

## The 20 effects
Live cursor, Clone row, Day dial, Predict keys, Orbit ring, Code body, Post wall, Letter dive,
Comment drop (your keyword), Layer explode, Sketch words, Blade slice, Head stack, Rack focus,
Banknote, Voice note, Impact frame, Dolly zoom, Press front, Paper tear, Blow away.

## Good to know
- The effects are spread evenly over your video. Want each one to start on the word that names it?
  Ask Claude: "retime the effects to my words" (it is in SKILL.md).
- Want only some effects? Ask Claude: "keep only clone row, orbit ring and blow away".
- Everything runs on your Mac. Nothing is uploaded, no account, no API key.
- Busy backgrounds and a moving camera make the cut-out messier. A plain wall works best.
- Rendering takes a few minutes. The cut-out step takes about a minute per 30 seconds of video.
