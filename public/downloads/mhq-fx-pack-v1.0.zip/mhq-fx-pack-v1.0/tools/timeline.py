#!/usr/bin/env python3
"""Spread the 20 effects over YOUR video: scales the reference timing (25.44 s reel) to your video length.
Usage: tools/timeline.py <seconds>   -> studio/src/timeline.json
Want each effect to start on a word? Ask Claude: "retime the effects to my words" (see SKILL.md)."""
import json, os, sys
J = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ref = json.load(open(os.path.join(J, "tools", "timeline-ref.json")))
dur = float(sys.argv[1]); k = dur / ref[-1]["end"]
if dur < 15: print(f"note: {dur:.1f} s is short, each effect gets {dur/21:.2f} s (20 s or more looks best)")
out = [dict(it, start=round(it["start"] * k, 2), end=round(it["end"] * k, 2)) for it in ref]
json.dump(out, open(os.path.join(J, "studio", "src", "timeline.json"), "w"), indent=1)
print(f"timeline: {len(out)} pieces over {dur:.2f} s")
