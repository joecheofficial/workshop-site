#!/usr/bin/env python3
"""Move the speaker left so the effects list on the right never covers their face (the reel puts the head at
x ~431). How far = median head centre - 431, 0..200 px. Prints the shift; with --apply also fixes track.json.
The video and mattes are shifted by make.sh with the same crop + mirrored edge (no hard line where the body ends).
Usage: shift-left.py <job> [--apply L]"""
import json, os, statistics, sys
J = sys.argv[1]; tp = os.path.join(J, "studio", "src", "track.json"); t = json.load(open(tp))
if "--apply" not in sys.argv:
    print(max(0, min(200, int(statistics.median(r[1] for r in t) - 431)))); sys.exit()
L = int(sys.argv[sys.argv.index("--apply") + 1])
for r in t:
    r[1] -= L; r[4] = max(0, r[4] - L); r[5] = 1079 if r[5] >= 1079 else max(0, r[5] - L)
json.dump(t, open(tp, "w")); print("shifted left", L, "px")
