#!/usr/bin/env python3
"""Voice-note avatar: Joe smiling at the lens (cut-out frame) on a mint circle, like the reference's round avatar.
Usage: voice-note-avatar.py <job-dir> [frame=101]"""
import sys, os
import numpy as np
from PIL import Image, ImageDraw
job = sys.argv[1]; n = int(sys.argv[2]) if len(sys.argv) > 2 else 101
im = Image.open(os.path.join(job, "media/cut", f"{n:05d}.png")).convert("RGBA")
# head + shoulders square (raw HeyGen coords) from the head track: same proportions as the close-up crop
# (square = 2.04 face widths, centred 0.27 face widths below the face centre)
import json
t = json.load(open(os.path.join(job, "studio/src/track.json")))[n - 1]
half = round(1.02 * t[2]); cx = round(t[1]); cy = round((t[0] + t[3]) / 2 + 0.27 * t[2])
crop = im.crop((cx - half, cy - half, cx + half, cy + half)).resize((512, 512), Image.LANCZOS)
S = 512
bg = Image.new("RGBA", (S, S), (114, 217, 160, 255))  # mint, sampled from the ref avatar
bg.alpha_composite(crop)
mask = Image.new("L", (S * 4, S * 4), 0)
ImageDraw.Draw(mask).ellipse((0, 0, S * 4 - 1, S * 4 - 1), fill=255)
mask = mask.resize((S, S), Image.LANCZOS)
out = Image.new("RGBA", (S, S), (0, 0, 0, 0)); out.paste(bg, (0, 0), mask)
dst = os.path.join(job, "studio/public/voice-note/avatar.png"); out.save(dst); print(dst)
