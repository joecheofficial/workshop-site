#!/usr/bin/env python3
"""Clean plate for the approved STUDIO take (plain dark grey backdrop, no desk, no clock).
1. Temporal median of raw/main.mp4 where Joe's matte (dilated) is absent = exact backdrop, exact light.
2. Pixels Joe never leaves: multi-scale normalised convolution from the known backdrop (a studio backdrop is a
   smooth gradient, so this is exact enough), plus matched grain.
Writes studio/public/plate-b.png (1080x1920), plate.png ((1080+EXT)x1920, right side mirrored) and an empty
front.png (nothing stands in front of Joe in the studio).
Usage: studio-plate.py <job> [EXT=200] [step=3]"""
import os, sys, subprocess, tempfile
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
J = sys.argv[1]; EXT = int(sys.argv[2]) if len(sys.argv) > 2 else 200; STEP = int(sys.argv[3]) if len(sys.argv) > 3 else 3
T = tempfile.mkdtemp()
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{J}/raw/main.mp4", "-vf", f"select='not(mod(n\\,{STEP}))'", "-fps_mode", "passthrough", f"{T}/%05d.png"], check=True)
fs = sorted(os.listdir(T)); A = []; V = []
for i, f in enumerate(fs):
    n = i * STEP + 1
    A.append(np.asarray(Image.open(f"{T}/{f}").convert("RGB"), np.float32))
    m = np.asarray(Image.open(f"{J}/mask/{n:05d}.png").convert("L")) > 6
    V.append(~ndi.binary_dilation(m, iterations=18))
A = np.stack(A); V = np.stack(V); cnt = V.sum(0)
med = np.nanmedian(np.where(V[..., None], A, np.nan), 0)
known = cnt >= max(6, len(fs) // 8)
plate = np.nan_to_num(med)
# smooth backdrop model: per-channel cubic surface fitted on the known backdrop, evaluated with y held at the last row that still has backdrop (below that his body
# fills the frame, so hold the light instead of extrapolating), clamped to the known range
H0, W0 = known.shape
yy, xx = np.mgrid[0:H0, 0:W0].astype(np.float32)
rowk = known.mean(1); ylast = int(np.nonzero(rowk > 0.05)[0].max())
def basis(x, y):
    x = x / W0 - 0.5; y = y / H0 - 0.5
    return np.stack([x ** i * y ** j for i in range(4) for j in range(4) if i + j <= 3], -1)
sel = known.copy()
ii = np.nonzero(sel.ravel())[0]; ii = ii[::max(1, len(ii) // 60000)]
Bf = basis(xx.ravel()[ii], yy.ravel()[ii])
Be = basis(xx, np.minimum(yy, ylast)).reshape(-1, Bf.shape[1])
model = np.zeros_like(plate)
for c in range(3):
    v = plate[..., c].ravel()[ii]
    coef, *_ = np.linalg.lstsq(Bf, v, rcond=None)
    model[..., c] = np.clip((Be @ coef).reshape(H0, W0), v.min(), v.max())
# the real backdrop's local difference from the model, carried a little way into the hole (keeps matte edges exact)
fill = model.copy()
wk = ndi.gaussian_filter(known.astype(np.float32), 24)
for c in range(3):
    r = ndi.gaussian_filter(np.where(known, plate[..., c] - model[..., c], 0), 24)
    fill[..., c] += r / (wk + 0.08)
print("model ylast", ylast)
hp = plate - ndi.gaussian_filter(plate, (3, 3, 0)); sd = float(hp[known].std())
# the known backdrop is used low-passed (model + its smooth residual): a studio wall has no detail, and the raw
# median carries thin matte-edge lines and compression blocks that show on the empty ending (blow-away)
wk10 = ndi.gaussian_filter(known.astype(np.float32), 10)
kn = model.copy()
for c in range(3):
    kn[..., c] += ndi.gaussian_filter(np.where(known, plate[..., c] - model[..., c], 0), 10) / np.maximum(wk10, 1e-3)
k = ndi.gaussian_filter(ndi.binary_erosion(known, iterations=12).astype(np.float32), 8)[..., None]
pb = kn * k + fill * (1 - k)
pb = np.clip(pb + np.random.default_rng(5).normal(0, sd, pb.shape[:2])[..., None], 0, 255)
Image.fromarray(pb.astype(np.uint8)).save(f"{J}/studio/public/plate-b.png")
H, W, _ = pb.shape
ext = pb[:, W - 1 - np.arange(EXT), :] * (1 - 0.12 * (np.arange(EXT) / EXT))[None, :, None]
out = np.concatenate([pb, ext], 1)
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).save(f"{J}/studio/public/plate.png")
Image.new("RGBA", (out.shape[1], out.shape[0]), (0, 0, 0, 0)).save(f"{J}/studio/public/front.png")
print("plate", out.shape[1], "x", out.shape[0], "known", round(float(known.mean()), 3), "grain", round(sd, 2))
