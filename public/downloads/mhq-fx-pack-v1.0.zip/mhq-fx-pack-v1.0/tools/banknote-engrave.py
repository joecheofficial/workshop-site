#!/usr/bin/env python3
"""Banknote portrait engraving (our build, 23 Nov 2026), modelled on the ref banknote portrait (ref/15-banknote):
 - one main family of fine lines that run across the face and BEND with the form (displaced by smoothed brightness +
   a spherical bulge over the head, so they arc over forehead, cheeks and cap), line WIDTH follows darkness, lines
   break up into white in the highlights;
 - a second family crossing at ~55 deg only in the shadows (cross-hatch), a third very dark-only family for the
   deepest shadows (hair, beard, collar), crisp feature edges from an unsharp-masked tone map;
 - the background inside the oval is the classic dark guilloche field: fine concentric ovals with light radial ticks;
 - rendered 3x supersampled, anti-aliased, then downsampled: green ink on paper, oval alpha.
Usage: banknote-engrave.py <job-dir> <out-dir> <first_file_no> <last_file_no> [--swap a:b,...] [--size W,H]
       (file numbers are media/cut NNNNN.png, 1-based = abs frame + 1)
"""
import os, sys
import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

INK = np.array([30, 52, 40], np.float32)
PAPER = np.array([241, 238, 226], np.float32)

def smoothstep(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)

# portrait framing (final px, measured on the approved close-up build): head top at y ~98, face centre at the
# oval centre, face width 317 px. MAP = (sc, ox, oy) raw -> portrait, set in main() from the head track.
MAP = [0.6867, 530.0, 230.0]

def engrave(rgba, W, H, SS=3, spacing=4.6):
    """rgba: raw HeyGen frame (1080x1920 RGBA, alpha = Joe matte). Returns RGBA W x H (oval alpha)."""
    w, h = W * SS, H * SS
    sc, ox, oy = MAP
    tx, ty = W / 2.0, 92.0 * (H / 816.0)
    # crop + resize the raw frame into portrait space at SS
    x0 = ox - tx / sc; y0 = oy - ty / sc
    box = (x0, y0, x0 + W / sc, y0 + H / sc)
    src = rgba.transform((w, h), Image.EXTENT, box, Image.BICUBIC)
    a = np.asarray(src, np.float32) / 255.0
    rgb, m = a[..., :3], a[..., 3]
    m = ndimage.gaussian_filter(m, 1.2 * SS)
    L = rgb @ np.array([0.30, 0.55, 0.15], np.float32)
    # tone: stretch on Joe only, lift local contrast (large unsharp) and crisp features (small unsharp)
    jm = m > 0.5
    lo, hi = np.percentile(L[jm], 1.5), np.percentile(L[jm], 99.2)
    T = np.clip((L - lo) / max(hi - lo, 1e-3), 0, 1)
    Tb = ndimage.gaussian_filter(T, 1.0 * SS)
    big = ndimage.gaussian_filter(Tb, 22 * SS)
    T2 = np.clip(Tb + 0.45 * (Tb - big), 0, 1)
    small = ndimage.gaussian_filter(T2, 3.0 * SS)
    T3 = np.clip(T2 + 0.9 * (T2 - small), 0, 1)
    T3 = T3 ** 0.97
    # ---- main line family: horizontal-ish, bent by the form ----
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    X, Y = xx / SS, yy / SS  # final px coords
    cx, cy = W / 2.0, H * 0.40
    # spherical bulge over the head (lines arc over the forehead / cap), weaker on the body
    rx, ry = W * 0.26, H * 0.27
    q = np.clip(1 - ((X - cx) / rx) ** 2 - ((Y - cy) / ry) ** 2, 0, 1)
    bulge = -15.0 * np.sqrt(q)
    form = ndimage.gaussian_filter(T3, 7 * SS)  # smooth brightness -> displacement (lines ride over the form)
    disp = bulge + 15.0 * (form - 0.5) + 2.2 * np.sin(X / 37.0 + Y / 90.0)
    ph1 = (Y + disp) / spacing
    d1 = np.abs(ph1 - np.round(ph1)) * spacing  # px distance to nearest line centre (approx.)
    dark = 1 - T3
    w1 = spacing * (0.05 + 0.9 * dark ** 1.08)  # line width follows darkness
    aa = 0.55
    ink1 = smoothstep(-aa, aa, w1 / 2 - d1) * smoothstep(0.0, 0.7, w1)
    ink1 *= smoothstep(0.07, 0.2, dark)  # highlights break into white
    # ---- cross-hatch in the shadows ----
    ang = np.deg2rad(57)
    ph2 = (X * np.cos(ang) + Y * np.sin(ang) + 0.5 * disp) / (spacing * 0.92)
    d2 = np.abs(ph2 - np.round(ph2)) * spacing * 0.92
    w2 = spacing * 0.92 * np.clip((dark - 0.55) / 0.45, 0, 1) ** 0.9 * 0.75
    ink2 = smoothstep(-aa, aa, w2 / 2 - d2) * smoothstep(0.0, 0.7, w2)
    ang3 = np.deg2rad(-35)
    ph3 = (X * np.cos(ang3) + Y * np.sin(ang3)) / (spacing * 0.85)
    d3 = np.abs(ph3 - np.round(ph3)) * spacing * 0.85
    w3 = spacing * 0.85 * np.clip((dark - 0.72) / 0.28, 0, 1) * 0.8
    ink3 = smoothstep(-aa, aa, w3 / 2 - d3) * smoothstep(0.0, 0.7, w3)
    # crisp feature edges (eyes, brows, nostrils, lips): thin dark contour where tone changes fast
    g = ndimage.gaussian_gradient_magnitude(ndimage.gaussian_filter(T2, 1.4 * SS), 1.0 * SS)
    g = g / max(np.percentile(g[jm], 99.3), 1e-4)
    edge = smoothstep(0.55, 1.0, g) * smoothstep(0.25, 0.55, dark + 0.2)
    joe_ink = np.clip(np.maximum(np.maximum(ink1, ink2), np.maximum(ink3, edge * 0.9)), 0, 1)
    # ---- background inside the oval: dark concentric guilloche + light radial ticks ----
    ex, ey = (X - W / 2) / (W / 2), (Y - H / 2) / (H / 2)
    r = np.sqrt(ex ** 2 + ey ** 2) * (W / 2)
    th = np.arctan2(ey, ex)
    phb = r / 3.4
    db = np.abs(phb - np.round(phb)) * 3.4
    bg = smoothstep(-aa, aa, 0.36 - db)  # thin cream rings (0.7 px) between dark ink => mostly dark
    bg = 1 - bg
    rad = np.abs(((th / (2 * np.pi)) * 420) % 1 - 0.5) * 2  # 420 radial ticks
    bg = bg * (1 - 0.35 * smoothstep(0.84, 0.98, rad))
    # vignette the field slightly lighter towards the rim (like the ref)
    bg = bg * (0.88 + 0.12 * np.clip(1 - r / (W / 2), 0, 1))
    ink = joe_ink * m + bg * (1 - m)
    # oval alpha
    # oval alpha: exactly the base art's inner rim (outer ellipse 408x548 minus a 100 px radial rim), 1 px overlap
    ddx, ddy = X - W / 2, Y - H / 2
    rr = np.sqrt(ddx ** 2 + ddy ** 2) + 1e-6
    ph = np.arctan2(ddy, ddx)
    rim = 408 * 548 / np.sqrt((548 * np.cos(ph)) ** 2 + (408 * np.sin(ph)) ** 2) - 100 + 1.0
    oval = smoothstep(0.8, -0.8, rr - rim)
    col = PAPER[None, None, :] * (1 - ink[..., None]) + INK[None, None, :] * ink[..., None]
    out = np.dstack([col, oval[..., None] * 255]).astype(np.uint8)
    return Image.fromarray(out, "RGBA").resize((W, H), Image.LANCZOS)

def main():
    job, outdir, a, b = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    swap = {}
    if "--swap" in sys.argv:
        for kv in sys.argv[sys.argv.index("--swap") + 1].split(","):
            k, v = kv.split(":"); swap[int(k)] = int(v)
    W, H = 618, 898
    if "--size" in sys.argv:
        W, H = map(int, sys.argv[sys.argv.index("--size") + 1].split(","))
    os.makedirs(outdir, exist_ok=True)
    # fixed camera for the window: median head box (raw px) -> face 317 px wide, top at ~98, centred
    import json
    tr = json.load(open(os.path.join(job, "studio/src/track.json")))
    rows = np.array([tr[min(len(tr) - 1, k - 1)] for k in range(a, b + 1)])
    top, cx, hw = float(np.median(rows[:, 0])), float(np.median(rows[:, 1])), float(np.median(rows[:, 2]))
    sc = 317.0 * (W / 618.0) / hw
    MAP[:] = [sc, cx, top + 3.4 / sc]
    print("portrait map", [round(v, 3) for v in MAP])
    for n in range(a, b + 1):
        src = swap.get(n, n)
        rgba = Image.open(os.path.join(job, "media/cut", f"{src:05d}.png")).convert("RGBA")
        im = engrave(rgba, W, H)
        p = os.path.join(outdir, f"{n:05d}.png"); im.save(p); print(p, "<-", src)

if __name__ == "__main__":
    main()
