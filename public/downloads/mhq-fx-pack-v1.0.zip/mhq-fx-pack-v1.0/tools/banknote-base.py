#!/usr/bin/env python3
"""Banknote base art (static layer) for the 9:16 banknote, modelled detail for detail on ref/15-banknote:
cream paper, thin rounded outer frame, guilloche side bands (woven sinusoids + bold chain), a wavy moire line field,
the portrait oval rim (zig-zag lattice band, fine mesh band, cream text band), two spirograph rosettes, rope-bordered
corner / serial / note boxes and the double-line number box. All drawn as anti-aliased distance fields at 2x.
Text, numbers and the portrait are layered on top in Remotion (banknote.tsx), so they stay crisp and animate.
Usage: banknote-base.py <out.png>   (layout constants shared with banknote-layout.ts)
"""
import sys, json
import numpy as np
from PIL import Image

SS = 2
W, H = 1080, 1920
INK = np.array([34, 56, 44], np.float32)
PAPER = np.array([243, 237, 223], np.float32)
BOXP = np.array([240, 237, 225], np.float32)


yy, xx = np.mgrid[0:H * SS, 0:W * SS].astype(np.float32)
X = (xx + 0.5) / SS; Y = (yy + 0.5) / SS
AA = 0.5

def ss(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)

def line(d, w):
    """coverage of a line of width w (px) given distance d (px) to its centre"""
    return ss(-AA, AA, w / 2 - np.abs(d)) * ss(0, 0.6, w)

def rrect_sdf(x0, y0, x1, y1, r):
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    hx, hy = (x1 - x0) / 2 - r, (y1 - y0) / 2 - r
    qx, qy = np.abs(X - cx) - hx, np.abs(Y - cy) - hy
    return np.sqrt(np.maximum(qx, 0) ** 2 + np.maximum(qy, 0) ** 2) + np.minimum(np.maximum(qx, qy), 0) - r

def inside(sdf):
    return ss(AA, -AA, sdf)

def periodic(v, p):
    """distance to nearest multiple of p"""
    return np.abs(v - p * np.round(v / p))

# ---------------- layout ----------------
LY = dict(
    frame=(23, 23, 1057, 1897, 28),
    top=(40, 40, 150), bot=(1740, 1870),
    boxL=(40, 372), boxR=(708, 1040), serial=(405, 50, 675, 140), note=(397, 1752, 683, 1858),
    band=(40, 88, 992, 1040), bandY=(150, 1740),
    oval=dict(cx=540, cy=742, rx=408, ry=548, lattice=36, mesh=30, text=34),
    ros=dict(r=85, y=1150, xl=180, xr=900, inner=44),
    num=(95, 1252, 985, 1712, 18),
)
paper = np.ones((H * SS, W * SS), np.float32)  # 1 = paper visible (we accumulate ink coverage)
ink = np.zeros_like(paper)
fillcol = None  # per-pixel paper colour override for boxes

def add(cov, alpha=1.0):
    global ink
    ink = np.maximum(ink, np.clip(cov, 0, 1) * alpha)

def erase(mask):
    """clear ink where mask (box interiors etc.)"""
    global ink
    ink = ink * (1 - mask)

# field region: inside the frame, between the bands, between top and bottom rows
fx0, fx1 = LY["band"][1], LY["band"][2]
fy0, fy1 = LY["bandY"]
field = ss(-AA, AA, X - fx0) * ss(-AA, AA, fx1 - X) * ss(-AA, AA, Y - fy0) * ss(-AA, AA, fy1 - Y)
# wavy moire field: two families of fine waves that cross
for sgn, ph in ((1, 0.0), (-1, np.pi)):
    yv = Y + 6.5 * np.sin(2 * np.pi * X / 118.0 + sgn * Y / 52.0 + ph) + 2.0 * np.sin(X / 23.0 + Y / 31.0)
    add(line(periodic(yv, 5.4), 0.62) * field, 0.78)

# side bands
bx0, bx1, bx2, bx3 = LY["band"]
for (a, b) in ((bx0, bx1), (bx2, bx3)):
    reg = ss(-AA, AA, X - a) * ss(-AA, AA, b - X) * ss(-AA, AA, Y - fy0) * ss(-AA, AA, fy1 - Y)
    erase(reg)
    add(reg * 0.16)
    c = (a + b) / 2
    for k in range(12):
        xv = c + 15.5 * np.sin(2 * np.pi * Y / 44.0 + 2 * np.pi * k / 12)
        add(line(X - xv, 1.05) * reg, 1.0)
    for s in (1, -1):
        xv = c + 17.5 * s * np.sin(2 * np.pi * Y / 150.0)
        add(line(X - xv, 2.8) * reg)
    for xe, w in ((a + 1.5, 2.0), (a + 5, 0.9), (b - 5, 0.9), (b - 1.5, 2.0)):
        add(line(X - xe, w) * ss(-AA, AA, Y - fy0) * ss(-AA, AA, fy1 - Y))

# ---------------- oval rim ----------------
O = LY["oval"]
cx, cy = O["cx"], O["cy"]
dx, dy = X - cx, Y - cy
r = np.sqrt(dx ** 2 + dy ** 2) + 1e-6
phi = np.arctan2(dy, dx)
def rb(a, b):
    return a * b / np.sqrt((b * np.cos(phi)) ** 2 + (a * np.sin(phi)) ** 2)
r_out = rb(O["rx"], O["ry"])
s = r - r_out  # <0 inside outer ellipse
latW, meshW, txtW = O["lattice"], O["mesh"], O["text"]
# arc parameter for even teeth: use angle on a circle-ish ellipse param
psi = np.arctan2(dy / O["ry"], dx / O["rx"])
in_lat = ss(-AA, AA, -s) * ss(-AA, AA, s + latW)
erase(ss(-AA, AA, -s))  # clear the field inside the oval
# lattice: a braid of |sine| curves => a ring of pointed diamond teeth on the outer edge (like the ref), dark,
# with light holes; then a fine diagonal cross-hatch mesh band inside it
nT = 40  # x3 interleaved curves => 120 teeth round the oval (ref pitch ~20 px * 1.3)
depth = -s  # 0 at outer edge .. inwards
TEETH = 36.0
for k in range(3):
    ph = np.pi * k / 3
    for A, wid in ((24.0, 1.7), (19.0, 1.2), (14.0, 1.05)):
        c_out = 2.0 + A * np.abs(np.sin(nT * psi / 2 + ph))           # cusps point OUT
        c_in = TEETH - 2.0 - A * np.abs(np.sin(nT * psi / 2 + ph))    # cusps point IN
        add(line(depth - c_out, wid) * ss(-AA, AA, depth + 0.5))
        add(line(depth - c_in, wid * 0.85) * ss(-AA, AA, depth + 0.5))
env = 2.0 + 24.0 * np.min(np.stack([np.abs(np.sin(nT * psi / 2 + np.pi * k / 3)) for k in range(3)]), axis=0)
add(ss(-0.5, 0.8, depth - env) * ss(-AA, AA, TEETH - depth) * 0.45)  # green tint inside the braid
add(line(depth - TEETH, 1.2))
MESH0, MESH1 = TEETH, latW + meshW
in_mesh = ss(-AA, AA, depth - MESH0) * ss(-AA, AA, MESH1 - depth)
arc = psi * 2900 / (2 * np.pi)  # ~ arc length in px along the ring
hatch = np.maximum(line(periodic(arc + depth, 4.4) / 1.414, 0.95), line(periodic(arc - depth, 4.4) / 1.414, 0.95))
add(hatch * in_mesh)
add(in_mesh * 0.12)
add(line(depth - MESH1, 1.3))
# text band: cream with a thin line at its inner edge (letters in Remotion)
d_txt0, d_txt1 = latW + meshW, latW + meshW + txtW
erase(ss(-AA, AA, depth - d_txt0 - 0.6) * ss(-AA, AA, d_txt1 - depth))
add(line(depth - d_txt1, 1.2))

# ---------------- rosettes ----------------
R = LY["ros"]
for xc, kind in ((R["xl"], "text"), (R["xr"], "target")):
    rx_, ry_ = X - xc, Y - R["y"]
    rr = np.sqrt(rx_ ** 2 + ry_ ** 2) + 1e-6
    th = np.arctan2(ry_, rx_)
    zone = ss(-AA, AA, R["r"] + 2 - rr)
    # spirograph petals: loops of small circles on a ring (two interleaved sets)
    acc = np.zeros_like(rr)
    for (M, rc, rs, off) in ((48, 56, 27, 0.0), (48, 61, 21, np.pi / 48)):
        for k in range(M):
            a = 2 * np.pi * k / M + off
            px, py = xc + rc * np.cos(a), R["y"] + rc * np.sin(a)
            dd = np.sqrt((X - px) ** 2 + (Y - py) ** 2)
            acc = np.maximum(acc, line(dd - rs, 0.62))
    add(acc * zone, 0.95)
    erase(ss(-AA, AA, R["inner"] + 1 - rr))
    add(line(rr - R["inner"], 1.8))
    add(line(rr - (R["inner"] - 5), 0.8))
    if kind == "target":
        for rad in (7, 13, 19, 25, 31):
            add(line(rr - rad, 1.3 if rad in (7, 19, 31) else 0.7))
        add(ss(AA, -AA, rr - 3.0))

# ---------------- boxes ----------------
boxcol = np.zeros_like(paper)
def rope_box(x0, y0, x1, y1, r, rope=9.0):
    sd = rrect_sdf(x0, y0, x1, y1, r)
    erase(inside(sd))
    global boxcol
    boxcol = np.maximum(boxcol, inside(sd + rope + 1.5))
    band = ss(-AA, AA, -sd - 1.0) * ss(-AA, AA, sd + rope)
    u = (X + Y) / 1.0; v = (X - Y) / 1.0
    lat = np.maximum(line(periodic(u, 3.8) / 1.414, 1.0), line(periodic(v, 3.8) / 1.414, 1.0))
    add(lat * band, 0.95)
    add(line(sd + 0.6, 1.8))
    add(line(sd + rope + 0.8, 1.1))
    add(line(sd + rope + 4.0, 0.7))

def double_box(x0, y0, x1, y1, r):
    sd = rrect_sdf(x0, y0, x1, y1, r)
    erase(inside(sd))
    global boxcol
    boxcol = np.maximum(boxcol, inside(sd + 2))
    add(line(sd + 0.8, 1.6))
    add(line(sd + 6.5, 0.9))

t0, t1 = LY["top"][1], LY["top"][2]
b0, b1 = LY["bot"]
rope_box(LY["boxL"][0], t0, LY["boxL"][1], t1, 18)
rope_box(LY["boxR"][0], t0, LY["boxR"][1], t1, 18)
rope_box(*LY["serial"], 14, rope=7.5)
rope_box(LY["boxL"][0], b0, LY["boxL"][1], b1, 18)
rope_box(LY["boxR"][0], b0, LY["boxR"][1], b1, 18)
rope_box(*LY["note"], 14, rope=7.5)
double_box(*LY["num"])

# outer frame line (runs behind the boxes: draw only where no box)
fr = LY["frame"]
fsd = rrect_sdf(*fr)
add(line(fsd + 0.8, 2.2) * (1 - boxcol))
add(line(fsd + 5.5, 0.7) * (1 - boxcol) * ss(-AA, AA, -fsd))

col = PAPER[None, None] * (1 - boxcol[..., None]) + BOXP[None, None] * boxcol[..., None]
col = col * (1 - ink[..., None]) + INK[None, None] * ink[..., None]
img = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8), "RGB").resize((W, H), Image.LANCZOS)
img.save(sys.argv[1]); print(sys.argv[1])
