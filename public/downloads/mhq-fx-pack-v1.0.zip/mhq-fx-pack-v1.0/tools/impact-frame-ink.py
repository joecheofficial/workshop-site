#!/usr/bin/env python3.11
"""Impact frame: turn Joe's live cut-out frames into bold manga ink line art (cream paper + black ink).
Not a threshold: edge-preserving smoothing, DoG ink lines on the face, solid black clothes + hair,
shadow pools, speck cleanup, then supersampled smoothing so every contour is a clean brush edge.

Usage: python3.11 tools/impact-frame-ink.py <first_abs_frame> <last_abs_frame> [--debug]
Writes media/impact-frame/NNNNN.png (abs frame, RGBA 1080x1920, PORTRAIT space: drawn full-frame at 0,0).
"""
import os, sys
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

JOB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(JOB, "media", "impact-frame")
os.makedirs(OUT, exist_ok=True)
CREAM = np.array([240, 235, 222], np.float32) / 255
import json
TRACK = json.load(open(os.path.join(JOB, "studio", "src", "track.json")))
INK = np.array([16, 16, 15], np.float32) / 255


def smooth_mask(m, sigma, thr=0.5):
    return ndi.gaussian_filter(m.astype(np.float32), sigma) > thr


def drop_small(m, min_area):
    lab, n = ndi.label(m)
    if n == 0:
        return m
    area = ndi.sum(np.ones_like(lab), lab, index=np.arange(1, n + 1))
    keep = np.zeros(n + 1, bool)
    keep[1:] = area >= min_area
    return keep[lab]


# Portrait space (medium shot, 23 Nov): the panel shows Joe head-and-shoulders BIG like the reference, so every raw
# frame is first resampled with a fixed camera for the window: face width -> P_W px, head top -> P_TOP, face centre
# -> x 540. The ink filters below were tuned at that face size (the old close-up), so they keep working.
P_W, P_TOP, P_CX = 540.0, 340.0, 540.0
CAM = {}

def set_cam(a, b):
    rows = np.array([TRACK[min(f, len(TRACK) - 1)] for f in range(a, b + 1)])
    CAM.update(top=float(np.median(rows[:, 0])), cx=float(np.median(rows[:, 1])), w=float(np.median(rows[:, 2])))
    CAM["k"] = P_W / CAM["w"]

def to_portrait(im):
    k = CAM["k"]
    # output (x, y) -> raw ((x - P_CX) / k + cx, (y - P_TOP) / k + top)
    return im.transform((1080, 1920), Image.AFFINE, (1 / k, 0, CAM["cx"] - P_CX / k, 0, 1 / k, CAM["top"] - P_TOP / k), Image.BICUBIC)

def ink_frame(abs_f):
    a = np.asarray(to_portrait(Image.open(os.path.join(JOB, "media", "cut", f"{abs_f + 1:05d}.png")).convert("RGBA")), np.float32) / 255
    rgb, A = a[..., :3], a[..., 3]
    # exposure: the study take is lit low and from the side; bring the face to the ref's level (skin median ~0.56)
    # so the fixed ink thresholds below read features, not whole shadow sides, as ink
    L0 = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    sk0 = ((rgb[..., 0] - rgb[..., 2]) > 0.06) & (A > 0.5) & (L0 > 0.08)
    if sk0.sum() > 500:
        gain = float(np.clip(0.56 / np.median(L0[sk0]), 1.0, 2.4))
        rgb = np.clip(rgb * gain, 0, 1)
    R, G, B = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    L = 0.299 * R + 0.587 * G + 0.114 * B
    body = smooth_mask(A > 0.5, 2.0)

    # edge-preserving smoothing (median twice + light blur) kills pores/noise but keeps feature edges
    Ls = ndi.median_filter(L, 7)
    Ls = ndi.median_filter(Ls, 5)
    Ls = ndi.gaussian_filter(Ls, 1.0)
    Rs, Bs = ndi.gaussian_filter(R, 3), ndi.gaussian_filter(B, 3)

    warm = (Rs - Bs)
    skin = smooth_mask((warm > 0.07) & body & (Ls > 0.18), 4)
    skin = drop_small(skin, 4000)
    skin = ndi.binary_fill_holes(skin)
    # clothes: the denim shirt is blue (B >= R); hair is dark
    yy = np.arange(L.shape[0])[:, None]
    t = TRACK[min(abs_f, len(TRACK) - 1)]
    top_p = (t[0] - CAM["top"]) * CAM["k"] + P_TOP
    below = yy > (top_p + 0.6 * t[2] * CAM["k"])  # under the hairline band: clothes live here, hair does not
    shirt = smooth_mask((warm < 0.03) & body & ~skin & below, 5)
    shirt = drop_small(shirt, 6000)
    dark = smooth_mask((Ls < 0.17) & body, 2.5)
    fill = shirt | dark

    # face ink: difference of Gaussians on the smoothed luminance (dark side of edges = ink line)
    g1 = ndi.gaussian_filter(Ls, 1.6)
    g2 = ndi.gaussian_filter(Ls, 1.6 * 2.2)
    D = g1 - g2
    lines = D < -0.013
    # stronger, wider strokes for the big features (eyes, brows, mouth, nostrils)
    g3 = ndi.gaussian_filter(Ls, 3.2)
    g4 = ndi.gaussian_filter(Ls, 3.2 * 2.0)
    lines |= (g3 - g4) < -0.03
    # shadow pools (under brow, nostrils, mouth, neck shadow)
    loc = ndi.gaussian_filter(Ls, 25)
    shadow = (Ls < loc * 0.48) | (Ls < 0.1)
    shadow = smooth_mask(shadow, 2.0)
    # stubble / beard hatching: fine DoG on lightly smoothed luminance, only where the skin is darker than its
    # surroundings (beard zone, jaw), kept as short strokes
    Lf = ndi.gaussian_filter(ndi.median_filter(L, 3), 0.8)
    fine = (ndi.gaussian_filter(Lf, 1.0) - ndi.gaussian_filter(Lf, 2.6)) < -0.016
    beardzone = smooth_mask((Ls < loc * 0.86) & skin, 6)
    stub = drop_small(fine & beardzone, 14)
    face_ink = (lines | shadow | stub) & skin
    face_ink = drop_small(face_ink, 45)

    # hair: solid black with a few cream curl highlights (manga style)
    hair = dark & ~below
    Lh = ndi.gaussian_filter(L, 1.2)
    hi = (Lh - ndi.gaussian_filter(Lh, 6)) > 0.03
    hi = drop_small(hi & ndi.binary_erosion(hair, iterations=7) & (Lh > 0.09), 30)

    ink = (fill | face_ink) & body
    ink &= ~hi

    # supersampled smoothing: blur the binary map at 2x then cut at 0.5 -> rounded brush contours
    big = np.kron(ink.astype(np.float32), np.ones((2, 2), np.float32))
    big = ndi.gaussian_filter(big, 2.4)
    v = big.reshape(big.shape[0] // 2, 2, big.shape[1] // 2, 2).mean(axis=(1, 3))
    inkA = np.clip((v - 0.5) * 3.0 + 0.5, 0, 1)

    # silhouette contour line (~6 px) so the figure reads against the speed lines
    bodyf = ndi.gaussian_filter(body.astype(np.float32), 1.2)
    inner = ndi.gaussian_filter(ndi.binary_erosion(body, iterations=6).astype(np.float32), 1.2)
    outline = np.clip((bodyf - inner) * 1.6, 0, 1)
    inkA = np.maximum(inkA, outline)

    col = CREAM[None, None, :] * (1 - inkA[..., None]) + INK[None, None, :] * inkA[..., None]
    alpha = np.clip(bodyf * 1.4 - 0.2, 0, 1)
    out = np.dstack([col, alpha])
    Image.fromarray((out * 255 + 0.5).astype(np.uint8), "RGBA").save(os.path.join(OUT, f"{abs_f:05d}.png"), compress_level=3)


if __name__ == "__main__":
    a, b = int(sys.argv[1]), int(sys.argv[2])
    set_cam(a, b); print("portrait cam", CAM, flush=True)
    for f in range(a, b + 1):
        ink_frame(f)
        print("ink", f, flush=True)
