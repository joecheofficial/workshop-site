"""Shared framing for the media tools: reads JOE + PLATE_EXT from studio/src/lib.tsx and track.json, so the
pre-rendered media always line up with what Remotion draws (Backdrop + Joe)."""
import json, os, re
import numpy as np
from PIL import Image
JOB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_lib = open(os.path.join(JOB, "studio", "src", "lib.tsx")).read()
_m = re.search(r"export const JOE = \{ s: ([\d.]+), ox: (-?[\d.]+), oy: (-?[\d.]+) \}", _lib)
JOE = dict(s=float(_m.group(1)), ox=float(_m.group(2)), oy=float(_m.group(3)))
_e = re.search(r"export const PLATE_EXT = (\d+)", _lib); PLATE_EXT = int(_e.group(1)) if _e else 0
TRACK = json.load(open(os.path.join(JOB, "studio", "src", "track.json")))
N = len(TRACK)
W, H = 1080, 1920

def head(f):
    """Joe's head box in OUTPUT px: dict(top, cx, w, chin, cy, x0, x1)."""
    t = TRACK[max(0, min(N - 1, f))]; s = JOE["s"]
    top, cx, w, chin = t[0] * s + JOE["oy"], t[1] * s + JOE["ox"], t[2] * s, t[3] * s + JOE["oy"]
    return dict(top=top, cx=cx, w=w, chin=chin, cy=(top + chin) / 2, x0=t[4] * s + JOE["ox"], x1=t[5] * s + JOE["ox"])

def _place(img, w_src, h_src, Hout=H):
    """Paste a raw-aligned image (w_src x h_src, raw px) into output space with the JOE transform."""
    s = JOE["s"]; sw, sh = round(w_src * s), round(h_src * s)
    if (sw, sh) != img.size: img = img.resize((sw, sh), Image.LANCZOS)
    mode = img.mode; can = Image.new(mode, (W, Hout), (0, 0, 0, 0) if mode == "RGBA" else (11, 15, 12))
    can.paste(img, (round(JOE["ox"]), round(JOE["oy"])))
    return can

def joe_rgba(f):
    """Joe cut-out (RGBA float 0..1) in output space for absolute frame f."""
    im = Image.open(os.path.join(JOB, "media", "cut", f"{max(1, min(N, f + 1)):05d}.png")).convert("RGBA")
    return np.asarray(_place(im, 1080, 1920), np.float32) / 255

def plate_rgb(Hout=H):
    """Clean plate (RGB float) in output space, like <Backdrop/>; rows below 1920 repeat the last row."""
    im = Image.open(os.path.join(JOB, "studio", "public", "plate.png")).convert("RGB")
    a = np.asarray(_place(im, 1080 + PLATE_EXT, 1920), np.float32) / 255
    if Hout > H: a = np.concatenate([a, np.repeat(a[-1:], Hout - H, 0)], 0)
    return a

def scene_rgb(f):
    j = joe_rgba(f); p = plate_rgb()
    return p * (1 - j[..., 3:4]) + j[..., :3] * j[..., 3:4], j[..., 3]
