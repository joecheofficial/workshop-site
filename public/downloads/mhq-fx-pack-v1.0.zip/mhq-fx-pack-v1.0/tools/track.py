#!/usr/bin/env python3
"""Joe's head + body box per frame -> <job>/studio/src/track.json.
Each entry: [head_top, head_cx, head_w, chin_y, body_x0, body_x1] in RAW HeyGen pixels (1080x1920).
- head_top  : first matte row (top of the hair)
- head_cx   : centre of Apple Vision's face box (falls back to the matte head band)
- head_w    : median width of the matte run through head_cx over the ear band (hands beside the head do not count)
- chin_y    : lowest point of Vision's face contour (jaw line). The old version took the narrowest matte row
              below the top as the "neck", which lands on the mouth/eyes when a collar hides the neck.
              Fallback when no face is found: top + 1.37 * head_w (measured ratio on Joe).
- body_x0/1 : matte extent 80..520 px below the chin
Smoothed with a 7-frame mean so boxes do not jitter.
Usage: track.py <job-dir>
"""
import json, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image

J = sys.argv[1]
HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(HERE, ".face-bin")
if not os.path.exists(BIN):
    subprocess.run(["swiftc", "-O", os.path.join(HERE, "face.swift"), "-o", BIN], check=True)
faces = {}
with tempfile.TemporaryDirectory() as T:
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", os.path.join(J, "raw", "main.mp4"), "-q:v", "2", os.path.join(T, "%05d.jpg")], check=True)
    out = subprocess.run([BIN, T], check=True, capture_output=True, text=True).stdout
for line in out.splitlines():
    p = line.split()
    if len(p) == 7: faces[p[0].replace(".jpg", ".png")] = [float(v) for v in p[1:]]

files = sorted(f for f in os.listdir(os.path.join(J, "mask")) if f.endswith(".png"))
rows = []; nf = 0
for fn in files:
    m = np.asarray(Image.open(os.path.join(J, "mask", fn)).convert("L")) > 128
    ys = np.where(m.any(1))[0]
    if len(ys) == 0:
        rows.append(rows[-1] if rows else [0, 540, 200, 400, 0, 1080]); continue
    top = int(ys[0])
    fc = faces.get(fn)
    if fc:
        nf += 1
        x0, y0, x1, y1, chx, chy = fc
        cx = (x0 + x1) / 2; chin = chy
    else:
        band = m[top:top + 260]; cols = np.where(band.any(0))[0]
        cx = float(cols.mean()); chin = None
    # head width: run of matte through cx, median over the ear band
    span = (chin - top) if chin else 360
    ws = []
    for y in range(int(top + 0.30 * span), int(top + 0.65 * span), 3):
        r = m[y]; c = int(round(cx))
        if c < 0 or c >= r.size or not r[c]: continue
        a = c
        while a > 0 and r[a - 1]: a -= 1
        b = c
        while b < r.size - 1 and r[b + 1]: b += 1
        ws.append(b - a + 1)
    w = float(np.median(ws)) if ws else 200.0
    if chin is None: chin = top + 1.37 * w
    body = m[int(chin) + 80:int(chin) + 520]; bx = np.where(body.any(0))[0]
    rows.append([top, cx, w, chin, int(bx[0]) if len(bx) else 0, int(bx[-1]) if len(bx) else 1080])
a = np.array(rows, dtype=np.float32)
k = np.ones(7) / 7
sm = np.stack([np.convolve(np.pad(a[:, i], 3, mode="edge"), k, mode="valid") for i in range(a.shape[1])], 1)
outp = os.path.join(J, "studio", "src", "track.json")
json.dump([[round(float(v), 1) for v in r] for r in sm], open(outp, "w"))
print(outp, len(sm), "frames,", nf, "with a face; frame 0:", [round(float(v)) for v in sm[0]])
