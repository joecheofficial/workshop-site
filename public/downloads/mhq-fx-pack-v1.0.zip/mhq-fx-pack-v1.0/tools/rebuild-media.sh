#!/bin/bash
# Makes the per-frame pictures for the effects that need them (code body, impact frame, banknote, newspaper, dust).
set -e
J="$(cd "$(dirname "$0")/.." && pwd)"; cd "$J"; PY="${PY:-python3}"
w() { node -e "const t=require('$J/studio/src/timeline.json');const i=t.find(x=>x.id==='$1');const r=s=>Math.floor(s*25+0.5);console.log(r(i.start),r(i.end)-1)"; }
read CA CB < <(w code-body); read IA IB < <(w impact-frame); read BA BB < <(w banknote)
read PA _ < <(w press-front); read _ TB < <(w paper-tear); read WA WB < <(w blow-away)
rm -rf media/code-body media/impact-frame media/banknote media/press-front media/blow-away
mkdir -p media/code-body media/impact-frame media/banknote media/press-front media/blow-away out
$PY tools/code-body-gen.py $CA $((CB-CA+1)) > out/media-code.log 2>&1 &
$PY tools/impact-frame-ink.py $IA $IB > out/media-impact.log 2>&1 &
$PY tools/banknote-engrave.py "$J" media/banknote $((BA+1)) $((BB+1)) > out/media-banknote.log 2>&1 &
$PY tools/press-front-halftone.py $PA $TB > out/media-press.log 2>&1 &
$PY tools/blow-away-particles.py $WA $((WB-WA+1)) > out/media-blow.log 2>&1 &
FAIL=0; for p in $(jobs -p); do wait $p || FAIL=1; done
[ $FAIL = 0 ] || { echo "a media step failed, see out/media-*.log"; exit 1; }
for d in code-body impact-frame banknote press-front blow-away; do echo "  $d: $(ls media/$d | wc -l | tr -d ' ') frames"; done
