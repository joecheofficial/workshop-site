import Foundation
import Vision
import CoreImage
import AppKit
let args = CommandLine.arguments
let inDir = URL(fileURLWithPath: args[1]), outDir = URL(fileURLWithPath: args[2])
let files = try FileManager.default.contentsOfDirectory(atPath: inDir.path).filter{$0.hasSuffix(".jpg")}.sorted()
let ctx = CIContext()
for f in files {
  autoreleasepool {
    let url = inDir.appendingPathComponent(f)
    guard let ci = CIImage(contentsOf: url) else { return }
    let req = VNGeneratePersonSegmentationRequest()
    req.qualityLevel = .accurate
    req.outputPixelFormat = kCVPixelFormatType_OneComponent8
    let h = VNImageRequestHandler(ciImage: ci, options: [:])
    try? h.perform([req])
    guard let pb = req.results?.first?.pixelBuffer else { return }
    var m = CIImage(cvPixelBuffer: pb)
    m = m.transformed(by: CGAffineTransform(scaleX: ci.extent.width / m.extent.width, y: ci.extent.height / m.extent.height))
    let cs = CGColorSpaceCreateDeviceGray()
    try? ctx.writePNGRepresentation(of: m, to: outDir.appendingPathComponent(f.replacingOccurrences(of: ".jpg", with: ".png")), format: .L8, colorSpace: cs)
  }
}
print("done", files.count)
