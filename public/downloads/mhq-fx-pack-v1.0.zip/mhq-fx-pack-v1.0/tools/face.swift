// Face box + chin per frame with Apple Vision face landmarks (on-device).
// Usage: face-bin <dir of NNNNN.jpg> -> prints one line per frame: "<file> x0 y0 x1 y1 chinX chinY" in PIXELS (top-left origin), or "<file> -" if no face.
import Foundation
import Vision
import CoreImage
let inDir = URL(fileURLWithPath: CommandLine.arguments[1])
let files = try FileManager.default.contentsOfDirectory(atPath: inDir.path).filter{$0.hasSuffix(".jpg")}.sorted()
for f in files {
  autoreleasepool {
    guard let ci = CIImage(contentsOf: inDir.appendingPathComponent(f)) else { print(f, "-"); return }
    let W = ci.extent.width, H = ci.extent.height
    let req = VNDetectFaceLandmarksRequest()
    let h = VNImageRequestHandler(ciImage: ci, options: [:])
    try? h.perform([req])
    guard let faces = req.results, !faces.isEmpty else { print(f, "-"); return }
    let face = faces.max(by: { $0.boundingBox.width < $1.boundingBox.width })!
    let bb = face.boundingBox
    let x0 = bb.minX * W, x1 = bb.maxX * W, y0 = (1 - bb.maxY) * H, y1 = (1 - bb.minY) * H
    var cx = (x0 + x1) / 2, cy = y1
    if let pts = face.landmarks?.faceContour?.normalizedPoints, !pts.isEmpty {
      let low = pts.min(by: { $0.y < $1.y })!   // lowest point of the jaw line = chin (Vision y goes up)
      cx = (bb.minX + low.x * bb.width) * W; cy = (1 - (bb.minY + low.y * bb.height)) * H
    }
    print(f, String(format: "%.1f %.1f %.1f %.1f %.1f %.1f", x0, y0, x1, y1, cx, cy))
  }
}
