"""Fill matte holes: any background region that does not reach the top of the frame (the real backdrop always does)
is a hole in Joe (e.g. the dark shadow between arm and torso at the bottom), so it becomes Joe. The cut-out then shows
the raw pixels there, which is the true picture. Usage: holefill.py <maskdir>"""
import sys, glob, numpy as np
from PIL import Image
from scipy import ndimage
fs = sorted(glob.glob(sys.argv[1] + "/*.png")); n = 0
for f in fs:
    m = np.asarray(Image.open(f).convert("L"))
    lab, k = ndimage.label(m < 128)
    keep = set(np.unique(lab[:3])) - {0}
    hole = (lab > 0) & ~np.isin(lab, list(keep))
    if hole.any():
        hole = ndimage.binary_dilation(hole, iterations=3)
        Image.fromarray(np.where(hole, 255, m).astype(np.uint8)).save(f); n += 1
print("holefill", len(fs), "masks,", n, "had holes")
