#!/usr/bin/env python3
"""Take the desk clock out of Joe's matte (Vision counts it as part of him).
The clock sits IN FRONT of Joe on the desk, so where it is the plate must show, never the cut-out.
Builds look/occluder-clock.png once (shapes measured on room-b at 1080x1920, scale 1080/1536, crop y 8)
and multiplies every mask/NNNNN.png by (1 - occluder). Run after matte.sh (copy mask/ to mask-vision/ first: this reads mask-vision/, writes mask/), before rebuilding media/cut.
The clock is always in FRONT of Joe's hands (its base sits nearer the lens than where his hands rest), so a static occluder is right.
Usage: matte-clean.py <job>
"""
import os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
J = sys.argv[1]
occ = Image.new("L", (1080, 1920), 0); d = ImageDraw.Draw(occ)
# shapes measured on the REAL take (raw/main.mp4 = omni.mp4 cropped 4 px each side), not on room-b.jpg
d.ellipse((932 - 109, 1552 - 109, 932 + 109, 1552 + 109), fill=255)      # clock body
d.ellipse((928 - 34, 1402 - 34, 928 + 34, 1402 + 34), fill=255)           # carry ring ...
d.ellipse((928 - 21, 1404 - 21, 928 + 21, 1404 + 21), fill=0)             # ... its hole shows Joe's sleeve
d.rectangle((910, 1416, 947, 1452), fill=255)                             # crown
d.rectangle((778, 1494, 822, 1920), fill=255); d.rectangle((1036, 1490, 1080, 1920), fill=255)  # posts
d.rectangle((748, 1662, 1080, 1920), fill=255)                            # base
occ = occ.filter(ImageFilter.GaussianBlur(2.5))
occ.save(os.path.join(J, "look", "occluder-clock.png"))
o = np.asarray(occ, np.float32) / 255
src_d = os.path.join(J, "mask-vision") if os.path.isdir(os.path.join(J, "mask-vision")) else os.path.join(J, "mask")
md = os.path.join(J, "mask"); n = 0
for fn in sorted(os.listdir(src_d)):
    if not fn.endswith(".png"): continue
    p = os.path.join(md, fn)
    m = np.asarray(Image.open(os.path.join(src_d, fn)).convert("L"), np.float32)
    Image.fromarray(np.clip(m * (1 - o) + 0.5, 0, 255).astype(np.uint8)).save(p); n += 1
print("cleaned", n, "mattes")
