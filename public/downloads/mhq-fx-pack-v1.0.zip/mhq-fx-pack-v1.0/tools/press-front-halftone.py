#!/usr/bin/env python3.11
"""Press front / paper tear: live halftone newspaper photo of Joe (room plate + Joe cut-out), one PNG per abs frame.
45 degree cosine dot screen (round dots in the lights, checkerboard in the mids, white holes in the shadows),
supersampled 3x for clean dot edges, ink + paper colours sampled from the reference page.

Usage: python3.11 tools/press-front-halftone.py <first_abs> <last_abs>
Writes media/press-front/NNNNN.png (PW x PH, RGB). Layout constants must match press-front-page.tsx.
"""
import json, os, sys
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

JOB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(JOB, "media", "press-front")
os.makedirs(OUT, exist_ok=True)
PW, PH = 588, 1060            # photo box in output px (press-front-page.tsx PHOTO)
SS = 3                        # supersample
PITCH = 8.6                   # dot pitch in output px (reference: ~8.5 px at 1080 wide)
HEAD_W = 370                  # Joe's head width inside the photo (new track metric = face width, ~5% wider than the old one)
HEAD_TOP = 168                # head top inside the photo
PAPER = np.array([246, 242, 231], np.float32) / 255   # photo highlights are a touch lighter than the page
INK = np.array([22, 18, 11], np.float32) / 255
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import framing  # JOE transform + plate exactly like lib.tsx (medium shot in the study, 23 Nov)
PLATE = framing.plate_rgb(2400)


def head_box(f):
    h = framing.head(f)
    return h["top"], h["cx"], h["w"]


def composite(f):
    """Output-space picture (plate + Joe) as float RGB, extended below 1920 by edge repeat. The study is already
    lit dark like the reference room, so no extra vignette or pull-down any more."""
    j = framing.joe_rgba(f)
    can = PLATE.copy()
    a = j[..., 3:4]
    can[:1920] = can[:1920] * (1 - a) + j[..., :3] * a
    return can


# fixed "camera": average head position over the press + tear windows
F0, F1 = int(sys.argv[1]), int(sys.argv[2]) + 1
hb = np.array([head_box(f) for f in range(F0, F1)])
TOP, CX, HW = np.median(hb[:, 0]), np.median(hb[:, 1]), np.median(hb[:, 2])
K = HEAD_W / HW


def halftone(f):
    can = composite(f)
    # sample the photo box at SS x
    v, u = np.mgrid[0:PH * SS, 0:PW * SS].astype(np.float32) / SS
    X = CX + (u - PW / 2) / K
    Y = TOP + (v - HEAD_TOP) / K
    g = can @ np.array([0.299, 0.587, 0.114], np.float32)
    g = ndi.gaussian_filter(g, 1.2 / K)  # remove detail finer than the screen before sampling
    gs = ndi.map_coordinates(g, [Y.ravel(), X.ravel()], order=1, mode="nearest").reshape(Y.shape)
    # tone curve: lift the face, crush the room a little (reference: dark grey room, bright cap/face)
    # the study take is lit low: lift it so the face prints light and the room a dark grey, like the ref page
    t = np.clip(gs * 1.6, 0, 1) ** 0.8
    t = t * t * (3 - 2 * t) * 0.35 + t * 0.65
    dark = 1 - t
    dark = np.clip(dark * 1.04 - 0.02, 0, 1)
    # 45 degree cosine spot function
    c, s = np.cos(np.pi / 4), np.sin(np.pi / 4)
    ur = (u * c + v * s) / PITCH
    vr = (-u * s + v * c) / PITCH
    spot = (np.cos(2 * np.pi * ur) + np.cos(2 * np.pi * vr)) / 4 + 0.5  # 1 = cell centre
    # ink where spot is above (1 - dark); soft edge one sub-pixel wide
    e = 0.5 / (SS * PITCH) * 6
    ink = np.clip((spot - (1 - dark)) / e + 0.5, 0, 1)
    ink = ink.reshape(PH, SS, PW, SS).mean(axis=(1, 3))
    col = PAPER[None, None] * (1 - ink[..., None]) + INK[None, None] * ink[..., None]
    Image.fromarray((col * 255 + 0.5).astype(np.uint8), "RGB").save(os.path.join(OUT, f"{f:05d}.png"), compress_level=3)


if __name__ == "__main__":
    a, b = int(sys.argv[1]), int(sys.argv[2])
    for f in range(a, b + 1):
        halftone(f)
        print("halftone", f, flush=True)
