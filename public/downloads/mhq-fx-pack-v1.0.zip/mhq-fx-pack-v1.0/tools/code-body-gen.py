# code-body: per-frame "person made of code" pictures for the Code body effect.
# Reads the room plate + Joe's RGBA cut frames, writes media/code-body/NN.png (one per local frame).
# Look copied from ref/06-code-body: dark green room with faint code, person = monospace cells coloured
# by his own picture (warm/bright -> cream, cool/dark clothes -> maroon), spaces shown as middle dots,
# cell size steps from big (mosaic) to fine between local frames 12 and 17.
import os, sys, glob, re
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

J = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # the job folder (tools/ lives inside it)
OUT = J + "/media/code-body"; os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import framing  # JOE transform + plate exactly like lib.tsx (medium shot, 23 Nov)
W, H = 1080, 1920
START, DUR = (int(sys.argv[1]), int(sys.argv[2])) if len(sys.argv) > 2 else (139, 27)  # absolute start frame, frames
FONT = "/System/Library/Fonts/SFNSMono.ttf"

# our own code as the text (lib.tsx + chrome.tsx), never his
src = ""
for p in [J + "/studio/src/lib.tsx", J + "/studio/src/chrome.tsx", J + "/studio/src/Main.tsx"]:
    src += open(p).read() + " "
src = re.sub(r"\s+", " ", src)

# plate in output space (same as Backdrop: no vignette any more, the study is lit dark)
plate = framing.plate_rgb()

def joe(abs_frame):
    a = framing.joe_rgba(abs_frame)
    return a[..., :3], a[..., 3]

def cell_means(img, alpha, lh, cw):
    rows, cols = int(np.ceil(H / lh)), int(np.ceil(W / cw))
    sm = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).resize((cols, rows), Image.BOX)
    sa = Image.fromarray((alpha * 255).astype(np.uint8)).resize((cols, rows), Image.BOX)
    return np.asarray(sm, np.float32) / 255, np.asarray(sa, np.float32) / 255, rows, cols

MAROON = np.array([0.50, 0.11, 0.17])
CREAM = np.array([0.95, 0.91, 0.80])
GREEN_BG = np.array([0.055, 0.105, 0.075])

def lum(c):
    return 0.299 * c[..., 0] + 0.587 * c[..., 1] + 0.114 * c[..., 2]

def render(lf):
    a = START + lf
    jr, ja = joe(a)
    comp = plate * (1 - ja[..., None]) + jr * ja[..., None]
    # cell size by phase (ref: 28 -> 19 -> 15 -> 10 px lines on 1080 with a ~180 px face;
    # Joe's face is ~258 px in the medium shot -> x1.43)
    k = lf * 27.5 / DUR  # ref-equivalent local frame (the ref window is 27.5 frames, ours is shorter)
    if k <= 11: lh = 40
    elif k <= 13: lh = 27
    elif k <= 16: lh = 21
    else: lh = 15
    fs = round(lh * 0.93)
    font = ImageFont.truetype(FONT, fs)
    cw = font.getlength("M")
    rows, cols = int(np.ceil(H / lh)), int(np.ceil(W / cw))
    m, al, rows, cols = cell_means(comp, ja, lh, cw)
    L = lum(m)
    m = np.clip((m - L[..., None]) * 1.15 + ((L - 0.5) * 1.45 + 0.5)[..., None], 0, 1)
    L = lum(m)
    # person colour: warm or bright -> cream, cool / mid -> maroon; brightness follows the picture
    pm = float(L[al > 0.5].mean()) if (al > 0.5).any() else 0.5
    # warm/bright RELATIVE to Joe himself (the study is dark and his shirt is black, so skin is the bright warm part)
    warm = (m[..., 0] - m[..., 2]) + 0.9 * (L - pm - 0.12)
    c = np.clip((warm - 0.02) / 0.16, 0, 1)[..., None]
    # contrast within each colour class, so the face keeps eyes/brows/beard and the shirt keeps its folds
    cm = c[..., 0] > 0.5; jm = al > 0.5
    sk = float(L[cm & jm].mean()) if (cm & jm).any() else pm
    rs = float(L[~cm & jm].mean()) if (~cm & jm).any() else pm
    Lp = np.clip(np.where(cm, (L - sk) * 2.8 + 0.8, (L - rs) * 2.6 + 0.55), 0.04, 1.0)
    shade = np.clip(0.22 + 0.95 * Lp, 0.2, 1.15)[..., None]
    person = (MAROON * (1 - c) + CREAM * c) * shade
    person = np.clip(person, 0, 1)
    # room: dark green with faint code, a touch of the room's own light kept
    pl = lum(cell_means(plate, ja, lh, cw)[0])
    pn = np.clip((pl - pl.min()) / max(1e-3, pl.max() - pl.min()), 0, 1)
    big = k <= 11
    # background picture
    # the room stays faintly visible as a dark green mosaic with its own lights (ref: lamp + frame still read)
    roomc = cell_means(plate, ja, lh, cw)[0]
    bg = np.where((al > 0.5)[..., None], person * (0.92 if big else 0.45),
                  GREEN_BG * (0.75 + 0.3 * pn[..., None]) + roomc * 0.32)
    bgimg = Image.fromarray((np.clip(bg, 0, 1) * 255).astype(np.uint8))
    if lf <= 16:
        bgimg = bgimg.resize((round(cols * cw), rows * lh), Image.NEAREST)
    else:
        bgimg = bgimg.resize((round(cols * cw), rows * lh), Image.BILINEAR).filter(ImageFilter.GaussianBlur(lh * 0.35))
    canvas = Image.new("RGB", (W, H), tuple((GREEN_BG * 255).astype(int)))
    canvas.paste(bgimg.crop((0, 0, W, H)), (0, 0))
    # soft person edge so the mosaic does not look like a hard cut-out in the fine phase
    dr = ImageDraw.Draw(canvas)
    off = 0
    for r in range(rows):
        y = r * lh + (lh - fs) * 0.35
        line = src[(off + r * (cols + 7)) % (len(src) - cols - 2):][: cols + 1]
        for k in range(cols):
            ch = line[k] if k < len(line) else " "
            x = k * cw
            if al[r, k] > 0.5:
                col = person[r, k]
                Lc = float(lum(col))
                if ch == " ": ch = "·"
                if big:
                    tc = (0.13, 0.10, 0.09) if Lc > 0.62 else (0.97, 0.94, 0.88)
                else:
                    tc = np.clip(col * 1.45 + 0.12 + 0.32 * Lc, 0, 1)
            else:
                if ch == " ": continue
                p = pn[r, k]
                tc = GREEN_BG + (np.array([0.10, 0.16, 0.12]) + 0.30 * p) * (0.30 if big else 0.42)
            dr.text((x, y), ch, fill=tuple(int(v * 255) for v in tc), font=font)
    canvas.save(f"{OUT}/{lf:02d}.png", optimize=False, compress_level=1)

if __name__ == "__main__":
    frames = range(DUR)
    for lf in frames:
        render(lf); print("ok", lf, flush=True)
