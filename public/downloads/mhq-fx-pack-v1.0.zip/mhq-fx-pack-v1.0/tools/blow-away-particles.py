#!/usr/bin/env python3.11
"""Blow away: Joe disintegrates into fine coloured dust that streams off with swirl, revealing the empty room.
Copied from ref/21-blow-away (10 fps, local s): 0.2 first dust leaves his left side and puffs out to the LEFT,
0.3-0.5 a ragged front sweeps left -> right and slightly bottom -> top (the head goes after the chest), 0.6-0.7 the
head and cap break up, 0.8-1.0 only long curling streaks drift up-right and thin out, 1.1+ empty room.

Not a block grid: every dissolved pixel can become a sub-pixel particle carrying its own colour, particles get a
random size/brightness, an initial puff, a growing wind and a curl-noise swirl field, and are drawn with motion
blur (several samples along their path) so they read as dust and streaks.

Usage: python3.11 tools/blow-away-particles.py <start_abs> <n_frames> [--seed 7]
Writes media/blow-away/NNNNN.png (abs frame, RGBA 1080x1920 OUTPUT space: remaining Joe + dust, transparent
elsewhere). The Remotion side draws Backdrop (clean plate) under it.
"""
import json, os, sys
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

JOB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(JOB, "media", "blow-away")
os.makedirs(OUT, exist_ok=True)
import sys as _s; _s.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import framing  # medium shot framing from lib.tsx
W, H = 1080, 1920

START = int(sys.argv[1]); NF = int(sys.argv[2])
SEED = int(sys.argv[sys.argv.index("--seed") + 1]) if "--seed" in sys.argv else 7
rng = np.random.default_rng(SEED)

# timing (local frames, 25 fps)
T_FIRST, T_LAST = 3.5, 25.0   # front enters his left edge / leaves the right edge (top of the head is last)
FADE = 15.0                   # particle life (frames) before it has thinned out


def joe_out(f):
    """Joe's RGBA frame in output space (float)."""
    return framing.joe_rgba(f)


def noise(shape, cell, rng):
    """smooth value noise in [0,1] with feature size ~cell px"""
    small = rng.random((shape[0] // cell + 3, shape[1] // cell + 3)).astype(np.float32)
    big = ndi.zoom(small, cell, order=3)[: shape[0], : shape[1]]
    big = (big - big.min()) / (big.max() - big.min() + 1e-6)
    return big


# ---- dissolve time map T(x, y): when each pixel turns to dust ----
first = joe_out(START)
A0 = first[..., 3] > 0.3
ys, xs = np.nonzero(A0)
x0, x1 = xs.min(), min(xs.max(), W - 1)
y0, y1 = ys.min(), H
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
xn = np.clip((xx - x0) / (x1 - x0), 0, 1)
yn = np.clip((yy - y0) / (y1 - y0), 0, 1)
n1 = noise((H, W), 160, rng) - 0.5
n2 = noise((H, W), 40, rng) - 0.5
n3 = rng.random((H, W)).astype(np.float32) - 0.5   # per-pixel grain: the front is eaten pixel by pixel
T = T_FIRST + (T_LAST - T_FIRST) * (0.74 * xn + 0.26 * (1 - yn)) + 2.6 * n1 + 1.4 * n2 + 1.0 * n3

# ---- velocity field: wind up-right that grows with age + curl-noise swirl ----
def swirl(px, py, t):
    # psi = S * sin(x/a + t/p) * cos(y/b - t/q) ; v = (dpsi/dy, -dpsi/dx)
    a, b, S = 140.0, 120.0, 1500.0
    sx_ = np.sin(px / a + t / 6.0); cx_ = np.cos(px / a + t / 6.0)
    sy_ = np.sin(py / b - t / 8.0); cy_ = np.cos(py / b - t / 8.0)
    a2, b2, S2 = 47.0, 53.0, 280.0
    s2x = np.sin(px / a2 - t / 3.0); c2x = np.cos(px / a2 - t / 3.0)
    s2y = np.sin(py / b2 + t / 4.0); c2y = np.cos(py / b2 + t / 4.0)
    vx = S * sx_ * (-sy_) / b + S2 * s2x * (-s2y) / b2
    vy = -(S * cx_ * cy_ / a) - (S2 * c2x * c2y / a2)
    return vx, vy


# particle state (grown each frame)
P = dict(x=np.zeros(0, np.float32), y=np.zeros(0, np.float32), vx=np.zeros(0, np.float32), vy=np.zeros(0, np.float32),
         t0=np.zeros(0, np.float32), c=np.zeros((0, 3), np.float32), a=np.zeros(0, np.float32), k=np.zeros(0, np.float32),
         life=np.zeros(0, np.float32), sz=np.zeros(0, np.float32))
SPAWN_P = 0.17   # share of dissolved pixels that become a particle


def spawn(fr, t_prev, t_now):
    newly = (T > t_prev) & (T <= t_now) & (fr[..., 3] > 0.25)
    iy, ix = np.nonzero(newly)
    keep = rng.random(len(iy)) < SPAWN_P
    iy, ix = iy[keep], ix[keep]
    n = len(iy)
    if n == 0:
        return
    col = fr[iy, ix, :3].copy()
    # a few specks catch the light, a few go dark
    col *= (1.0 + 0.55 * rng.random((n, 1)) ** 2).astype(np.float32)
    xnp = xn[iy, ix]
    # initial puff: the first (left) dust bursts out to the left and down, the rest out sideways and up
    # puff: early dust on his left bursts out LEFT and down (ref 0.2-0.3 s); the rest leaves fast up-right in a fan
    left = np.clip((0.32 - xnp) / 0.2, 0, 1)
    ang = np.where(rng.random(n) < left, np.pi + rng.normal(0.35, 0.45, n), rng.normal(-0.42, 0.55, n))
    spd = (12.0 + 10.0 * rng.random(n) ** 2) * (1 + 0.6 * left)
    vx0 = (np.cos(ang) * spd).astype(np.float32)
    vy0 = (np.sin(ang) * spd).astype(np.float32)
    P["x"] = np.concatenate([P["x"], ix + rng.random(n).astype(np.float32)])
    P["y"] = np.concatenate([P["y"], iy + rng.random(n).astype(np.float32)])
    P["vx"] = np.concatenate([P["vx"], vx0]); P["vy"] = np.concatenate([P["vy"], vy0])
    P["t0"] = np.concatenate([P["t0"], T[iy, ix]])
    P["c"] = np.concatenate([P["c"], np.clip(col, 0, 1)])
    P["a"] = np.concatenate([P["a"], (0.55 + 0.45 * rng.random(n)).astype(np.float32)])
    P["k"] = np.concatenate([P["k"], (0.6 + 0.8 * rng.random(n)).astype(np.float32)])  # how much the wind takes it
    P["life"] = np.concatenate([P["life"], (FADE * (0.5 + rng.random(n))).astype(np.float32)])
    P["sz"] = np.concatenate([P["sz"], (rng.random(n) < 0.12).astype(np.float32)])  # 12% are 2x2 grains


def step(t, dt=1.0, sub=3):
    """integrate velocities over one frame in `sub` substeps; returns the path samples for motion blur"""
    samples = []
    for s in range(sub):
        age = np.maximum(0, t - P["t0"])
        wind_x = (7.0 + 3.6 * age) * P["k"]
        wind_y = -(2.5 + 2.1 * age) * P["k"]
        sx, sy = swirl(P["x"], P["y"], t)
        sw = np.minimum(1.0, age / 3.0) * P["k"]
        P["vx"] *= 0.92 ** (dt / sub); P["vy"] *= 0.92 ** (dt / sub)
        P["x"] += (P["vx"] + wind_x + sx * sw) * dt / sub
        P["y"] += (P["vy"] + wind_y + sy * sw) * dt / sub
        samples.append((P["x"].copy(), P["y"].copy()))
    return samples


def render(fr, t, samples):
    # remaining Joe: pixels whose time has not come
    keep = (T > t).astype(np.float32)
    keep = ndi.gaussian_filter(keep, 0.5)
    joe_a = fr[..., 3] * keep
    accC = np.zeros((H, W, 3), np.float32)
    accA = np.zeros((H, W), np.float32)
    age = np.maximum(0, t - P["t0"])
    alpha = P["a"] * np.clip(1 - age / P["life"], 0, 1) * np.clip(age * 2 + 0.3, 0, 1)
    alive = alpha > 0.02
    ns = len(samples)
    for (sx, sy) in samples:
        X = np.round(sx[alive]).astype(np.int32); Y = np.round(sy[alive]).astype(np.int32)
        a = alpha[alive] / ns * 1.5
        c = P["c"][alive]
        big = P["sz"][alive] > 0
        for ddx, ddy, m in ((0, 0, None), (1, 0, big), (0, 1, big), (1, 1, big)):
            Xi, Yi, ai, ci = X + ddx, Y + ddy, a, c
            if m is not None:
                Xi, Yi, ai, ci = Xi[m], Yi[m], ai[m], ci[m]
            ok = (Xi >= 0) & (Xi < W) & (Yi >= 0) & (Yi < H)
            np.add.at(accA, (Yi[ok], Xi[ok]), ai[ok])
            np.add.at(accC, (Yi[ok], Xi[ok]), ci[ok] * ai[ok][:, None])
    dustA = np.clip(accA, 0, 1)
    dustC = accC / np.maximum(accA, 1e-6)[..., None]
    # composite dust over remaining Joe (premultiplied over)
    outA = dustA + joe_a * (1 - dustA)
    outC = (dustC * dustA[..., None] + fr[..., :3] * (joe_a * (1 - dustA))[..., None]) / np.maximum(outA, 1e-6)[..., None]
    return np.dstack([np.clip(outC, 0, 1), outA])


t_prev = -1.0
for i in range(NF):
    f = START + i
    fr = joe_out(f)
    t = float(i)
    spawn(fr, t_prev, t)
    samples = step(t) if len(P["x"]) else []
    img = render(fr, t, samples) if samples else np.dstack([fr[..., :3], fr[..., 3] * (T > t)])
    Image.fromarray((img * 255 + 0.5).astype(np.uint8), "RGBA").save(os.path.join(OUT, f"{f:05d}.png"), compress_level=2)
    # drop dead particles
    age = t - P["t0"]
    live = age < P["life"]
    for k in P:
        P[k] = P[k][live]
    t_prev = t
    print("blow", f, len(P["x"]), flush=True)
