#!/bin/bash
# MHQ FX Pack: put 20 video effects on your own talking video.
# Usage: ./make.sh my-video.mp4        -> out/fx-video.mp4
# Needs a Mac (Apple Vision cuts you out of the background), ffmpeg, Node 18+, Python 3 with numpy pillow scipy fonttools.
# Best input: vertical, you in the middle, camera still, plain-ish background, 20 to 40 seconds.
set -eo pipefail
J="$(cd "$(dirname "$0")" && pwd)"; cd "$J"; PY="${PY:-python3}"; export PY
IN="$1"; [ -f "$IN" ] || { echo "usage: ./make.sh my-video.mp4"; exit 1; }
for c in ffmpeg ffprobe node npx swiftc "$PY"; do command -v $c >/dev/null || { echo "missing: $c (see README, step 1)"; exit 1; }; done
$PY -c "import numpy, PIL, scipy, fontTools" 2>/dev/null || { echo "missing Python parts: $PY -m pip install numpy pillow scipy fonttools"; exit 1; }
[ -d studio/node_modules ] || (echo "== first run: installing Remotion (one time, ~1 min)"; cd studio && npm install --no-audit --no-fund --loglevel=error)
cp config.json studio/src/config.json
rm -rf raw mask media/cut; mkdir -p raw media out
echo "== 1/7 video to 1080x1920, 25 fps"
ffmpeg -v error -y -i "$IN" -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=25,setsar=1,format=yuv420p" \
  -c:v libx264 -preset medium -crf 14 -c:a aac -b:a 192k -ar 48000 raw/main.mp4
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 raw/main.mp4)
NF=$(ffprobe -v error -count_packets -select_streams v:0 -show_entries stream=nb_read_packets -of csv=p=0 raw/main.mp4)
echo "   $DUR s, $NF frames"
echo "== 2/7 cutting you out (Apple Vision, on this Mac)"
[ -x tools/.seg-bin ] || swiftc -O tools/seg.swift -o tools/.seg-bin
T="$(mktemp -d)"; ffmpeg -v error -y -i raw/main.mp4 -q:v 2 "$T/%05d.jpg"; mkdir -p mask; tools/.seg-bin "$T" mask >/dev/null; rm -rf "$T"
$PY tools/holefill.py mask >/dev/null
mkdir -p media/cut
ffmpeg -v error -y -i raw/main.mp4 -framerate 25 -i mask/%05d.png -filter_complex "[1:v]format=gray,gblur=sigma=1.2[m];[0:v]format=rgba[v];[v][m]alphamerge" \
  -frames:v $NF -compression_level 1 media/cut/%05d.png
echo "== 3/7 finding your head in every frame"
$PY tools/track.py "$J" | tail -1
SH=$($PY tools/shift-left.py "$J"); SH=$(( SH / 2 * 2 ))   # even, so the video stays 1080 wide
if [ "$SH" -gt 8 ]; then
  echo "   moving you $SH px left, clear of the effects list"
  COLS="split=2[a][b];[a]crop=$((1080-SH)):1920:${SH}:0[l];[b]crop=${SH}:1920:$((1080-SH)):0,hflip[r];[l][r]hstack"
  ffmpeg -v error -y -i raw/main.mp4 -filter_complex "[0:v]${COLS},format=yuv420p[v]" -map "[v]" -map 0:a? -c:v libx264 -preset medium -crf 14 -c:a copy raw/shifted.mp4
  mv raw/shifted.mp4 raw/main.mp4
  mkdir -p mask2; ffmpeg -v error -y -framerate 25 -i mask/%05d.png -filter_complex "[0:v]format=gray,${COLS}" -start_number 1 mask2/%05d.png
  rm -rf mask; mv mask2 mask
  rm -rf media/cut; mkdir -p media/cut
  ffmpeg -v error -y -i raw/main.mp4 -framerate 25 -i mask/%05d.png -filter_complex "[1:v]format=gray,gblur=sigma=1.2[m];[0:v]format=rgba[v];[v][m]alphamerge" \
    -frames:v $NF -compression_level 1 media/cut/%05d.png
  [ "$(ffprobe -v error -show_entries stream=width -select_streams v:0 -of csv=p=0 raw/main.mp4)" = 1080 ] || { echo "shift made the wrong width"; exit 1; }
  $PY tools/shift-left.py "$J" --apply $SH
fi
echo "== 4/7 the empty background"
$PY tools/studio-plate.py "$J" 200 $(( NF / 40 > 3 ? NF / 40 : 3 )) | tail -1   # ~40 sample frames keeps memory low
echo "== 5/7 timing the 20 effects"
$PY tools/timeline.py "$DUR"
$PY tools/voice-note-avatar.py "$J" $(( NF / 3 )) >/dev/null && cp studio/public/voice-note/avatar.png studio/public/comment-drop/avatar.png
echo "== 6/7 effect pictures"
bash tools/rebuild-media.sh
echo "== 7/7 render (a few minutes)"
(cd media && exec $PY -m http.server 8790 --bind 127.0.0.1 >/dev/null 2>&1) & SRV=$!; trap 'kill $SRV 2>/dev/null' EXIT; sleep 1
(cd studio && npx remotion render src/index.ts Main ../out/fx-silent.mp4 --codec=h264 --crf=16 --timeout=180000 --log=error)
ffmpeg -v error -y -i out/fx-silent.mp4 -i raw/main.mp4 -map 0:v -map 1:a? -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart out/fx-video.mp4
echo "DONE: $J/out/fx-video.mp4"
