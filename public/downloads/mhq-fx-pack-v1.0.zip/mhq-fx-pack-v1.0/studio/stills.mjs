// Fast stills: bundle once, render many absolute frames. Usage:
//   node tools/stills.mjs <outdir> <frame> [frame ...]      -> <outdir>/fNNN.png
// Set REBUNDLE=0 to reuse out/.bundle from the previous call (only when no source changed).
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition, openBrowser } from "@remotion/renderer";
import path from "path"; import fs from "fs";
const J = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const [outDir, ...frames] = process.argv.slice(2);
fs.mkdirSync(outDir, { recursive: true });
const bdir = path.join(J, "out", ".bundle");
let serveUrl = bdir;
if (process.env.REBUNDLE !== "0" || !fs.existsSync(bdir)) {
  serveUrl = await bundle({ entryPoint: path.join(J, "studio/src/index.ts"), outDir: bdir, publicDir: path.join(J, "studio/public"), enableCaching: true });
}
const browser = await openBrowser("chrome", { browserExecutable: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" });
const comp = await selectComposition({ serveUrl, id: "Main", puppeteerInstance: browser });
const todo = frames.map(Number);
const conc = 4;
async function worker() {
  while (todo.length) {
    const f = todo.shift();
    await renderStill({ composition: comp, serveUrl, output: path.join(outDir, `f${String(f).padStart(3, "0")}.png`), frame: f, puppeteerInstance: browser, timeoutInMilliseconds: 120000, imageFormat: "png" });
  }
}
await Promise.all(Array.from({ length: conc }, worker));
await browser.close({ silent: true });
console.log("stills", frames.length, "->", outDir);
