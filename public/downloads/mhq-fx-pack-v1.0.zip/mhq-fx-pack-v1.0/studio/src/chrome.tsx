// Persistent layout copied from the reference: the green "IN THIS VIDEO" list on the right and the
// two white title boxes top-left ("20 video effects in 20 seconds" / "built by Claude").
// Measured on the 1080x1080 reference: panel x 743-1060 (w 317), header 38 px tall, rows 36 px apart,
// numbers mono 13 px, names 22 px semibold, active row = white pill r 9, footer "+ 40 more effects" 25 px bold.
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C, F, TIMELINE, fr, clamp } from "./lib";
import CFG from "./config.json";


export const PANEL = { x: 744, y: 520, w: 318, row: 36 };
export const FOOTER_TEXT = `Comment ${CFG.keyword}`;

export const Panel: React.FC<{ goldFrom?: number; visible?: number }> = ({ goldFrom = 9e9, visible = 1 }) => {
  const f = useCurrentFrame();
  const t = f / 25;
  const items = TIMELINE;
  let active = 0;
  items.forEach((it, i) => { if (t >= it.start - 0.04) active = i; });
  let n = 0;
  const numbered = items.map((it) => (it.id === "comment-drop" ? "+" : String(++n).padStart(2, "0")));
  const count = Math.min(20, items.slice(0, active + 1).filter((it) => it.id !== "comment-drop").length);
  const gold = interpolate(f, [goldFrom, goldFrom + 6], [0, 1], clamp);
  const h = 62 + items.length * PANEL.row + 78;
  return (
    <div style={{ position: "absolute", left: PANEL.x, top: PANEL.y, width: PANEL.w, height: h, opacity: visible,
      background: "rgba(27,49,36,0.94)", border: "1.5px solid rgba(200,180,106,0.55)", borderRadius: 22,
      boxShadow: "0 10px 40px rgba(0,0,0,.45)", fontFamily: F.ui }}>
      <div style={{ position: "absolute", left: 24, top: 22, fontFamily: F.mono, fontSize: 15.5, letterSpacing: 3.2, color: C.gold }}>IN THIS VIDEO</div>
      <div style={{ position: "absolute", right: 24, top: 22, fontFamily: F.mono, fontSize: 15.5, letterSpacing: 1.5, color: C.cream }}>
        {String(Math.max(1, count)).padStart(2, "0")} / 20
      </div>
      {items.map((it, i) => {
        const on = i === active;
        return (
          <div key={it.id} style={{ position: "absolute", left: 10, top: 62 + i * PANEL.row, width: PANEL.w - 20, height: 33,
            borderRadius: 9, background: on ? "#fbfaf6" : "transparent", display: "flex", alignItems: "center" }}>
            <span style={{ width: 44, textAlign: "center", fontFamily: F.mono, fontSize: 13, color: on ? "#5b6a5f" : C.sageDim }}>{numbered[i]}</span>
            <span style={{ fontSize: 22, fontWeight: 600, letterSpacing: -0.2, color: on ? "#16201a" : C.sage }}>{it.name}</span>
          </div>
        );
      })}
      <div style={{ position: "absolute", left: 24, right: 24, top: 62 + items.length * PANEL.row + 12, height: 1, background: "rgba(183,196,182,.28)" }} />
      <div style={{ position: "absolute", left: 14, top: 62 + items.length * PANEL.row + 26, padding: "4px 10px", borderRadius: 8,
        background: `rgba(205,181,106,${gold})`, fontSize: 25, fontWeight: 700, letterSpacing: -0.3,
        color: gold > 0.5 ? "#1b2a1f" : C.cream }}>{FOOTER_TEXT}</div>
    </div>
  );
};

/** White rounded title boxes, top-left, shown while the first effects play. */
export const Title: React.FC<{ until: number }> = ({ until }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  void fps;
  // ref: the title is up for effects 01-02 and gone when 03 (day dial) starts
  const dd = TIMELINE.find((it) => it.id === "day-dial");
  const end = dd ? Math.min(until, fr(dd.start) - 3) : until;
  if (f > end + 3) return null;
  const out = interpolate(f, [end, end + 3], [1, 0], clamp);
  const box: React.CSSProperties = { display: "inline-block", background: "#fff", borderRadius: 16, padding: "6px 22px 10px",
    fontFamily: F.ui, fontWeight: 700, fontSize: 46, letterSpacing: -1.2, color: "#111", lineHeight: 1.12 };
  return (
    <AbsoluteFill style={{ opacity: out }}>
      <div style={{ position: "absolute", left: 30, top: 330, width: 700, textAlign: "center" }}>
        <div style={box}>{CFG.title_line_1}</div>
        <div style={{ ...box, marginTop: -2 }}>built by <span style={{ color: "#1f3d2b" }}>Claude</span></div>
      </div>
    </AbsoluteFill>
  );
};
