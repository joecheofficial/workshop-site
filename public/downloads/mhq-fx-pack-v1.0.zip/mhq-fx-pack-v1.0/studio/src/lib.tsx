// Shared building blocks for the "20 effects in 20 seconds" Joe reel (MHQ FX pack v2, 23 Nov 2026).
// Layout + look copied detail for detail from the reference reel (ref/justyn-reference.mp4, 1080x1080),
// re-laid for 9:16. Every effect file imports from here so they all line up.
import React from "react";
import { AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig, interpolate, Easing, Sequence } from "remotion";
import TRACK from "./track.json";
import TL from "./timeline.json";

export const W = 1080, H = 1920, FPS = 25;
export const MEDIA = "http://127.0.0.1:8790"; // big media served locally (never in public/, Remotion copies public on every render)

// ---------- palette (sampled from the reference frames) ----------
export const C = {
  green: "#1c3325",        // panel / dark green
  greenDeep: "#14261b",
  greenInk: "#1f4a33",     // banknote ink
  gold: "#c8b46a",         // selection box, panel border, header text
  goldBright: "#d9c27a",
  goldPill: "#cdb56a",     // "+40 more effects" pill once the CTA has played
  cream: "#efe9dc",        // paper / cards
  creamDeep: "#e6dfcf",
  sage: "#b7c4b6",         // panel item text
  sageDim: "#7f9283",      // panel numbers
  ink: "#121614",
  white: "#ffffff",
  red: "#a3343a",
};
export const F = {
  ui: "-apple-system, 'SF Pro Display', 'Helvetica Neue', Inter, Arial, sans-serif",
  mono: "'SF Mono', Menlo, 'Roboto Mono', monospace",
  serif: "Didot, 'Bodoni 72', 'Times New Roman', serif",
  serifText: "Georgia, 'Times New Roman', serif",
  hand: "Noteworthy, 'Bradley Hand', 'Marker Felt', cursive",
};

// ---------- Joe framing: HeyGen 1080x1920 take scaled into the left of the 9:16 frame ----------
// v5 (Illy 24 Nov: "exactly like the approved look"): the approved STUDIO look itself (plain grey backdrop,
// black shirt), take2/take-studio.mp4. take2/rebuild-studio.sh already moves him down 240 px and left 40 px
// inside raw/main.mp4, so the framing here is identity. plate.png still carries PLATE_EXT px on the right.
// v6 (Illy 24 Nov: "a bit stiff"): take2/take-studio-B.mp4 ("B natural" movement prompt) with L=110, so his head
// sways but never goes under the IN THIS VIDEO panel (right edge max ~738 vs panel x 744).
export const JOE = { s: 1, ox: 0, oy: 0 }; // out = raw * s + o
export const PLATE_EXT = 200; // plate.png is (1080 + PLATE_EXT) x 1920, raw-aligned from x 0
export const toOut = (x: number, y: number) => ({ x: x * JOE.s + JOE.ox, y: y * JOE.s + JOE.oy });
type T = [number, number, number, number, number, number]; // raw: head_top, head_cx, head_w, chin_y, body_x0, body_x1
/** Joe's head box in OUTPUT pixels at a given absolute frame. */
export const head = (frame: number) => {
  const t = (TRACK as T[])[Math.max(0, Math.min((TRACK as T[]).length - 1, frame))];
  const top = t[0] * JOE.s + JOE.oy, cx = t[1] * JOE.s + JOE.ox, w = t[2] * JOE.s, chin = t[3] * JOE.s + JOE.oy;
  return { top, cx, w, chin, cy: (top + chin) / 2, bodyX0: t[4] * JOE.s + JOE.ox, bodyX1: t[5] * JOE.s + JOE.ox };
};

/** The room behind Joe: clean plate of the study (look/room-b-empty), framed exactly like Joe (JOE transform).
 *  No vignette: the room is already lit dark, and darkening the plate but not Joe's cut-out edge would halo him. */
export const Backdrop: React.FC<{ style?: React.CSSProperties }> = ({ style }) => (
  <AbsoluteFill style={{ background: "#0b0f0c", ...style }}>
    <Img src={staticFile("plate.png")} style={{ position: "absolute", left: JOE.ox, top: JOE.oy, width: (1080 + PLATE_EXT) * JOE.s, height: 1920 * JOE.s }} />
  </AbsoluteFill>
);

/** What stands IN FRONT of Joe in the room: the desk top (from its edge down) and the desk clock (public/front.png,
 *  tools/front-layer.py). Draw it over a replaced background and under Joe, so the desk stays in front. */
export const Front: React.FC<{ style?: React.CSSProperties }> = ({ style }) => (
  <AbsoluteFill style={style}>
    <Img src={staticFile("front.png")} style={{ position: "absolute", left: JOE.ox, top: JOE.oy, width: (1080 + PLATE_EXT) * JOE.s, height: 1920 * JOE.s }} />
  </AbsoluteFill>
);

/** Absolute frame of the composition, even inside a Sequence (Remotion's useCurrentFrame is local there). */
export const AbsFrame = React.createContext(0);
export const joeSrc = (absFrame: number) => `${MEDIA}/cut/${String(Math.max(1, Math.min(N_FRAMES, absFrame + 1))).padStart(5, "0")}.png`;
export const N_FRAMES = (TRACK as unknown[]).length;
/** Joe cut out (lossless PNG + alpha), framed. `at` = absolute frame to show (freeze / offset); default = now. */
export const Joe: React.FC<{ style?: React.CSSProperties; outline?: boolean; at?: number; filter?: string }> = ({ style, outline, at, filter }) => {
  const now = React.useContext(AbsFrame);
  const fs = [outline ? "drop-shadow(0 0 1.5px rgba(239,233,220,.95)) drop-shadow(0 0 1px rgba(239,233,220,.95))" : "", filter || ""].join(" ").trim();
  return (
    <AbsoluteFill style={style}>
      <Img src={joeSrc(at ?? now)} style={{ position: "absolute", left: JOE.ox, top: JOE.oy, width: 1080 * JOE.s, height: 1920 * JOE.s, filter: fs || undefined }} />
    </AbsoluteFill>
  );
};

/** The normal picture: room + Joe. */
export const Scene: React.FC<{ outline?: boolean }> = ({ outline }) => (
  <AbsoluteFill>
    <Backdrop />
    <Joe outline={outline} />
  </AbsoluteFill>
);

// ---------- timeline ----------
export type Item = { id: string; name: string; start: number; end: number; chrome?: "show" | "hide" };
export const TIMELINE = TL as Item[];
export const fr = (s: number) => Math.round(s * FPS);
export const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
export const easeOut = Easing.bezier(0.22, 1, 0.36, 1);
export const easeInOut = Easing.bezier(0.65, 0, 0.35, 1);
/** 0..1 progress of local frame between a and b (frames), eased. */
export const prog = (f: number, a: number, b: number, e = easeOut) => interpolate(f, [a, b], [0, 1], { ...clamp, easing: e });

/** Absolute frame inside an effect. */
export const useAbs = () => React.useContext(AbsFrame);
export const useLocal = () => {
  const f = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  return { f, dur: durationInFrames };
};
