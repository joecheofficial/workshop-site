import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import TL from "./timeline.json";
const last = (TL as { end: number }[]).slice(-1)[0].end;
export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={Math.round(last * 25)} fps={25} width={1080} height={1920} />
);
