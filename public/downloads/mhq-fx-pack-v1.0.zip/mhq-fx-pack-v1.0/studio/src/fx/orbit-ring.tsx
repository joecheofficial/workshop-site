// 05 Orbit ring: big serif capitals "ORBIT RING · " orbit Joe's head on a tilted ellipse around chin level,
// passing behind his head (Backdrop, back letters, Joe, front letters) and in front of his neck. Letters stay
// upright, scale and dim with depth, a warm gold highlight sits on the front-left of the ring. Swoops in from a
// wide blurred ring, orbits ~0.9 turn, smears out. Timing from ref/05-orbit-ring.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Backdrop, Joe, head, useAbs, F, clamp, easeOut } from "../lib";

const TEXT = "ORBIT RING · ORBIT RING · ".split("");
const N = TEXT.length; // 26 slots
const DELTA = (2 * Math.PI) / N;
// ref/05 measured: ring centred on the face at 0.8 of the way from head top to chin, RX 0.9 / RY 0.47 face widths,
// capitals ~0.32 face widths tall (font size). All follow the head track (medium shot, 23 Nov).
const KX = 0.9, KY = 0.47, KF = 0.33;

const mix = (a: number[], b: number[], t: number) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
const CREAM = [236, 231, 218], GOLD = [214, 190, 116];

const OrbitRing: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const hd = head(abs);
  const cx = hd.cx + 0.03 * hd.w, cy = hd.top + 0.8 * (hd.chin - hd.top);
  const RX = KX * hd.w, RY = KY * hd.w, FS = KF * hd.w;

  const enter = interpolate(f, [1, 5.5], [0, 1], { ...clamp, easing: easeOut });
  const exit = interpolate(f, [19.5, 25], [0, 1], clamp);
  const radius = (1 + (1 - enter) * 0.9) * (1 - exit * 0.32);
  const blur = (1 - enter) * 12 + exit * 9;
  const smear = 1 + exit * 2.2; // horizontal motion smear as it spins out
  const alpha = interpolate(f, [1, 3.5], [0, 1], clamp) * (1 - interpolate(exit, [0.45, 1], [0, 1], clamp));
  // rotation: front centre between B and I of the first ORBIT at frame 7.5, half a turn per 15 frames;
  // spins up on the way out
  const w = (13 * DELTA) / 15;
  const extra = exit * exit * 3.2;
  const phi0 = -2.5 * DELTA - w * (f - 7.5) - extra - (1 - enter) * 0.9;

  if (alpha <= 0.001) return null;
  const letters = TEXT.map((ch, i) => {
    const phi = phi0 + i * DELTA;
    const z = Math.cos(phi);
    const x = cx + RX * radius * Math.sin(phi);
    const y = cy + RY * radius * z;
    let rel = Math.atan2(Math.sin(phi), Math.cos(phi));
    const g = Math.exp(-Math.pow((rel + 0.45) / 0.55, 2)) * (z > 0 ? 1 : 0.3);
    const col = mix(CREAM, GOLD, g);
    const sc = 0.8 + 0.2 * z;
    const op = (0.62 + 0.38 * (z + 1) / 2) * alpha;
    return { ch, x, y, z, col, sc, op };
  });
  const draw = (front: boolean) =>
    letters.filter((l) => (front ? l.z >= 0 : l.z < 0) && l.ch !== " ").map((l, i) => (
      <div key={`${front}${i}`} style={{ position: "absolute", left: l.x, top: l.y, transform: `translate(-50%,-50%) scale(${l.sc * smear}, ${l.sc})`,
        fontFamily: F.serif, fontSize: l.ch === "·" ? FS * 0.7 : FS, lineHeight: 1, color: `rgb(${l.col.join(",")})`, opacity: l.op,
        textShadow: front ? "0 3px 8px rgba(0,0,0,.45), 0 0 2px rgba(0,0,0,.35)" : "0 2px 6px rgba(0,0,0,.35)",
        filter: blur > 0.3 || !front ? `blur(${blur + (front ? 0 : 0.6)}px)` : undefined }}>{l.ch}</div>
    ));

  return (
    <AbsoluteFill>
      <Backdrop />
      {draw(false)}
      <Joe />
      {draw(true)}
    </AbsoluteFill>
  );
};
export default OrbitRing;
