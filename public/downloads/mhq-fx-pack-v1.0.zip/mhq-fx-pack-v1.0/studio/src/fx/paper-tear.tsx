// Paper tear: the Press front page rips down the middle and the halves fly apart, copied from ref/20-paper-tear.
// Ref timing (local s): 0.0-0.3 whole page (photo still live) | 0.4 torn, halves hinge open from the bottom, a white
// fibrous edge on each side | 0.5 halves swing out and grow towards the camera (left goes up-left, right
// down-right) | 0.6 left gone, right half falling off the bottom-right corner, OVER the panel | 0.7+ normal video.
// The halves are drawn above the "IN THIS VIDEO" panel in the reference, so this file draws the panel itself
// underneath them when the timeline hides the shared chrome (chrome: "hide" for this item gives the exact layering).
import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame } from "remotion";
import { useAbs, TIMELINE, fr } from "../lib";
import { Panel } from "../chrome";
import { PressPage, Grain } from "./press-front-page";

// deterministic noise
const rnd = (i: number, seed: number) => {
  const x = Math.sin(i * 127.1 + seed * 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const STEP = 7;
const N = Math.ceil(1920 / STEP) + 1;
// the tear line: slightly diagonal, low-frequency wander + mid zig-zag + fine fibre jitter
const TEAR: number[] = Array.from({ length: N }, (_, i) => {
  const y = i * STEP;
  return 548 - (y / 1920) * 46 + 26 * Math.sin(y / 260 + 0.7) + 11 * Math.sin(y / 71 + 2.1) + (rnd(i, 1) - 0.5) * 16 + (rnd(i >> 1, 5) - 0.5) * 10;
});
// width of the exposed white paper core on each half (thin, ragged, sometimes wide)
const WL: number[] = Array.from({ length: N }, (_, i) => 3 + 7 * rnd(i, 9) + 9 * Math.max(0, Math.sin(i / 9 + 1)) * rnd(i >> 2, 3));
const WR: number[] = Array.from({ length: N }, (_, i) => 3 + 6 * rnd(i, 13) + 10 * Math.max(0, Math.sin(i / 11 + 4)) * rnd(i >> 2, 7));

const poly = (side: "L" | "R", off: (i: number) => number) => {
  const pts = TEAR.map((x, i) => `${(x + off(i)).toFixed(1)}px ${Math.min(1920, i * STEP + (rnd(i, 21) - 0.5) * 3).toFixed(1)}px`);
  if (side === "L") return `polygon(-400px -400px, ${pts.join(", ")}, -400px 2400px)`;
  return `polygon(1600px -400px, ${pts.join(", ")}, 1600px 2400px)`;
};
const CLIP = {
  Lpage: poly("L", (i) => -WL[i]),
  Lwhite: poly("L", () => 0),
  Rpage: poly("R", (i) => WR[i]),
  Rwhite: poly("R", () => 0),
};

const T0 = 8.5; // local frame the paper starts to give (ref: whole at 0.3 s, torn at 0.4 s)

const Half: React.FC<{ side: "L" | "R"; at: number; tf: string }> = ({ side, at, tf }) => (
  <AbsoluteFill style={{ transform: tf, transformOrigin: "540px 1760px", filter: "drop-shadow(0 10px 18px rgba(0,0,0,.5))" }}>
    <AbsoluteFill style={{ clipPath: side === "L" ? CLIP.Lwhite : CLIP.Rwhite, background: "#fbf9f2" }}>
      {/* soft grey fibre shading on the white core */}
      <AbsoluteFill style={{ background: side === "L" ? "linear-gradient(90deg, rgba(0,0,0,0) 40%, rgba(120,110,95,.18) 100%)" : "linear-gradient(270deg, rgba(0,0,0,0) 40%, rgba(120,110,95,.18) 100%)" }} />
    </AbsoluteFill>
    <AbsoluteFill style={{ clipPath: side === "L" ? CLIP.Lpage : CLIP.Rpage }}>
      <PressPage at={at} />
      <Grain />
    </AbsoluteFill>
  </AbsoluteFill>
);

const PaperTear: React.FC<{ dur: number }> = ({ dur }) => {
  // keyframes are ref frames (ref window 23.5 frames); ours is shorter, so the tear plays compressed and the
  // halves are always gone (normal video back) before the cut, like the ref
  const f = (useCurrentFrame() * 23.5) / dur;
  const abs = useAbs();
  const me = TIMELINE.find((it) => it.id === "paper-tear")!;
  const cta = TIMELINE.find((it) => it.id === "comment-drop")!;
  const start = fr(me.start);
  const t = Math.max(0, f - T0);
  const gone = f >= T0 + 9;
  // left half: swings up-left, rotates counter-clockwise; right half: down-right, clockwise, then falls
  const sc = 1 + 0.0085 * t * t;
  const L = `translate(${-13.5 * t * t}px, ${-0.2 * t * t * t}px) rotate(${-0.12 * t * t}deg) scale(${sc})`;
  const R = `translate(${8.6 * t * t}px, ${1.5 * t * t * t}px) rotate(${0.27 * t * t}deg) scale(${sc})`;
  return (
    <AbsoluteFill>
      {me.chrome === "hide" && (
        <Sequence from={-start} layout="none">
          <Panel goldFrom={fr(cta.start + 2.6)} />
        </Sequence>
      )}
      {!gone && (f < T0 ? (
        <AbsoluteFill><PressPage at={abs} /><Grain /></AbsoluteFill>
      ) : (
        <>
          <Half side="L" at={abs} tf={L} />
          <Half side="R" at={abs} tf={R} />
        </>
      ))}
    </AbsoluteFill>
  );
};
export default PaperTear;
