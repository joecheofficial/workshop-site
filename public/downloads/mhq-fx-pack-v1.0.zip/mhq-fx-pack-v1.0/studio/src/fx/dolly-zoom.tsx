// Dolly zoom (vertigo), copied from ref/18-dolly-zoom (10 fps, local s): the room behind pushes in hard around the
// head while the man keeps his size: 0.0 x1.00 | 0.1 x1.25 | 0.2 x1.55 | 0.3 x1.75, then it holds and keeps
// creeping (~x1.8) to 0.9 s | 1.0 s snaps back to the normal picture. Joe is redrawn untouched on top.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Backdrop, Front, Joe, head, useAbs, clamp, easeOut } from "../lib";

const DollyZoom: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const back = dur - 4; // snap back on the last frames (ref frame 11 = 1.0 s is normal again)
  if (f >= back) return null;
  const h0 = head(abs - f); // zoom centre fixed at the head where the move starts
  const push = interpolate(f, [0, 7.5], [1, 1.76], { ...clamp, easing: easeOut });
  const creep = interpolate(f, [7.5, back], [0, 0.06], clamp);
  const z = push + creep;
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ transform: `scale(${z})`, transformOrigin: `${h0.cx}px ${h0.cy}px` }}>
        <Backdrop />
      </AbsoluteFill>
      {/* the desk + clock sit right in front of him, so like him they keep their size (only the room behind pushes in) */}
      <Front />
      <Joe />
    </AbsoluteFill>
  );
};
export default DollyZoom;
