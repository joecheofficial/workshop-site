// Head stack: effect-name tags drop from above and pile up on Joe's head (and a second pile beside him), then tumble off
// to the left. All motion/size detail lives in head-stack-tags.tsx (shared with the first frame of rack-focus).
import React from "react";
import { useCurrentFrame } from "remotion";
import { useAbs } from "../lib";
import { HeadStackTags } from "./head-stack-tags";

// the tag keyframes are ref frames (ref window 28 frames); our window is shorter, so the drop-in + fling-off play
// time-compressed to fit and the exit is always seen (rack-focus continues at ref frame 28).
const HeadStack: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const abs = useAbs();
  return <HeadStackTags f={(f * 28) / dur} abs={abs} />;
};
export default HeadStack;
