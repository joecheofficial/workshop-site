// Shared newspaper front page for press-front (it slams in) and paper-tear (it rips). Copied from ref/19-press-front,
// re-laid for 9:16: same widths and type sizes as the 1080 reference, the extra height goes to taller columns
// (all 20 effects listed), a taller live halftone photo and a short story under the caption.
// Type: Instrument Serif (masthead, headline, italic deck, heads) + IM FELL DW Pica (body, small caps), both OFL,
// files in public/press-front/. Photo: live halftone frames from tools/press-front-halftone.py in media/press-front/.
import React from "react";
import { continueRender, delayRender, Img, staticFile } from "remotion";
import CFG from "../config.json";
import { MEDIA, TIMELINE, fr } from "../lib";
const _pa = fr(TIMELINE.find((x) => x.id === "press-front")!.start), _pb = fr(TIMELINE.find((x) => x.id === "paper-tear")!.end) - 1;

export const PAPER = "#eee7d5";
export const INK = "#19150d";
export const PHOTO = { x: 246, y: 556, w: 588, h: 1060 };

const FONTS: [string, string, string][] = [
  ["PF Instrument", "press-front/InstrumentSerif-Regular.ttf", "normal"],
  ["PF Instrument", "press-front/InstrumentSerif-Italic.ttf", "italic"],
  ["PF Fell", "press-front/IMFePIrm28P.ttf", "normal"],
  ["PF Fell", "press-front/IMFePIit28P.ttf", "italic"],
];
let fontsReady = false;
if (typeof document !== "undefined" && !fontsReady) {
  const h = delayRender("press-front fonts");
  Promise.all(
    FONTS.map(([fam, file, style]) => {
      const ff = new FontFace(fam, `url(${staticFile(file)})`, { style });
      return ff.load().then((x) => (document as any).fonts.add(x));
    })
  )
    .then(() => { fontsReady = true; continueRender(h); })
    .catch((e) => { console.error(e); continueRender(h); });
}

const HEAD = "'PF Instrument', 'Times New Roman', serif";
const BODY = "'PF Fell', Georgia, serif";

export const FIRST_NINE: [string, string][] = [
  ["Live cursor.", "A cursor named Claude moves the frame."],
  ["Clone row.", "A row of clones, all talking."],
  ["Day dial.", "The head is the hub, the room a printed clock face."],
  ["Predict keys.", "A keyboard types the name, three suggestions pop up."],
  ["Orbit ring.", "Type goes round the head, behind it and in front."],
  ["Code body.", "The body turns into the code behind it."],
  ["Post wall.", "A wall of posts fills the room."],
  ["Letter dive.", "The camera dives into one letter."],
  ["Layer explode.", "The frame splits into its layers."],
];
export const THE_REST: [string, string][] = [
  ["Sketch words.", "One word drawn in pencil."],
  ["Blade slice.", "One white hairline, two halves slide apart."],
  ["Head stack.", "Tiles pile up on a moving head."],
  ["Rack focus.", "The room goes soft."],
  ["Banknote.", "A live engraving on paper money."],
  ["Voice note.", "The words turn into a voice message."],
  ["Impact frame.", "One manga panel, full force."],
  ["Dolly zoom.", "The room stretches, the man stays."],
  ["Press front.", "This page."],
  ["Paper tear.", "The page rips down the middle."],
  ["Blow away.", "The man turns to dust."],
];

const Rule: React.FC<{ y: number; x0?: number; x1?: number; w?: number; double?: boolean }> = ({ y, x0 = 40, x1 = 1040, w = 1.3, double }) => (
  <>
    <div style={{ position: "absolute", left: x0, top: y, width: x1 - x0, height: w, background: INK }} />
    {double && <div style={{ position: "absolute", left: x0, top: y + 4.5, width: x1 - x0, height: w, background: INK }} />}
  </>
);

const Item: React.FC<{ name: string; text: string; size?: number }> = ({ name, text, size = 25 }) => (
  <p style={{ margin: "0 0 17px", textIndent: 22, textAlign: "justify", hyphens: "auto", fontFamily: BODY, fontSize: size, lineHeight: 1.17, color: INK }}>
    <i>{name}</i> {text}
  </p>
);

const ColHead: React.FC<{ children: React.ReactNode; size?: number }> = ({ children, size = 37 }) => (
  <div style={{ fontFamily: HEAD, fontSize: size, textAlign: "center", lineHeight: 1.05, color: INK, letterSpacing: -0.3 }}>{children}</div>
);

/** The full page, 1080x1920, at absolute frame `at` (drives the live photo). `boldDeck` = the slam frame. */
export const PressPage: React.FC<{ at: number; boldDeck?: number }> = ({ at, boldDeck = 0 }) => {
  const photo = `${MEDIA}/press-front/${String(Math.max(_pa, Math.min(_pb, at))).padStart(5, "0")}.png`;
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, background: PAPER, overflow: "hidden", color: INK }}>
      {/* masthead boxes */}
      <div style={{ position: "absolute", left: 40, top: 60, width: 158, height: 90, border: `1.3px solid ${INK}`, textAlign: "center" }}>
        <div style={{ fontFamily: HEAD, fontSize: 25, marginTop: 6, lineHeight: 1 }}>Final Edition</div>
        <div style={{ fontFamily: BODY, fontSize: 15, lineHeight: 1.25, marginTop: 4 }}>This page is on sale<br />for 1 second</div>
      </div>
      <div style={{ position: "absolute", left: 882, top: 60, width: 158, height: 90, border: `1.3px solid ${INK}`, textAlign: "center" }}>
        <div style={{ fontFamily: HEAD, fontSize: 25, marginTop: 6, lineHeight: 1 }}>Late News</div>
        <div style={{ fontFamily: BODY, fontSize: 15, lineHeight: 1.25, marginTop: 4 }}>Comment {CFG.keyword} to<br />get access to these</div>
      </div>
      <div style={{ position: "absolute", left: 200, width: 680, top: 30, textAlign: "center", fontFamily: HEAD, fontSize: 130, letterSpacing: -2, lineHeight: 1.08, WebkitTextStroke: `0.6px ${INK}` }}>
        The Daily Feed
      </div>
      {/* dateline */}
      <Rule y={170} double />
      <div style={{ position: "absolute", left: 40, right: 40, top: 184, display: "flex", justifyContent: "space-between", fontFamily: BODY, fontSize: 16.5, letterSpacing: 2.6 }}>
        <span>{`BY ${CFG.first_name} ${CFG.last_name}`.toUpperCase()}</span><span style={{ marginLeft: 40 }}>{CFG.dateline}</span><span>SET BY CLAUDE</span>
      </div>
      <Rule y={206} double />
      {/* headline + deck */}
      <div style={{ position: "absolute", left: 0, width: 1080, top: 232, textAlign: "center", fontFamily: HEAD, fontSize: 156, letterSpacing: -2.5, lineHeight: 1.0, whiteSpace: "nowrap", WebkitTextStroke: `0.8px ${INK}` }}>
        {CFG.headline}
      </div>
      <div style={{ position: "absolute", left: 0, width: 1080, top: 390, textAlign: "center", fontFamily: HEAD, fontStyle: "italic", fontSize: 80, letterSpacing: -0.6, lineHeight: 1.05,
        WebkitTextStroke: boldDeck > 0 ? `${2.6 * boldDeck}px ${INK}` : undefined }}>
        {CFG.deck}
      </div>
      <Rule y={535} w={2.2} />
      {/* column rules */}
      <div style={{ position: "absolute", left: 236, top: 548, width: 1.2, height: 1332, background: INK }} />
      <div style={{ position: "absolute", left: 843, top: 548, width: 1.2, height: 1332, background: INK }} />

      {/* left column: The List */}
      <div style={{ position: "absolute", left: 40, top: 556, width: 188 }}>
        <ColHead>The List</ColHead>
        <div style={{ fontFamily: BODY, fontSize: 14.5, letterSpacing: 2.2, textAlign: "center", marginTop: 8, lineHeight: 1.3 }}>{`BY ${CFG.first_name} ${CFG.last_name}`.toUpperCase()}</div>
        <div style={{ height: 1.2, background: INK, margin: "18px 0 14px" }} />
        <ColHead size={33}>The first nine</ColHead>
        <div style={{ height: 14 }} />
        {FIRST_NINE.map(([n, t]) => <Item key={n} name={n} text={t} />)}
        <div style={{ height: 1.2, background: INK, margin: "4px 0 10px" }} />
        <div style={{ fontFamily: BODY, fontStyle: "italic", fontSize: 20, textAlign: "center", lineHeight: 1.15 }}>Eleven more<br />on the right</div>
      </div>

      {/* centre: photo + caption + short story */}
      <Img src={photo} style={{ position: "absolute", left: PHOTO.x, top: PHOTO.y, width: PHOTO.w, height: PHOTO.h }} />
      <div style={{ position: "absolute", left: PHOTO.x, top: PHOTO.y + PHOTO.h + 14, width: PHOTO.w, textAlign: "center", fontFamily: BODY, fontStyle: "italic", fontSize: 24 }}>
        {CFG.first_name} {CFG.last_name}, reading the list.
      </div>
      <Rule y={PHOTO.y + PHOTO.h + 58} x0={PHOTO.x + 6} x1={PHOTO.x + PHOTO.w - 6} />
      <div style={{ position: "absolute", left: PHOTO.x + 6, top: PHOTO.y + PHOTO.h + 70, width: PHOTO.w - 12 }}>
        <ColHead size={40}>Every frame set in code</ColHead>
        <div style={{ columnCount: 2, columnGap: 22, columnRule: `1.2px solid ${INK}`, marginTop: 10 }}>
          <Item name="Claude wrote it." text="Each effect on this page is a short program. Claude wrote them, then the machine drew every frame." />
          <Item name="Twenty in a row." text="The effects run one after another, about a second each, while the man keeps talking." />
        </div>
      </div>

      {/* right column: The ask + The rest */}
      <div style={{ position: "absolute", left: 852, top: 562, width: 188 }}>
        <ColHead>The ask</ColHead>
        <p style={{ fontFamily: BODY, fontSize: 23.5, lineHeight: 1.12, textAlign: "center", margin: "12px 0 0" }}>Comment {CFG.keyword} to get access to these.</p>
        <div style={{ height: 1.2, background: INK, margin: "18px 0 14px" }} />
        <ColHead>The rest</ColHead>
        <div style={{ height: 12 }} />
        {THE_REST.map(([n, t]) => <Item key={n} name={n} text={t} />)}
        <div style={{ height: 1.2, background: INK, margin: "4px 0 10px" }} />
        <div style={{ fontFamily: BODY, fontStyle: "italic", fontSize: 20, textAlign: "center", lineHeight: 1.15 }}>Comment {CFG.keyword}<br />for the full set</div>
      </div>
    </div>
  );
};

/** Faint paper grain over the page. */
export const Grain: React.FC<{ seed?: number }> = ({ seed = 3 }) => (
  <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0, mixBlendMode: "multiply", opacity: 0.16 }}>
    <filter id={`pfg${seed}`}>
      <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed={seed} />
      <feColorMatrix values="0 0 0 0 0.5  0 0 0 0 0.45  0 0 0 0 0.38  0 0 0 1.4 -0.35" />
    </filter>
    <rect width={1080} height={1920} filter={`url(#pfg${seed})`} />
  </svg>
);
