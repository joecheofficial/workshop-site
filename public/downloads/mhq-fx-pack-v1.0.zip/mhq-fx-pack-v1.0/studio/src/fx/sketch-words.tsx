// 10 Sketch words. Copied from ref/11-sketch-words: hard cut to cream paper with two pencil rules (x-height line
// draws on left -> right, baseline rule already there), a small handwritten "sketch" writes on top-left, then a huge
// serif "words" draws its outline letter by letter in pencil (double sketchy stroke), fills with maroon pencil
// hatching letter by letter, gets a darker second pass, and a gold-brown brush underline drags across under it.
// Joe stays in front as a cut-out with a light halo, the panel stays on. Hard cut back to the live shot.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Front, Joe, W, H, clamp, easeOut, easeInOut } from "../lib";
import G from "./sketch-words-glyphs";

const PAPER = "#f4efe3";
const PENCIL = "#2b221d";
const RED = "#9c2a3d";
const GOLD = "#a68c48";
// medium shot (23 Nov): like the ref the word sits just above his head and BEHIND it (baseline ~0.35 face widths
// under the hair top) and fits the open area left of the panel (ref: ~60% of the frame width).
const WW = 700, K = WW / 960;            // word width; K scales the old 960-wide layout constants
const S = WW / (G.glyphs[4].box[2] - G.glyphs[0].box[0]); // glyph px (size 1000) -> frame px
const X0 = 34 - G.glyphs[0].box[0] * S;
const BASE = 660;                       // baseline (rule 2); x-height rule above it
const XH = 481 * S;                     // Georgia x-height at size 1000 = 481
const ON = 4, OFF = 27;                 // hard cuts (local frames)
const OUTLINE: [number, number][] = [[8, 10], [9, 10.8], [10, 11.6], [10.5, 12.2], [11, 12.6]];
const HATCH: [number, number][] = [[11, 13.4], [12.4, 14.8], [13.4, 15.4], [14, 16.6], [15, 17.2]];

const SketchWords: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  if (f < ON || f >= OFF) return null;
  const tf = `translate(${X0} ${BASE}) scale(${S})`;
  const rule1 = interpolate(f, [ON, 7], [0.12, 1], { ...clamp, easing: easeOut });
  const write = interpolate(f, [ON, 10], [0.08, 1], clamp);
  const pass2 = interpolate(f, [15.8, 18], [0, 1], clamp);
  const under = interpolate(f, [16, 20.6], [0, 1], { ...clamp, easing: easeInOut });
  const ulX0 = 38, ulX1 = 38 + 940 * K, ulY = BASE + 33 * K;
  return (
    <AbsoluteFill style={{ background: PAPER }}>
      <svg width={W} height={H} style={{ position: "absolute", left: 0, top: 0 }}>
        <defs>
          <filter id="sw-grain" x="-8%" y="-8%" width="116%" height="116%">
            <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={3} result="n" />
            <feDisplacementMap in="SourceGraphic" in2="n" scale={2.6} xChannelSelector="R" yChannelSelector="G" result="d" />
            <feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.5 1.65" result="a" />
            <feComposite in="d" in2="a" operator="in" />
          </filter>
          <filter id="sw-rough" x="-5%" y="-5%" width="110%" height="110%">
            <feTurbulence type="fractalNoise" baseFrequency="0.045 0.11" numOctaves={2} seed={5} result="n" />
            <feDisplacementMap in="SourceGraphic" in2="n" scale={9} xChannelSelector="R" yChannelSelector="G" result="d" />
            <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves={2} seed={11} result="m" />
            <feColorMatrix in="m" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.6 1.7" result="a" />
            <feComposite in="d" in2="a" operator="in" />
          </filter>
          <filter id="sw-paper"><feTurbulence type="fractalNoise" baseFrequency="0.75" numOctaves={3} seed={9} />
            <feColorMatrix type="matrix" values="0 0 0 0 0.45  0 0 0 0 0.40  0 0 0 0 0.32  0 0 0 0.07 0" /></filter>
          <pattern id="sw-hatch" patternUnits="userSpaceOnUse" width={14} height={14} patternTransform="rotate(31)">
            <rect x={0} y={0} width={5.6} height={14} fill={RED} />
          </pattern>
          <pattern id="sw-hatch2" patternUnits="userSpaceOnUse" width={17} height={17} patternTransform="rotate(36) translate(6 0)">
            <rect x={0} y={0} width={4.4} height={17} fill="#7e1d2f" />
          </pattern>
          {G.glyphs.map((g, i) => (
            <clipPath key={i} id={`sw-g${i}`}><path d={g.d} transform={tf} /></clipPath>
          ))}
          <clipPath id="sw-write"><rect x={30} y={0} width={330 * K * write} height={BASE} /></clipPath>
          <linearGradient id="sw-ul" x1="0" x2="1">
            <stop offset="0" stopColor={GOLD} stopOpacity={0.75} /><stop offset="0.5" stopColor={GOLD} /><stop offset="1" stopColor={GOLD} stopOpacity={0.85} />
          </linearGradient>
        </defs>
        <rect x={0} y={0} width={W} height={H} filter="url(#sw-paper)" />
        {/* pencil rules: x-height line draws on, baseline already there */}
        <g filter="url(#sw-grain)" stroke="#55504a" strokeLinecap="round" fill="none">
          <path d={`M0 ${BASE - XH} L${W * rule1} ${BASE - XH - 1.5}`} strokeWidth={2} opacity={0.6} />
          <path d={`M0 ${BASE + 1} L${W} ${BASE - 1}`} strokeWidth={2} opacity={0.6} />
        </g>
        {/* handwritten "sketch" */}
        <g clipPath="url(#sw-write)" filter="url(#sw-grain)">
          <text x={40} y={BASE - XH - 30 * K} fontFamily="Noteworthy, 'Bradley Hand', cursive" fontWeight={300} fontSize={104 * K}
            fill="#3a322c" letterSpacing={-2} transform={`rotate(-3 40 ${BASE - XH - 30 * K})`}>sketch</text>
        </g>
        {/* hatching, letter by letter, then a darker second pass */}
        {G.glyphs.map((g, i) => {
          const [a, b] = HATCH[i];
          const p = interpolate(f, [a, b], [0, 1], clamp);
          if (p <= 0) return null;
          const x0 = X0 + g.box[0] * S - 10, w = (g.box[2] - g.box[0]) * S + 20;
          return (
            <g key={i} clipPath={`url(#sw-g${i})`}>
              <rect x={x0} y={BASE - 300 * K} width={w * p} height={340 * K} fill="rgba(190,95,110,.12)" />
              <g filter="url(#sw-rough)">
                <rect x={x0} y={BASE - 300 * K} width={w * p} height={340 * K} fill="url(#sw-hatch)" opacity={0.95} />
                {pass2 > 0 && <rect x={x0} y={BASE - 300 * K} width={w} height={340 * K} fill="url(#sw-hatch2)" opacity={0.75 * pass2} />}
              </g>
            </g>
          );
        })}
        {/* pencil outline, drawn on letter by letter (two passes, slightly off, like a sketch) */}
        <g fill="none" strokeLinejoin="round" strokeLinecap="round">
          {G.glyphs.map((g, i) => {
            const [a, b] = OUTLINE[i];
            const p = interpolate(f, [a, b], [0, 1], clamp);
            if (p <= 0) return null;
            const dark = 0.8 + 0.2 * pass2;
            return (
              <g key={i} filter="url(#sw-grain)">
                <path d={g.d} transform={`translate(${X0 + 3} ${BASE - 2.5}) scale(${S * 1.004})`} pathLength={1} strokeDasharray="1 1"
                  strokeDashoffset={1 - p} stroke={PENCIL} strokeWidth={2.4 / S} opacity={0.6 * dark} />
                <path d={g.d} transform={tf} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - p}
                  stroke={PENCIL} strokeWidth={(3.6 + 1.2 * pass2) / S} opacity={dark} />
              </g>
            );
          })}
        </g>
        {/* gold-brown brush underline */}
        {under > 0 && (
          <g filter="url(#sw-grain)">
            <path d={`M${ulX0} ${ulY + 2} Q ${(ulX0 + ulX1) / 2} ${ulY - 5} ${ulX0 + (ulX1 - ulX0) * under} ${ulY - 1}`}
              stroke="url(#sw-ul)" strokeWidth={10} strokeLinecap="round" fill="none" />
          </g>
        )}
      </svg>
      <Front />
      <Joe outline filter="drop-shadow(0 0 2.5px rgba(255,255,255,.75))" />
    </AbsoluteFill>
  );
};
export default SketchWords;
