// Rack focus, copied from ref/14-rack-focus (10 fps frames + the 30 fps video):
// 0.00-0.08 s  sharp (the last head-stack tags are still smearing out on the left edge in the very first frame)
// 0.10-0.40 s  focus pulls off the room: the room goes from sharp to very soft (shallow depth of field: lamps turn into
//              soft blobs, a touch of focus breathing) and DARKER (measured: room mean luma -34 %, highlights -37 %),
//              eased in and out. Joe stays tack sharp.
// 0.40-1.08 s  holds soft.
// last frame   snaps back to sharp for one frame right before the cut to the banknote.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Backdrop, Joe, easeInOut, clamp, useAbs } from "../lib";
import { HeadStackTags } from "./head-stack-tags";

const BLUR = 16; // px at full defocus (ref ~11 px; Joe's face is ~1.45x the ref's in the medium shot)

const RackFocus: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const last = f >= dur - 1;
  const p = last ? 0 : interpolate(f, [3, 10], [0, 1], { ...clamp, easing: easeInOut });
  return (
    <AbsoluteFill>
      {p > 0 && (
        <AbsoluteFill style={{ background: "#0b0f0c", overflow: "hidden" }}>
          <Backdrop style={{ filter: `blur(${p * BLUR}px) brightness(${1 - 0.32 * p})`, transform: `scale(${1 + 0.07 * p})` }} />
          <Joe />
        </AbsoluteFill>
      )}
      {/* hand-off: head-stack tags still flying out on the left in the first two frames */}
      {f < 2 && <HeadStackTags f={28 + f} abs={abs} />}
    </AbsoluteFill>
  );
};
export default RackFocus;
