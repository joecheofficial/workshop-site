// One file per effect, id = timeline id. Each default-exports React.FC<{ dur: number }> (dur = frames in its window).
import React from "react";
const FILES: Record<string, () => { default: React.FC<{ dur: number }> }> = {};
const ids = ["live-cursor","clone-row","day-dial","predict-keys","orbit-ring","code-body","post-wall","letter-dive","comment-drop",
  "layer-explode","sketch-words","blade-slice","head-stack","rack-focus","banknote","voice-note","impact-frame","dolly-zoom",
  "press-front","paper-tear","blow-away"];
export const FX: Record<string, React.FC<{ dur: number }> | undefined> = {};
// eslint-disable-next-line @typescript-eslint/no-var-requires
const ctx = (require as any).context("./", false, /^\.\/[a-z-]+\.tsx$/);
for (const k of ctx.keys()) {
  const id = k.replace("./", "").replace(".tsx", "");
  if (ids.includes(id)) FX[id] = ctx(k).default;
}
void FILES;
