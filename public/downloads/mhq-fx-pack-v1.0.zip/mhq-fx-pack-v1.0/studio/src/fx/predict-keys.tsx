// 04 Predict keys: an iOS-style keyboard (cream keys, dark green field) slides up, "Predict keys" is typed letter
// by letter with key pop-ups while the 3-word prediction bar updates; the middle suggestion "keys" is tapped
// (turns green, word drops in gold), the send button turns gold, next prediction "orbit", keyboard slides away.
// Layout measured on ref/04-predict-keys (keyboard 690 x 383 ref px). The first 5 frames finish the Day dial's reverse wipe (it spills over in the ref).
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { F, clamp, easeOut } from "../lib";
import { DayDialScene } from "./day-dial-face";

// Medium shot (23 Nov): like the ref, the keyboard covers the chest ~0.6 face widths under the chin and fills the
// open area left of the panel (ref 690 px of 1080 -> ours 711 px, x 30-741).
const S = 1.03, X0 = 30, Y0 = 1092;
const FIELD = "#173827", FIELD_LINE = "#2d5a3f", KEY = "#f1ede3", SUG = "#e1d9c5", DARK = "#22402d", INKK = "#1d1d1b";
const GOLD = "#c9b56c", CREAMT = "#f1ece2";

const ROW1 = "qwertyuiop".split(""), ROW2 = "asdfghjkl".split(""), ROW3 = "zxcvbnm".split("");
const PITCH = 69.7, KW = 62, KH = 56;
const ROWY = [130, 196, 262, 328];

const keyX = (ch: string) => {
  let i = ROW1.indexOf(ch); if (i >= 0) return { x: i * PITCH, y: ROWY[0] };
  i = ROW2.indexOf(ch); if (i >= 0) return { x: 35 + i * PITCH, y: ROWY[1] };
  i = ROW3.indexOf(ch); return { x: 105 + i * PITCH, y: ROWY[2] };
};

const Key: React.FC<{ x: number; y: number; w?: number; dark?: boolean; children?: React.ReactNode; fs?: number }> = ({ x, y, w = KW, dark, children, fs = 32 }) => (
  <div style={{ position: "absolute", left: x, top: y, width: w, height: KH, borderRadius: 10, background: dark ? DARK : KEY,
    boxShadow: dark ? "0 1.5px 0 rgba(0,0,0,.45)" : "0 1.5px 0 rgba(60,50,30,.45)", display: "flex", alignItems: "center", justifyContent: "center",
    fontFamily: F.ui, fontSize: fs, color: dark ? CREAMT : INKK, paddingBottom: 3, boxSizing: "border-box" }}>{children}</div>
);

const Popup: React.FC<{ ch: string; o: number }> = ({ ch, o }) => {
  const { x, y } = keyX(ch);
  return (
    <div style={{ position: "absolute", left: x - 6, top: y - 62, width: KW + 12, height: KH + 62, opacity: o }}>
      <div style={{ position: "absolute", left: 0, top: 0, width: KW + 12, height: 66, borderRadius: 12, background: KEY,
        boxShadow: "0 3px 10px rgba(0,0,0,.35)", display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: F.ui, fontSize: 42, color: INKK }}>{ch}</div>
      <div style={{ position: "absolute", left: 6, top: 54, width: KW, height: KH + 8, borderRadius: "0 0 10px 10px", background: KEY }} />
    </div>
  );
};

const PredictKeys: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();

  // slide up 5 -> 7.5 (small overshoot settles by 10), slide down 23.5 -> 27
  const up = interpolate(f, [5, 7.5], [1, 0], { ...clamp, easing: easeOut });
  const settle = interpolate(f, [7.5, 10], [7, 0], { ...clamp, easing: easeOut });
  const down = interpolate(f, [23, 26.2], [0, 1], { ...clamp, easing: (x: number) => x * (0.55 + 0.45 * x) });
  const dy = up * 860 + (f >= 7.5 ? settle * S : 0) + down * 900;
  const show = f >= 5 && f < 26.4;

  // typing state
  let typed = "Predict ";
  let gold = "";
  let sug: [string, string, string] = ["the", "your", "what"];
  let thirdO = 1;
  if (f >= 9) { typed = "Predict k"; sug = ["k", "keys", "keep"]; }
  if (f >= 11.5) { typed = "Predict ke"; sug = ["ke", "keys", "keep"]; }
  if (f >= 14) { typed = "Predict key"; sug = ["key", "keys", "keyboard"]; thirdO = interpolate(f, [14, 16], [0.25, 1], clamp); }
  const tapped = f >= 16.5 && f < 21.5;
  if (f >= 16.5) { typed = "Predict "; }
  if (f >= 19) { typed = "Predict "; gold = "keys"; }
  if (f >= 21.5) { sug = [",", "orbit", "."]; thirdO = 1; }
  const sendGold = f >= 21.5;
  const midText = f >= 16.5 && f < 19 ? "keys" : f >= 19 && f < 21.5 ? "" : sug[1];
  const popK = f >= 9 && f < 11.5 ? 1 : 0;
  const popE = f >= 11.5 && f < 14 ? 1 : 0;
  const ringT = (f - 16.5) / 5;
  const caret = f < 16.5;

  return (
    <AbsoluteFill>
      {f < 5.5 && <DayDialScene T={24 + f} />}
      {show && (
        <div style={{ position: "absolute", left: X0, top: Y0, width: 690, height: 383, transformOrigin: "0 0",
          transform: `translateY(${dy}px) scale(${S})`, filter: "drop-shadow(0 6px 18px rgba(0,0,0,.35))" }}>
          {/* text field */}
          <div style={{ position: "absolute", left: 0, top: 0, width: 690, height: 63, borderRadius: 32, background: FIELD,
            border: `1.5px solid ${FIELD_LINE}`, boxSizing: "border-box" }}>
            <div style={{ position: "absolute", left: 24, top: 0, height: 60, display: "flex", alignItems: "center", fontFamily: F.ui,
              fontWeight: 600, fontSize: 36, letterSpacing: -0.4, color: CREAMT, whiteSpace: "pre" }}>
              <span>{typed}</span>{gold && <span style={{ color: GOLD }}>{gold}</span>}
              {caret && <span style={{ display: "inline-block", width: 2.5, height: 32, background: GOLD, marginLeft: 2 }} />}
            </div>
            <div style={{ position: "absolute", right: 9, top: 6, width: 48, height: 48, borderRadius: "50%", background: sendGold ? GOLD : CREAMT,
              display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width={26} height={28} viewBox="0 0 26 28"><path d="M13 25 V4 M4 12.5 L13 3.5 L22 12.5" stroke={FIELD} strokeWidth={3.6} fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
          </div>
          {/* prediction bar */}
          {sug.map((w, i) => {
            const mid = i === 1;
            const dark = mid && tapped;
            return (
              <div key={i} style={{ position: "absolute", left: i * 232.3, top: 73, width: 225.5, height: 47, borderRadius: 8,
                background: dark ? "#1f3e2c" : SUG, boxShadow: dark ? "none" : "0 1.5px 0 rgba(60,50,30,.35)", display: "flex", alignItems: "center",
                justifyContent: "center", fontFamily: F.ui, fontSize: 28, color: dark ? GOLD : INKK, opacity: i === 2 ? thirdO : 1 }}>
                {mid ? midText : w}
              </div>
            );
          })}
          {ringT >= 0 && ringT <= 1 && (
            <div style={{ position: "absolute", left: 345 - (36 + 10 * ringT), top: 96.5 - (36 + 10 * ringT), width: 2 * (36 + 10 * ringT),
              height: 2 * (36 + 10 * ringT), borderRadius: "50%", border: "2px solid rgba(236,232,220,.8)", opacity: 1 - ringT * 0.85 }} />
          )}
          {/* keys */}
          {ROW1.map((c, i) => <Key key={c} x={i * PITCH} y={ROWY[0]}>{c}</Key>)}
          {ROW2.map((c, i) => <Key key={c} x={35 + i * PITCH} y={ROWY[1]}>{c}</Key>)}
          <Key x={0} y={ROWY[2]} w={98} dark>
            <svg width={26} height={26} viewBox="0 0 26 26"><path d="M13 3 L23 13.5 H17.5 V22 H8.5 V13.5 H3 Z" fill="none" stroke={CREAMT} strokeWidth={2} strokeLinejoin="round" /></svg>
          </Key>
          {ROW3.map((c, i) => <Key key={c} x={105 + i * PITCH} y={ROWY[2]}>{c}</Key>)}
          <Key x={592} y={ROWY[2]} w={98} dark>
            <svg width={34} height={24} viewBox="0 0 34 24"><path d="M10 2 H31 V22 H10 L2 12 Z M16 7.5 L25 16.5 M25 7.5 L16 16.5" fill="none" stroke={CREAMT} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" /></svg>
          </Key>
          <Key x={0} y={ROWY[3]} w={102} dark fs={26}>123</Key>
          <Key x={108} y={ROWY[3]}>,</Key>
          <Key x={178} y={ROWY[3]} w={333} fs={25}>space</Key>
          <Key x={518} y={ROWY[3]}>.</Key>
          <Key x={588} y={ROWY[3]} w={102} dark fs={26}>return</Key>
          {popK > 0 && <Popup ch="k" o={popK} />}
          {popE > 0 && <Popup ch="e" o={popE} />}
        </div>
      )}
    </AbsoluteFill>
  );
};
export default PredictKeys;
