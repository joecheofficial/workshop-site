// Comment drop (the CTA), copied beat for beat from ref/09-comment-drop (10 fps frames, local seconds):
// 0.0 white comment field + big white "EDIT" letters fall in one by one with a bounce (0.0-0.8)
// 0.9 letters land in the field -> "EDIT to get access to these / + 40 more", Post turns dark green
// 1.2 posted: comment card (avatar, handle · now, text, outline heart + count)
// 1.5 reply card "you · now / EDIT" slides in under it; hearts fill red and the counts tick up
// 1.7 caption boxes stack: "Comment EDIT" / "to get access to these" / "+ 40 more effects"
import React from "react";
import { AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { F, clamp } from "../lib";
import CFG from "../config.json";

export const HANDLE = CFG.handle;
export const KEYWORD = CFG.keyword;
export const MORE_LINE = ""; // Illy 23 Nov: drop the "40 more" line
export const MORE_CAPTION = "";

const s = (sec: number) => Math.round(sec * 25);
const CARD = { x: 56, y: 290, w: 600 }; // v5 studio close-up: the cards sit just above his hair like the ref

const Heart: React.FC<{ filled: number; size?: number }> = ({ filled, size = 30 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24">
    <path d="M12 21s-7.5-4.6-9.6-9.2C.9 8.4 3 5 6.4 5c2.1 0 3.6 1.2 4.6 2.6C12 6.2 13.5 5 15.6 5 19 5 21.1 8.4 19.6 11.8 17.5 16.4 12 21 12 21z"
      fill={`rgba(206,52,72,${filled})`} stroke={filled > 0.5 ? "#ce3448" : "#6b6b6b"} strokeWidth={1.8} />
  </svg>
);

const Caption: React.FC<{ at: number; children: React.ReactNode; size?: number }> = ({ at, children, size = 64 }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const sp = spring({ frame: f - at, fps, config: { damping: 15, stiffness: 220, mass: 0.6 } });
  if (f < at) return null;
  return (
    <div style={{ display: "inline-block", background: "#fff", borderRadius: 18, padding: "4px 24px 12px", margin: "-2px 0",
      fontFamily: F.ui, fontWeight: 700, fontSize: size, letterSpacing: -1.6, color: "#111", lineHeight: 1.12,
      transform: `scale(${interpolate(sp, [0, 1], [0.6, 1])})`, opacity: Math.min(1, sp * 1.6) }}>{children}</div>
  );
};

const CommentDrop: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tPost = s(0.92), tCard = s(1.2), tReply = s(1.5);
  const appear = spring({ frame: f, fps, config: { damping: 18, stiffness: 260 } });
  const typedIn = f >= tPost;
  const posted = f >= tCard;
  const reply = spring({ frame: f - tReply, fps, config: { damping: 16, stiffness: 200 } });
  const likes1 = f < tReply ? 1 : Math.min(7, 1 + Math.floor((f - tReply) / 4));
  const heart1 = interpolate(f, [tReply, tReply + 3], [0, 1], clamp);
  const heart2 = interpolate(f, [s(2.6), s(2.6) + 3], [0, 1], clamp);
  const out = interpolate(f, [dur - 4, dur], [1, 0], clamp);

  // falling letters (only before they land in the field)
  const letters = KEYWORD.split("");
  const letterEls = !typedIn && letters.map((ch, i) => {
    const st = i * 3;
    const sp = spring({ frame: f - st, fps, config: { damping: 9, stiffness: 170, mass: 0.7 } });
    const sink = interpolate(f, [s(0.72), tPost], [0, 1], clamp); // letters drop into the field
    if (f < st) return null;
    return (
      <span key={i} style={{ display: "inline-block", transform: `translateY(${interpolate(sp, [0, 1], [-260, 0]) + sink * 120}px) scale(${1 - sink * 0.7})`,
        opacity: 1 - sink }}>{ch}</span>
    );
  });

  return (
    <AbsoluteFill style={{ opacity: out }}>
      {/* big EDIT letters above the field */}
      {!typedIn && (
        <div style={{ position: "absolute", left: CARD.x, top: CARD.y - 215, width: 560, textAlign: "center", fontFamily: F.ui, fontWeight: 800,
          fontSize: 196, letterSpacing: -5, color: "#f4f1ea", textShadow: "0 6px 24px rgba(0,0,0,.35)" }}>{letterEls}</div>
      )}

      {/* the field, then the posted comment */}
      <div style={{ position: "absolute", left: CARD.x, top: CARD.y + (posted ? -60 : 0), width: CARD.w, minHeight: 112, background: "#fff", borderRadius: 18,
        boxShadow: "0 12px 40px rgba(0,0,0,.35)", transform: `scale(${interpolate(appear, [0, 1], [0.85, 1])})`, opacity: appear,
        display: "flex", alignItems: posted ? "flex-start" : "center", padding: posted ? "18px 22px" : "0 22px", boxSizing: "border-box", fontFamily: F.ui }}>
        <Img src={staticFile("comment-drop/avatar.png")} style={{ width: 52, height: 52, borderRadius: 26, marginRight: 16, flexShrink: 0 }} />
        {!posted && (
          <>
            <div style={{ flex: 1, fontSize: 26, color: typedIn ? "#111" : "#8a8a8a", lineHeight: 1.25 }}>
              {typedIn ? (<><b>{KEYWORD}</b> to get access to these</>) :
                (<><span style={{ display: "inline-block", width: 2, height: 30, background: "#111", verticalAlign: "middle", marginRight: 2, opacity: Math.floor(f / 6) % 2 ? 0 : 1 }} />Add a comment...</>)}
            </div>
            <div style={{ padding: "8px 20px", borderRadius: 22, fontSize: 24, fontWeight: 600, background: typedIn ? "#1f3d2b" : "#ecebe6", color: typedIn ? "#fff" : "#555" }}>Post</div>
          </>
        )}
        {posted && (
          <>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 19, color: "#222", fontWeight: 600 }}>{HANDLE} <span style={{ color: "#8a8a8a", fontWeight: 400 }}>· now</span></div>
              <div style={{ fontSize: 27, color: "#111", lineHeight: 1.25, marginTop: 4 }}><b>{KEYWORD}</b> to get access to these</div>
            </div>
            <div style={{ textAlign: "center", width: 40, marginTop: 6 }}>
              <Heart filled={heart1} />
              <div style={{ fontSize: 15, color: "#6b6b6b", marginTop: -2 }}>{likes1}</div>
            </div>
          </>
        )}
      </div>

      {/* reply card */}
      {f >= tReply && (
        <div style={{ position: "absolute", left: CARD.x + 60, top: CARD.y + 76, width: CARD.w - 60, height: 96, background: "#fff", borderRadius: 18,
          boxShadow: "0 10px 30px rgba(0,0,0,.3)", display: "flex", alignItems: "center", padding: "0 22px", boxSizing: "border-box", fontFamily: F.ui,
          transform: `translateY(${interpolate(reply, [0, 1], [-30, 0])}px)`, opacity: reply }}>
          <div style={{ width: 46, height: 46, borderRadius: 23, background: "#dfe6e1", marginRight: 16, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width={26} height={26} viewBox="0 0 24 24"><circle cx={12} cy={9} r={4.2} fill="#7d8c82" /><path d="M4 21c1.2-4.2 4.4-6 8-6s6.8 1.8 8 6" fill="#7d8c82" /></svg>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 18, color: "#222", fontWeight: 600 }}>you <span style={{ color: "#8a8a8a", fontWeight: 400 }}>· now</span></div>
            <div style={{ fontSize: 26, fontWeight: 800, color: "#111" }}>{KEYWORD}</div>
          </div>
          <div style={{ textAlign: "center", width: 40 }}>
            <Heart filled={heart2} size={26} />
            {heart2 > 0.5 && <div style={{ fontSize: 14, color: "#6b6b6b", marginTop: -2 }}>1</div>}
          </div>
        </div>
      )}

      {/* stacked caption boxes over his chest */}
      <div style={{ position: "absolute", left: 20, top: 1150, width: 720, textAlign: "center" }}>
        <div><Caption at={s(1.62)}>Comment <span style={{ fontWeight: 800 }}>{KEYWORD}</span></Caption></div>
        <div><Caption at={s(2.05)}>to get access to these</Caption></div>
      </div>
    </AbsoluteFill>
  );
};
export default CommentDrop;
