// 08 Letter dive (chrome hidden). Copied from ref/08-letter-dive: cream paper slides down over the picture,
// a huge serif "dive." types on letter by letter (local 2 / 4 / 5 / 6 / 7) and every letter is a window onto the
// live video (the "i" dot lands on Joe's eye), it holds, then the camera dives into the "i" stem (scale grows
// exponentially around the stem: 1 -> 1.26 -> 2.2 -> 6.3 -> 24, measured on the ref) until the stem is the whole
// frame and the normal shot (with the list panel) is back.
import React from "react";
import { AbsoluteFill, Sequence, interpolate, useCurrentFrame } from "remotion";
import { Backdrop, Joe, W, H, clamp, fr, TIMELINE } from "../lib";
import { Panel } from "../chrome";
import G from "./letter-dive-glyphs";

const PAPER = "#f0ebdf";
// layout: word width fitted to the frame like the ref (x 40 -> 1045), slightly condensed serif
const SX = 0.86, S = 1005 / ((G.glyphs[4].box[2] - G.glyphs[0].box[0]) * SX); // glyph px (size 1000) -> frame px
const X0 = 40 - G.glyphs[0].box[0] * S * SX;
const BASE = 1114;                                   // baseline: the i dot lands on Joe's upper face (x ~390, y ~735) like the ref (medium shot)
const iBox = G.glyphs[1].box;
const OX = X0 + ((iBox[0] + iBox[2]) / 2) * S * SX; // dive origin = centre of the i stem
const OY = BASE - 0.47 * 481 * S;                   // ref: origin 0.47 x-height above the baseline
const TYPE_AT = [2, 4, 5, 6, 7];                     // local frame each letter appears
// zoom keyframes (local frame -> log scale), from the ref: 10:1, 12.5:1.26, 15:2.2, 17.5:6.3, 20:24
const ZK = [10, 12.5, 15, 17.5, 20, 22.5];
const ZL = [0, Math.log(1.26), Math.log(2.2), Math.log(4.9), Math.log(18.5), Math.log(140)];

const LivePanel: React.FC = () => {
  const cta = TIMELINE.find((it) => it.id === "comment-drop")!;
  const me = TIMELINE.find((it) => it.id === "letter-dive")!;
  return (
    <Sequence from={-fr(me.start)} layout="none">
      <Panel goldFrom={fr(cta.start + 2.6)} />
    </Sequence>
  );
};

const LetterDive: React.FC<{ dur: number }> = ({ dur }) => {
  // all keyframes are ref frames (ref window 24 frames); our window is longer, so play them stretched to fit
  const f = (useCurrentFrame() * 24) / dur;
  const paperBottom = interpolate(f, [-1.5, 1.4], [0, H], clamp);
  const zoom = Math.exp(interpolate(f, ZK, ZL, clamp));
  const done = zoom > 120;
  const roomDim = interpolate(f, [1.6, 2, 18, 21], [1, 0.42, 0.42, 1], clamp);
  const showPanel = f < 2 || f >= 19;
  const lettersOn = f >= TYPE_AT[0];
  const glyphs = G.glyphs.filter((_, i) => f >= TYPE_AT[i]);
  const tf = `translate(${OX} ${OY}) scale(${zoom}) translate(${-OX} ${-OY}) translate(${X0} ${BASE}) scale(${S * SX} ${S})`;
  return (
    <AbsoluteFill>
      {/* the live picture behind the paper (room dimmed while it only shows through the letters) */}
      <Backdrop style={{ filter: roomDim < 1 ? `brightness(${roomDim})` : undefined }} />
      <Joe />
      {showPanel && <LivePanel />}
      {!done && (
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", left: 0, top: 0 }}>
          <defs>
            <mask id="ld-holes" maskUnits="userSpaceOnUse" x={0} y={0} width={W} height={H}>
              <rect x={0} y={0} width={W} height={lettersOn ? H : paperBottom} fill="#fff" />
              <g transform={tf}>{glyphs.map((g, i) => <path key={i} d={g.d} fill="#000" />)}</g>
            </mask>
            <clipPath id="ld-clip"><g transform={tf}>{glyphs.map((g, i) => <path key={i} d={g.d} />)}</g></clipPath>
            <filter id="ld-blur" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation={14} /></filter>
          </defs>
          {/* soft inner shadow at the letter edges, like light falling into a cut-out */}
          {lettersOn && zoom < 30 && (
            <g clipPath="url(#ld-clip)">
              <g transform={tf} filter="url(#ld-blur)" opacity={0.55}>
                {glyphs.map((g, i) => <path key={i} d={g.d} fill="none" stroke="#000" strokeWidth={34} />)}
              </g>
            </g>
          )}
          <rect x={0} y={0} width={W} height={H} fill={PAPER} mask="url(#ld-holes)" />
        </svg>
      )}
    </AbsoluteFill>
  );
};
export default LetterDive;
