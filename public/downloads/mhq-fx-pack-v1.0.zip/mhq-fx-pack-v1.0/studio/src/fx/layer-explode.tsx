// 09 Layer explode (chrome hidden). Copied from ref/10-layer-explode: the whole frame (room, Joe, list, title)
// shrinks and swings into 3D over dark green, a serif "layer" punches in with an extruded edge, then the frame
// splits into five outlined glass planes along depth: ROOM (clean plate), TYPE ("layer explode"), ME (Joe cut-out),
// LIST (the panel), SOUND (cream/pink waveform), each labelled in mono above its top-left corner, tops on one line,
// floor edges joined like a box. It drifts, then slams back together into the normal frame. Motion blur on the
// fast moves = sub-frame samples averaged.
import React from "react";
import { AbsoluteFill, Sequence, interpolate, useCurrentFrame } from "remotion";
import { Backdrop, Joe, F, W, H, clamp, fr, TIMELINE, easeOut, easeInOut } from "../lib";
import { Panel } from "../chrome";
import { Easing } from "remotion";
import G from "./layer-explode-glyphs";

const BG = "#09150f";
const CREAM = "#f1ece0";
const P = 3000;                       // CSS perspective (px)
const LABELS = ["ROOM", "TYPE", "ME", "LIST", "SOUND"];
const easeIn = Easing.bezier(0.55, 0, 0.9, 0.45);

// ---- motion curves (local frames, measured on the ref: shrink 3.5-12, split 13-18, hold/drift, collapse 26-33.5)
const curves = (t: number) => {
  const a = interpolate(t, [3.5, 5, 7.5, 10, 12.5], [0, 0.2, 0.7, 0.94, 1], clamp);
  const sep = interpolate(t, [13.2, 18.4], [0, 1], { ...clamp, easing: easeInOut });
  const drift = interpolate(t, [18, 26], [0, 1], clamp);
  const c = interpolate(t, [26, 27.5, 30, 32.5, 33.6], [0, 0.15, 0.7, 0.95, 1], clamp);
  const k = a * (1 - c);              // how far from the flat full frame
  const s = 1 - 0.35 * k;              // stack scale
  const rot = (32 + 2.5 * drift) * k; // deg, left edge nearer
  const gap = (360 + 30 * drift) * sep * (1 - c);       // depth between planes (plane px)
  const xc = 540 + (-20 + 215 * sep) * k;                  // screen x of the stack's top centre
  const yt = 300 * k;                                     // screen y of the planes' top edge
  return { a, sep, c, k, s, rot, gap, xc, yt };
};

// waveform: deterministic bursts and thin dashes, like the ref
const rnd = (i: number) => { const x = Math.sin(i * 91.7 + 13.3) * 43758.5453; return x - Math.floor(x); };
const BARS = Array.from({ length: 120 }, (_, i) => {
  const u = i / 119;
  const env = Math.max(0.05, Math.abs(Math.sin(u * 9.5 + 0.6)) * (0.55 + 0.45 * Math.sin(u * 3.1 + 1)) );
  const quiet = (u > 0.08 && u < 0.2) || (u > 0.66 && u < 0.72);
  return quiet ? 0.035 : env * (0.45 + 0.55 * rnd(i));
});
const Wave: React.FC<{ grow: number }> = ({ grow }) => {
  const x0 = 130, x1 = 1000, cy = 1655, maxH = 200, play = 0.56;
  const bw = (x1 - x0) / BARS.length;
  return (
    <svg width={W} height={H} style={{ position: "absolute", left: 0, top: 0 }}>
      {BARS.map((v, i) => {
        if (i / BARS.length > grow) return null;
        const h = Math.max(5, v * maxH);
        const x = x0 + i * bw;
        return <rect key={i} x={x} y={cy - h / 2} width={bw * 0.55} height={h} rx={bw * 0.27}
          fill={i / BARS.length < play ? "#ece6d6" : "#c25a6e"} />;
      })}
      {grow > play && <rect x={x0 + play * (x1 - x0) - 2} y={cy - maxH * 0.62} width={4} height={maxH * 1.24} fill="#ece6d6" opacity={0.9} />}
    </svg>
  );
};

const TS = 210 / 1000, TSX = 0.82; // type size: glyphs are at size 1000
const Word: React.FC<{ g: typeof G.layer; x: number; y: number; fill: string }> = ({ g, x, y, fill }) => (
  <g transform={`translate(${x} ${y}) scale(${TS * TSX} ${TS})`}>{g.glyphs.map((gl, i) => <path key={i} d={gl.d} fill={fill} />)}</g>
);
const Type: React.FC<{ t: number; extrude: number; fade: number }> = ({ t, extrude, fade }) => {
  const showExplode = t >= 14;
  if (t < 4 || fade <= 0) return null;
  const lines = (fill: string) => (
    <>
      <Word g={G.layer} x={78} y={420} fill={fill} />
      {showExplode && <Word g={G.explode} x={78} y={600} fill={fill} />}
    </>
  );
  return (
    <svg width={W} height={H} style={{ position: "absolute", left: 0, top: 0, overflow: "visible", opacity: fade }}>
      {extrude > 0.01 && Array.from({ length: 9 }, (_, i) => (
        <g key={i} transform={`translate(${(9 - i) * 2.2 * extrude} ${(9 - i) * 3.2 * extrude})`} opacity={0.9}>
          {lines(i < 8 ? "#8f8f89" : "#bdbcb4")}
        </g>
      ))}
      {lines(CREAM)}
    </svg>
  );
};

const LivePanel: React.FC = () => {
  const cta = TIMELINE.find((it) => it.id === "comment-drop")!;
  const me = TIMELINE.find((it) => it.id === "layer-explode")!;
  return (
    <Sequence from={-fr(me.start)} layout="none">
      <Panel goldFrom={fr(cta.start + 2.6)} />
    </Sequence>
  );
};

// project a plane point (plane px, origin = plane top-centre) to the screen
const project = (cv: ReturnType<typeof curves>, x: number, y: number, z: number) => {
  const r = (cv.rot * Math.PI) / 180;
  const X = (x * Math.cos(r) + z * Math.sin(r)) * cv.s;
  const Z = (-x * Math.sin(r) + z * Math.cos(r)) * cv.s;
  const k = P / (P - Z);
  return { x: cv.xc + X * k, y: cv.yt + y * cv.s * k, k };
};

const Stack: React.FC<{ t: number; opacity?: number }> = ({ t, opacity = 1 }) => {
  const cv = curves(t);
  const zs = [0, 1, 2, 3, 4].map((i) => (i - 4) * cv.gap); // ROOM back ... SOUND front
  const border = cv.sep * (1 - cv.c);
  const extrude = interpolate(t, [4, 7, 11, 13, 15, 17.5], [1, 0.8, 0, 0, 0.7, 0], clamp) * (1 - cv.c);
  const bw = 2.2 / cv.s;
  const plane = (i: number, child: React.ReactNode) => (
    <div key={i} style={{ position: "absolute", left: 0, top: 0, width: W, height: H, transform: `translateZ(${zs[i]}px)`,
      outline: border > 0.01 ? `${bw}px solid rgba(236,233,222,${0.85 * border})` : undefined,
      background: i > 0 && border > 0.01 ? `rgba(255,255,255,${0.025 * border})` : undefined, overflow: "hidden" }}>
      {child}
    </div>
  );
  const corners = zs.map((z) => ({
    bl: project(cv, -540, 1920, z), br: project(cv, 540, 1920, z), tl: project(cv, -540, 0, z),
  }));
  return (
    <AbsoluteFill style={{ opacity }}>
      <div style={{ position: "absolute", inset: 0, perspective: P, perspectiveOrigin: `${cv.xc}px ${cv.yt}px` }}>
        <div style={{ position: "absolute", left: 0, top: 0, width: W, height: H, transformStyle: "preserve-3d",
          transformOrigin: "540px 0px", transform: `translate(${cv.xc - 540}px, ${cv.yt}px) scale3d(${cv.s},${cv.s},${cv.s}) rotateY(${cv.rot}deg)` }}>
          {plane(0, <Backdrop />)}
          {plane(1, <Type t={t} extrude={extrude} fade={1 - cv.c * 1.6} />)}
          {plane(2, <Joe />)}
          {plane(3, <LivePanel />)}
          {plane(4, t >= 11.5 && cv.c < 0.9 ? <div style={{ opacity: 1 - cv.c / 0.9 }}><Wave grow={interpolate(t, [11.5, 16.5], [0.04, 1], clamp)} /></div> : null)}
        </div>
      </div>
      {border > 0.01 && (
        <svg width={W} height={H} style={{ position: "absolute", left: 0, top: 0 }}>
          <g stroke={`rgba(236,233,222,${0.8 * border})`} strokeWidth={2} fill="none">
            <line x1={corners[0].bl.x} y1={corners[0].bl.y} x2={corners[4].bl.x} y2={corners[4].bl.y} />
            <line x1={corners[0].br.x} y1={corners[0].br.y} x2={corners[4].br.x} y2={corners[4].br.y} />
          </g>
          {corners.map((cn, i) => (
            <text key={i} x={cn.tl.x + 4} y={cn.tl.y - 22 * cn.tl.k} fontFamily={F.mono} fontSize={27 * cn.tl.k}
              letterSpacing={1.6 * cn.tl.k} fill={CREAM} opacity={border}>{LABELS[i]}</text>
          ))}
        </svg>
      )}
    </AbsoluteFill>
  );
};

// motion blur: average sub-frame samples while things move fast
const speed = (t: number) => {
  const a = curves(t), b = curves(t + 0.5);
  return Math.abs(a.s - b.s) * 6 + Math.abs(a.rot - b.rot) / 6 + Math.abs(a.gap - b.gap) / 90;
};
const LayerExplode: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  const n = Math.max(1, Math.min(6, Math.round(speed(f) * 4)));
  const span = 0.7; // frames of shutter
  return (
    <AbsoluteFill style={{ background: BG }}>
      {Array.from({ length: n }, (_, i) => {
        const t = n === 1 ? f : f - span * (i / (n - 1));
        return <Stack key={i} t={t} opacity={1 / (i + 1)} />;
      })}
    </AbsoluteFill>
  );
};
export default LayerExplode;
