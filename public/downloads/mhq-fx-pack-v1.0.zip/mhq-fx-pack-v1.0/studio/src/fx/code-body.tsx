// 06 Code body. Copied from ref/06-code-body: a thin white scan line sweeps DOWN the frame (local ~2.3 -> 6.7),
// behind it the picture turns into monospace code (room = dark green with faint code, Joe = cells coloured by his
// own picture, big mosaic cells first, then finer at local 12 / 14 / 17), then the line sweeps back UP
// (local ~22.3 -> 26.7) and the live picture returns. Per-frame code pictures are precomputed by
// tools/code-body-gen.py into media/code-body/NN.png (text = our own Remotion code, never his).
import React from "react";
import { AbsoluteFill, Img, interpolate, useCurrentFrame } from "remotion";
import { MEDIA, W, H, clamp } from "../lib";

// ref timing (27.5-frame window), scaled to our window so the sweep back UP always plays
const REF_DUR = 27.5;
const DOWN0: [number, number] = [2.3, 6.7]; // local frames: line at y=0 -> y=H
const UP0: [number, number] = [22.3, 26.7]; // line at y=H -> y=0

const ScanLine: React.FC<{ y: number }> = ({ y }) => (
  <div style={{ position: "absolute", left: 0, top: y - 1.5, width: W, height: 3, background: "#f4f1e8",
    boxShadow: "0 0 6px rgba(244,241,232,.55), 0 0 18px rgba(244,241,232,.18)" }} />
);

const CodeBody: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const r = dur / REF_DUR;
  const DOWN: [number, number] = [DOWN0[0] * r, DOWN0[1] * r];
  const UP: [number, number] = [UP0[0] * r, UP0[1] * r];
  if (f < DOWN[0]) return null;
  const idx = Math.max(0, Math.min(dur - 1, f));
  const src = `${MEDIA}/code-body/${String(idx).padStart(2, "0")}.png`;
  let edge = H; // code visible for y < edge
  let line: number | null = null;
  if (f < DOWN[1]) { edge = interpolate(f, DOWN, [0, H], clamp); line = edge; }
  else if (f >= UP[0]) { edge = interpolate(f, UP, [H, 0], clamp); line = edge; }
  if (edge <= 0) return null;
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ clipPath: `inset(0 0 ${H - edge}px 0)` }}>
        <Img src={src} style={{ width: W, height: H }} />
      </AbsoluteFill>
      {line !== null && <ScanLine y={line} />}
    </AbsoluteFill>
  );
};
export default CodeBody;
