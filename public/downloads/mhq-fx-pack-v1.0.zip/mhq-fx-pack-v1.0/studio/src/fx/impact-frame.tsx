// Impact frame: full-screen manga panel (chrome hidden), copied from ref/17-impact-frame (10 fps, local s):
// 0.0-0.1 NEGATIVE flash (black paper, cream figure, white speed lines), frame zoomed in ~10% and knocked off-centre
// 0.2-0.7 positive: cream paper, dense radial speed lines that re-draw every frame, Joe as live bold ink line art
//         (tools/impact-frame-ink.py -> media/impact-frame/), huge cream "IMPACT" with a black outline across the
//         lower body, speed lines run on below the word (white over the black shirt)
// 0.8+    hard cut back to the normal picture + panel.
import React from "react";
import { AbsoluteFill, Img, interpolate, Sequence, useCurrentFrame } from "remotion";
import { useAbs, MEDIA, TIMELINE, fr, clamp, easeOut } from "../lib";
const _w = (id: string) => { const it = TIMELINE.find((x) => x.id === id)!; return [fr(it.start), fr(it.end) - 1]; };

import { Panel } from "../chrome";

const CREAM = "#f0ebde";
const INKC = "#121110";
// media/impact-frame is rendered in PORTRAIT space by tools/impact-frame-ink.py (face 540 px wide, head top y 340,
// face centred at x 540): Joe head-and-shoulders big like the reference, drawn full-frame at 0,0.
const CX = 540, CY = 730;  // speed-line focus = his face
const TEXT_TOP = 1500;
const END0 = 19;         // first local frame of the normal picture again in the ref's 29-frame window (scaled to ours)

const rnd = (i: number, s: number) => { const x = Math.sin(i * 12.9898 + s * 78.233) * 43758.5453; return x - Math.floor(x); };

/** Radial speed lines as thin wedges (sharp at the inner end), a fresh set every frame like the reference. */
const SpeedLines: React.FC<{ seed: number; fill: string }> = ({ seed, fill }) => {
  const paths: string[] = [];
  const n = 560;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + (rnd(i, seed) - 0.5) * (Math.PI * 2 / n) * 1.6;
    // inner radius: most stop well short of the figure, some reach in close
    const r0 = 300 + Math.pow(rnd(i, seed + 1), 1.4) * 520;
    const r1 = 1500;
    const w = 0.7 + Math.pow(rnd(i, seed + 2), 2.4) * 6.5; // half-width at r1: mostly fine lines, some heavy strokes
    const ca = Math.cos(a), sa = Math.sin(a);
    const px = -sa, py = ca;
    const x0 = CX + ca * r0, y0 = CY + sa * r0 * 1.12;
    const x1 = CX + ca * r1, y1 = CY + sa * r1 * 1.12;
    paths.push(`M${x0.toFixed(1)} ${y0.toFixed(1)}L${(x1 + px * w).toFixed(1)} ${(y1 + py * w).toFixed(1)}L${(x1 - px * w).toFixed(1)} ${(y1 - py * w).toFixed(1)}Z`);
    // some lines come in pairs/clusters like inked speed lines
    if (rnd(i, seed + 3) > 0.7) {
      const a2 = a + 0.006;
      const r02 = r0 + 30 + rnd(i, seed + 4) * 120;
      const c2 = Math.cos(a2), s2 = Math.sin(a2), w2 = w * 0.5;
      paths.push(`M${(CX + c2 * r02).toFixed(1)} ${(CY + s2 * r02 * 1.12).toFixed(1)}L${(CX + c2 * r1 - s2 * w2).toFixed(1)} ${(CY + s2 * r1 * 1.12 + c2 * w2).toFixed(1)}L${(CX + c2 * r1 + s2 * w2).toFixed(1)} ${(CY + s2 * r1 * 1.12 - c2 * w2).toFixed(1)}Z`);
    }
  }
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
      <path d={paths.join("")} fill={fill} />
    </svg>
  );
};

const ImpactFrame: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const END = Math.round((END0 * dur) / 29);
  const abs = useAbs();
  const me = TIMELINE.find((it) => it.id === "impact-frame")!;
  const cta = TIMELINE.find((it) => it.id === "comment-drop")!;
  const start = fr(me.start);
  if (f >= END) {
    return me.chrome === "hide" ? (
      <Sequence from={-start} layout="none"><Panel goldFrom={fr(cta.start + 2.6)} /></Sequence>
    ) : null;
  }
  const neg = f < 4;
  // entry punch: zoomed + knocked off-centre on frame 0, settles by ~frame 5
  const z = interpolate(f, [0, 2, 5], [1.11, 1.035, 1], { ...clamp, easing: easeOut });
  const shx = [-26, 14, -8, 4, -2, 0][Math.min(5, f)] ?? 0;
  const shy = [-40, -12, 6, -3, 1, 0][Math.min(5, f)] ?? 0;
  const [wa, wb] = _w("impact-frame");
  const ink = `${MEDIA}/impact-frame/${String(Math.min(wb, Math.max(wa, abs))).padStart(5, "0")}.png`;
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <svg width={0} height={0} style={{ position: "absolute" }}>
        {/* negative = swap ink and paper (black paper, cream figure), not a plain invert */}
        <filter id="impact-neg" colorInterpolationFilters="sRGB">
          <feColorMatrix type="matrix" values={[0.941, 0.922, 0.871].map((c, i) => {
            const k = -([0.873, 0.851, 0.8][i]) / 0.86; // stretch so the paper lands on full black, ink on cream
            return [k * 0.299, k * 0.587, k * 0.114, 0, c - k * 0.07].map((v) => v.toFixed(4)).join(" ");
          }).concat(["0 0 0 1 0"]).join("  ")} />
        </filter>
      </svg>
      <AbsoluteFill style={{ filter: neg ? "url(#impact-neg)" : undefined }}>
        <AbsoluteFill style={{ background: CREAM, transform: `translate(${shx}px, ${shy}px) scale(${z})`, transformOrigin: `${CX}px ${CY}px` }}>
          <SpeedLines seed={f * 7 + 1} fill={INKC} />
          <Img src={ink} style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920 }} />
          {/* speed lines carry on under the word: white over the black shirt, black over the paper */}
          <AbsoluteFill style={{ mixBlendMode: "difference", clipPath: `inset(${TEXT_TOP + 120}px 0 0 0)` }}>
            <SpeedLines seed={f * 7 + 4} fill="#ffffff" />
          </AbsoluteFill>
          <div style={{ position: "absolute", left: 0, width: 1080, top: TEXT_TOP, textAlign: "center",
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontWeight: 800, fontSize: 252, letterSpacing: -9, lineHeight: 1,
            color: CREAM, WebkitTextStroke: `16px ${INKC}`, paintOrder: "stroke fill" } as React.CSSProperties}>
            IMPACT
          </div>
          <div style={{ position: "absolute", left: 0, width: 1080, top: TEXT_TOP, textAlign: "center",
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontWeight: 800, fontSize: 252, letterSpacing: -9, lineHeight: 1,
            color: CREAM, WebkitTextStroke: `3px ${CREAM}` }}>
            IMPACT
          </div>
        </AbsoluteFill>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
export default ImpactFrame;
