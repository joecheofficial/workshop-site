// 07 Post wall. Copied from ref/07-post-wall: a contributions-style wall of small squares (one per day, one row
// per month, ragged month ends) wipes in from the bottom BEHIND Joe, header "DAY 046 ... 1,577 POSTS" counts up
// while the days fill from the bottom-left start upward (newest ~1.5 rows cream, then they settle into
// sage / light sage / cream / gold / dark green / black), numbers turn gold and today's square pops, then the
// wall wipes away bottom-up. Joe is redrawn on top so the wall sits behind him.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Joe, C, F, clamp, easeOut, easeInOut } from "../lib";
import CFG from "../config.json";

// PLACEHOLDER totals: must be checked against Joe's real numbers before posting.
export const POSTS_TOTAL = CFG.posts_total;

const P = 22, CELL = 18, X0 = 44; // pitch, square, left edge (ref: x 44-722, 31 columns)
const TOP = 350;                 // y of the header row (row 0)
const MONTHS = [31, 30, 31, 31, 30, 31, 30, 31, 31, 28, 31, 30, 31, 30, 31, 31];
type Cell = { c: number; r: number; day: number }; // day -1 = no data
const build = () => {
  const rows: number[][] = [];
  rows.push([0, 1]);                                   // header row: today's square sits here
  MONTHS.forEach((len) => rows.push([...Array(len).keys()]));
  rows.push([...Array(31).keys()]);                    // first month: starts mid-row (col 21)
  rows.push([...Array(31).keys()]);                    // no-data rows
  rows.push([...Array(31).keys()]);
  rows.push([...Array(8).keys()].map((k) => k + 22));
  const startRow = rows.length - 4;
  const cells: Cell[] = [];
  let day = 0;
  for (let r = startRow; r >= 0; r--) {
    for (const c of rows[r]) {
      const filled = !(r === startRow && c < 21);
      cells.push({ c, r, day: filled ? day++ : -1 });
    }
  }
  for (let r = startRow + 1; r < rows.length; r++) for (const c of rows[r]) cells.push({ c, r, day: -1 });
  return { cells, total: day, nRows: rows.length };
};
const GRID = build();
export const DAYS_TOTAL = GRID.total; // PLACEHOLDER: follows the grid size (ref showed 564)

// deterministic final colour per day (ref palette, sampled)
const PAL = ["#8e9a8b", "#8e9a8b", "#8e9a8b", "#8e9a8b", "#aeb8ab", "#aeb8ab", "#e8e2cd", "#c6aa5b", "#203a2a", "#203a2a", "#0b0e0c"];
const rnd = (i: number) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const finalCol = (d: number) => PAL[Math.floor(rnd(d) * PAL.length)];
const NEW = "#f1ede1";

const mix = (a: string, b: string, t: number) => {
  const h = (s: string) => [1, 3, 5].map((i) => parseInt(s.slice(i, i + 2), 16));
  const A = h(a), B = h(b);
  return `rgb(${A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(",")})`;
};

// keyframes measured on the ref (local frame -> fraction of the final number)
const KF = [4, 5, 7.5, 10, 12.5, 15, 16.6];
const DAYF = [0, 0.082, 0.227, 0.424, 0.665, 0.949, 1];
const POSTF = [0, 0.039, 0.143, 0.332, 0.594, 0.922, 1];

const PostWall: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  const head = interpolate(f, KF, DAYF, clamp) * GRID.total;
  const days = Math.round(head);
  const posts = Math.round(interpolate(f, KF, POSTF, clamp) * POSTS_TOTAL);
  const gold = interpolate(f, [16.4, 17.6], [0, 1], clamp);
  const gridTop = TOP, gridBot = TOP + GRID.nRows * P;
  // entry: revealed from the bottom up; exit: hidden from the bottom up
  const inP = interpolate(f, [0.5, 4.6], [0, 1], { ...clamp, easing: easeOut });
  const outP = interpolate(f, [21.4, 24.4], [0, 1], { ...clamp, easing: easeInOut });
  const visTop = gridBot - (gridBot - gridTop + 40) * inP;
  const visBot = gridBot - (gridBot - gridTop + 40) * outP;
  const legendOn = f < 21.6 && inP > 0.05;
  const headerOn = f >= 4 && f < 24;
  const pop = interpolate(f, [16.4, 17.4, 19.6], [1, 2.05, 1], clamp);
  const numCol = mix("#f1ede1", C.goldBright, gold);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ clipPath: `inset(${visTop - 6}px 0 ${1920 - visBot}px 0)` }}>
        {GRID.cells.map((cell, i) => {
          const x = X0 + cell.c * P, y = gridTop + cell.r * P;
          const isToday = cell.day === GRID.total - 1;
          let style: React.CSSProperties;
          if (cell.day < 0 || cell.day >= head) {
            style = { background: "rgba(8,12,10,.55)", border: "1.5px solid rgba(178,186,174,.55)" };
          } else {
            const age = head - cell.day;
            const t = Math.max(interpolate(age, [30, 58], [0, 1], clamp), interpolate(f, [16, 17.6], [0, 1], clamp));
            style = { background: mix(NEW, finalCol(cell.day), t) };
            if (isToday) style = { background: mix(NEW, C.goldBright, gold) };
          }
          const s = isToday ? pop : 1;
          return <div key={i} style={{ position: "absolute", left: x, top: y, width: CELL, height: CELL, borderRadius: 1.5,
            boxSizing: "border-box", transform: s !== 1 ? `scale(${s})` : undefined, transformOrigin: "50% 50%", zIndex: isToday ? 2 : 1, ...style }} />;
        })}
      </AbsoluteFill>
      {legendOn && (
        <div style={{ position: "absolute", left: 110, top: gridBot + 18, display: "flex", alignItems: "center", gap: 8,
          clipPath: `inset(0 0 ${Math.max(0, gridBot + 50 - visBot)}px 0)` }}>
          <div style={{ width: 13, height: 13, boxSizing: "border-box", border: "1.5px solid rgba(190,196,186,.75)" }} />
          <span style={{ fontFamily: F.mono, fontSize: 15, letterSpacing: 3.2, color: "rgba(205,208,198,.85)" }}>NO DATA</span>
        </div>
      )}
      {headerOn && (
        <>
          <div style={{ position: "absolute", left: 96, top: TOP - 4, display: "flex", alignItems: "baseline", gap: 18 }}>
            <span style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: 3.5, color: "#e9e5d8" }}>DAY</span>
            <span style={{ fontFamily: F.mono, fontSize: 25, fontWeight: 600, letterSpacing: 0.5, color: numCol }}>
              {String(days).padStart(3, "0")}</span>
          </div>
          <div style={{ position: "absolute", right: 1080 - 722, top: TOP - 52, display: "flex", alignItems: "baseline", gap: 12 }}>
            <span style={{ fontFamily: F.mono, fontSize: 58, fontWeight: 600, letterSpacing: -1, color: numCol, lineHeight: 1 }}>
              {posts.toLocaleString("en-US")}</span>
            <span style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: 3.2, color: "#e9e5d8" }}>POSTS</span>
          </div>
        </>
      )}
      <Joe />
    </AbsoluteFill>
  );
};
export default PostWall;
