// Banknote (chrome hidden), copied from ref/15-banknote + the 30 fps video, re-laid for 9:16:
//  - full-screen engraved note: green ink on cream paper, guilloche side bands, wavy moire field, a portrait oval with a
//    zig-zag lattice rim, mesh band and a cream text band with lettering running round it, two spirograph rosettes
//    (left one carries the name), rope-bordered corner boxes + red serial box on top, a big number box, rope boxes below.
//    Static art: public/banknote/base.png (tools/banknote-base.py).
//  - the portrait is LIVE: every frame of Joe is engraved (tools/banknote-engrave.py -> media/banknote/NNNNN.png):
//    contour-bent line engraving, width follows darkness, cross-hatched shadows, dark concentric guilloche behind him.
//  - motion (measured): the note lands 3.5 % zoomed and settles in 3 frames; the number types in digit by digit
//    (corner boxes in sync); the final "." lands with a 2.4 % punch that settles in 3 frames. Then it holds.
// Words from config.json: number / title / serial from brand + initials / "THIS NOTE IS NOT MONEY. THE NUMBER IS REAL."
import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { MEDIA, clamp, useAbs, TIMELINE, fr } from "../lib";
import CFG from "../config.json";
const _w = (id: string) => { const it = TIMELINE.find((x) => x.id === id)!; return [fr(it.start), fr(it.end) - 1]; };


const INK = "rgb(34,56,44)";
const RED = "rgb(168,46,54)";
const NUM = "Bodoni 72, Didot, 'Bodoni 72 Oldstyle', serif";
const SERIF = "Baskerville, 'Big Caslon', 'Bodoni 72', Georgia, serif";
const FULL = CFG.banknote_number + ".";
const RING = `${CFG.banknote_title} • ${CFG.brand} • ${CFG.first_name} ${CFG.last_name} • `.toUpperCase().repeat(3);
const OVAL = { cx: 540, cy: 742, rx: 408, ry: 548 };
const PORTRAIT = { w: 618, h: 898 };

// characters shown per local frame (ref: one char every ~1.5 frames at 30 fps, "." last with a punch)
const shown = (f: number) => Math.min(FULL.length, f < 2 ? 0 : Math.floor((f - 2) / 3) + 1);

const Banknote: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const n = shown(f);
  const txt = FULL.slice(0, n);
  // digits type in LEFT-anchored at their final place (ref): the not-yet-typed rest is laid out but invisible
  const rest = FULL.slice(n);
  const T = (<>{txt}<tspan fillOpacity={0} strokeOpacity={0}>{rest}</tspan></>);
  const land = interpolate(f, [0, 1, 2, 3], [1.035, 1.0135, 1.004, 1], clamp);
  const punch = interpolate(f, [11, 12, 13, 14, 15], [1, 1.024, 1.0135, 1.004, 1], clamp);
  const s = land * punch;
  const bold = f === 12 ? 1 : 0;
  const tcx = OVAL.cx, tcy = OVAL.cy, trx = 325, try_ = 465; // text band centre line
  const ringPath = `M ${tcx - trx} ${tcy} A ${trx} ${try_} 0 1 1 ${tcx + trx} ${tcy} A ${trx} ${try_} 0 1 1 ${tcx - trx} ${tcy}`;
  const [wa, wb] = _w("banknote");
  const portraitNo = String(Math.min(wb + 1, Math.max(wa + 1, abs + 1))).padStart(5, "0");
  return (
    <AbsoluteFill style={{ background: "rgb(243,237,223)", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${s})`, transformOrigin: "540px 960px" }}>
        <Img src={staticFile("banknote/base.png")} style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920 }} />
        <Img src={`${MEDIA}/banknote/${portraitNo}.png`} style={{ position: "absolute", left: OVAL.cx - PORTRAIT.w / 2, top: OVAL.cy - PORTRAIT.h / 2,
          width: PORTRAIT.w, height: PORTRAIT.h }} />
        <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{ position: "absolute", left: 0, top: 0 }}>
          <defs>
            <pattern id="bn-hh" patternUnits="userSpaceOnUse" width={12} height={5.4}>
              <rect x={0} y={0} width={12} height={3.1} fill={INK} />
            </pattern>
            <pattern id="bn-hf" patternUnits="userSpaceOnUse" width={12} height={3.2}>
              <rect x={0} y={0} width={12} height={2.1} fill={INK} />
            </pattern>
            <pattern id="bn-dg" patternUnits="userSpaceOnUse" width={4.6} height={4.6} patternTransform="rotate(-45)">
              <rect x={0} y={0} width={1.5} height={4.6} fill={INK} />
            </pattern>
            <pattern id="bn-hc" patternUnits="userSpaceOnUse" width={12} height={2.6}>
              <rect x={0} y={0} width={12} height={1.75} fill={INK} />
            </pattern>
            <path id="bn-ring" d={ringPath} />
          </defs>
          {/* serial */}
          <text x={540} y={104} textAnchor="middle" fontFamily={SERIF} fontWeight={700} fontSize={25} letterSpacing={1.8} fill={RED}>{`${CFG.brand.slice(0, 3)} 20202026 ${CFG.first_name[0] || ""}${CFG.last_name[0] || ""}`.toUpperCase()}</text>
          {/* corner numbers */}
          {[[206, 120], [874, 120], [206, 1831], [874, 1831]].map(([x, y], i) => (
            <g key={i} transform={`translate(${x} ${y}) scale(0.8 1)`}>
              <text x={0} y={0} textAnchor="middle" fontFamily={NUM} fontSize={84} fill="url(#bn-hc)" stroke={INK} strokeWidth={1.1}>{T}</text>
            </g>
          ))}
          {/* ring lettering */}
          <text fontFamily={SERIF} fontWeight={600} fontSize={21} letterSpacing={6.2} fill={INK} dominantBaseline="central">
            <textPath href="#bn-ring" startOffset="2%">{RING}</textPath>
          </text>
          {/* left rosette: name */}
          <text x={180} y={1135} textAnchor="middle" fontFamily={SERIF} fontStyle="italic" fontSize={23} fill={INK}>{CFG.first_name}</text>
          <text x={180} y={1157} textAnchor="middle" fontFamily={SERIF} fontStyle="italic" fontSize={23} fill={INK}>{CFG.last_name}</text>
          <text x={180} y={1174} textAnchor="middle" fontFamily={SERIF} fontWeight={700} fontSize={10.5} letterSpacing={1.4} fill={INK}>{CFG.role}</text>
          {/* big number: hatched shadow down-left, hatched fill, solid hairline outline */}
          <g transform="translate(540 1585) scale(0.74 1)">
            <text x={-13} y={10} textAnchor="middle" fontFamily={NUM} fontSize={430} fill="url(#bn-dg)">{T}</text>
            <text x={0} y={0} textAnchor="middle" fontFamily={NUM} fontSize={430} fill="url(#bn-hh)" stroke={INK} strokeWidth={2.2 + bold * 2.5}>{T}</text>
          </g>
          {/* title */}
          <g transform="translate(540 1676) scale(0.78 1)">
            <text x={0} y={0} textAnchor="middle" fontFamily={NUM} fontSize={74} letterSpacing={1} fill="url(#bn-hf)" stroke={INK} strokeWidth={0.9}>{CFG.banknote_title}</text>
          </g>
          {/* note box */}
          <text x={540} y={1798} textAnchor="middle" fontFamily={SERIF} fontWeight={700} fontSize={19} letterSpacing={1.1} fill={INK}>THIS NOTE IS NOT MONEY.</text>
          <text x={540} y={1829} textAnchor="middle" fontFamily={SERIF} fontWeight={700} fontSize={19} letterSpacing={1.1} fill={INK}>THE NUMBER IS REAL.</text>
        </svg>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
export default Banknote;
