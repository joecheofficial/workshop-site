// 02 Clone row: copies of Joe slide out from behind him on both sides, receding in depth (smaller, darker,
// softer, bodies fading out), 2 -> 4 -> 6 copies, then they tuck back behind him. Timing from ref/02-clone-row.
// Medium shot (23 Nov): measured on ref/02-clone-row 09: clones' eyes sit on the main eye line (rising a little with
// depth: -0.07 / -0.15 / -0.20 face widths), scales 0.47 / 0.27 / 0.185, centres 1.05 / 1.47 / 1.73 face widths out.
// Joe's face is ~1.6x the ref's and the panel starts at x 744, so the row keeps the ref sizes a touch smaller
// (0.40 / 0.23 / 0.16) and is pulled in (x0.72 left, x0.68 right) so the third copy on the right still clears the panel.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Backdrop, Joe, head, useAbs, clamp, easeOut, easeInOut } from "../lib";

type Copy = { side: -1 | 1; depth: 0 | 1 | 2 };
// per depth: scale, brightness, blur (output px), lag frames, entry frame
const D = [
  { k: 0.4, b: 0.86, blur: 0.6, lag: 2, in: 0.5, dx: 1.05, dy: -0.07 },
  { k: 0.23, b: 0.72, blur: 1.2, lag: 4, in: 4.5, dx: 1.47, dy: -0.15 },
  { k: 0.16, b: 0.6, blur: 1.8, lag: 6, in: 9.0, dx: 1.73, dy: -0.2 },
];
const SQUEEZE = { "-1": 0.72, "1": 0.68 } as Record<string, number>;

const CloneRow: React.FC<{ dur: number }> = ({ dur }) => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const h0 = head(abs - f); // fixed for the whole effect: Joe barely moves, the row must not jitter
  const EYE = { x: h0.cx, y: h0.top + 0.49 * (h0.chin - h0.top) };
  const fw = h0.w;
  const TARGET = (side: number, depth: number) => ({
    x: EYE.x + side * D[depth].dx * SQUEEZE[String(side)] * fw,
    y: EYE.y + D[depth].dy * fw,
  });
  // bodies fade out ~2.4 face widths under the chin (ref), in Joe's own frame before the copy is scaled
  const fadeA = h0.chin + 1.0 * fw, fadeB = h0.chin + 1.7 * fw, fadeC = h0.chin + 2.4 * fw;
  const MASK = `linear-gradient(to bottom, #000 0px, #000 ${fadeA}px, rgba(0,0,0,.55) ${fadeB}px, transparent ${fadeC}px)`;
  const copies: Copy[] = [];
  for (const depth of [2, 1, 0] as const) for (const side of [-1, 1] as const) copies.push({ side, depth });
  const out = interpolate(f, [dur - 3.5, dur - 1.5], [0, 1], { ...clamp, easing: easeInOut });

  return (
    <AbsoluteFill>
      <Backdrop />
      {copies.map(({ side, depth }) => {
        const d = D[depth];
        const t = interpolate(f, [d.in, d.in + 3.5], [0, 1], { ...clamp, easing: easeOut });
        if (t <= 0) return null;
        const tg = TARGET(side, depth);
        // slide out from behind the copy in front of it (or from behind Joe)
        const from = depth === 0 ? { x: EYE.x + side * 0.3 * fw, y: tg.y } : TARGET(side, depth - 1);
        const m = Math.min(t, 1 - out);
        const ex = from.x + (tg.x - from.x) * m;
        const ey = from.y + (tg.y - from.y) * m;
        const op = interpolate(t, [0, 0.5], [0, 1], clamp) * (1 - interpolate(out, [0.4, 1], [0, 1], clamp));
        const mblur = (1 - t) * 7 + out * 5;
        return (
          <AbsoluteFill key={`${side}${depth}`} style={{ opacity: op }}>
            <div style={{ position: "absolute", inset: 0, transformOrigin: `${EYE.x}px ${EYE.y}px`,
              transform: `translate(${ex - EYE.x}px, ${ey - EYE.y}px) scale(${d.k})`,
              WebkitMaskImage: MASK, maskImage: MASK }}>
              <Joe at={Math.max(0, abs - d.lag)} filter={`brightness(${d.b}) saturate(0.92) blur(${(d.blur + mblur) / d.k}px)`} />
            </div>
          </AbsoluteFill>
        );
      })}
      <Joe />
    </AbsoluteFill>
  );
};
export default CloneRow;
