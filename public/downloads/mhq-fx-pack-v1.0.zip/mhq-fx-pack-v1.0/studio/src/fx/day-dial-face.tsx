// Shared drawing for 03 Day dial (also used by predict-keys.tsx for the dial's reverse-wipe exit, which in the
// reference spills ~0.2 s into the next effect's window).
// Model (from ref/03-day-dial + ref/04-predict-keys 01-02): a cream clock face is revealed by a clockwise wipe
// from 12 o'clock with a soft glowing leading edge; the 11-12 sector is a black flap printed "dial" that folds
// into the 12 o'clock line to show the cream side ("dial" in green); a thin gold hand stands at 12; then the
// flap unfolds and the wipe runs back counter-clockwise. The dial sits behind Joe (soft drop shadow on cream).
import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { Backdrop, Front, Joe, F, clamp } from "../lib";

// ref: dial centred on the face (a touch above its centre), outer ring ~1.9 face widths. Joe medium shot:
// face centre ~ (440, 763), face ~246 px -> ro ~466.
export const DIAL = { cx: 440, cy: 755, ro: 466 };
const INK = "#1e3a2a";
const CREAM = "#efebdf";
const HANDC = "#b6ab6f";

// T = day-dial local frame (25 fps); predict-keys passes 24 + its own frame.
export const dialState = (T: number) => {
  const theta = interpolate(T, [0, 2.5, 5, 7.5, 10, 12.5, 15, 22.5, 24, 26.5, 29], [0, 80, 150, 210, 300, 335, 360, 360, 300, 150, 0], clamp);
  const flap = interpolate(T, [0.6, 1.6, 11, 15.5, 20.5, 22.5, 23.6, 24], [0, 30, 30, 0, 0, 15, 4, 0], clamp);
  const hand = (T < 2 ? 1 : 0) + interpolate(T, [15, 16, 22, 23], [0, 1, 1, 0], clamp);
  return { theta, flap, hand: Math.min(1, hand) };
};

const P = (r: number, a: number) => {
  const rad = (a * Math.PI) / 180;
  return { x: DIAL.cx + r * Math.sin(rad), y: DIAL.cy - r * Math.cos(rad) };
};
const sector = (a0: number, a1: number, r = 2600) => {
  const p0 = P(r, a0), p1 = P(r, a1);
  const large = a1 - a0 > 180 ? 1 : 0;
  return `M${DIAL.cx} ${DIAL.cy} L${p0.x} ${p0.y} A${r} ${r} 0 ${large} 1 ${p1.x} ${p1.y} Z`;
};

const Face: React.FC = () => {
  const { cx, cy, ro } = DIAL;
  const els: React.ReactNode[] = [];
  for (let i = 0; i < 60; i++) {
    const a = i * 6, hour = i % 5 === 0;
    const p0 = P(hour ? ro * 0.93 : ro * 0.985, a), p1 = P(hour ? ro * 1.03 : ro * 1.035, a);
    els.push(<line key={`t${i}`} x1={p0.x} y1={p0.y} x2={p1.x} y2={p1.y} stroke={INK} strokeWidth={hour ? 3.4 : 2.1} strokeLinecap="butt" />);
  }
  for (let h = 1; h <= 12; h++) {
    const a = h * 30;
    const pn = P(ro * 0.884, a);
    els.push(<text key={`n${h}`} x={pn.x} y={pn.y} textAnchor="middle" dominantBaseline="central" fontFamily={F.serif} fontSize={68}
      fill={INK}>{h}</text>);
    const d0 = P(ro * 0.34, a), d1 = P(ro * 0.81, a);
    els.push(<line key={`d${h}`} x1={d0.x} y1={d0.y} x2={d1.x} y2={d1.y} stroke={INK} strokeOpacity={0.72} strokeWidth={1.7} />);
    const aw = a + 15;
    const pw = P(ro * 0.735, aw);
    const word = aw === 345 ? "dial" : "day";
    els.push(<text key={`w${h}`} x={pw.x} y={pw.y} transform={`rotate(${aw} ${pw.x} ${pw.y})`} textAnchor="middle" dominantBaseline="central"
      fontFamily={F.serif} fontStyle="italic" fontSize={50} fill={INK}>{word}</text>);
  }
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
      <circle cx={cx} cy={cy} r={ro} fill="none" stroke={INK} strokeWidth={3.3} />
      <circle cx={cx} cy={cy} r={ro * 0.81} fill="none" stroke={INK} strokeWidth={2.6} />
      {els}
    </svg>
  );
};

const mask = (theta: number) => {
  if (theta >= 359.5) return undefined;
  const g = `conic-gradient(from 0deg at ${DIAL.cx}px ${DIAL.cy}px, #000 0deg, #000 ${Math.max(0, theta - 0.9)}deg, transparent ${theta + 0.9}deg)`;
  return { WebkitMaskImage: g, maskImage: g } as React.CSSProperties;
};

export const DayDialScene: React.FC<{ T: number }> = ({ T }) => {
  const { theta, flap, hand } = dialState(T);
  const { cx, cy, ro } = DIAL;
  const m = mask(theta);
  const glowOn = theta > 0.5 && theta < 359.5;
  // flap text squashes and mirrors as the flap folds onto the 12 o'clock line
  const s = (flap / 30) * 1.4 - 0.4;
  const fa = 360 - Math.max(flap, 0.001) / 2;
  const pt = P(ro * 0.985, fa);
  // trailing light streak behind the leading edge (ref 06, 10)
  const streakA = T < 16 ? theta - 32 : 285;
  const streakO = T < 16 ? interpolate(T, [8, 10, 13.5, 15.5], [0, 0.55, 0.45, 0], clamp) : interpolate(T, [21.5, 22.5, 24, 25], [0, 0.5, 0.4, 0], clamp);
  return (
    <AbsoluteFill>
      <Backdrop />
      {glowOn && (
        <AbsoluteFill style={{ background: `conic-gradient(from 0deg at ${cx}px ${cy}px, transparent ${theta}deg, rgba(246,242,231,0.82) ${theta}deg, rgba(246,242,231,0.32) ${theta + 9}deg, rgba(246,242,231,0) ${theta + 24}deg)` }} />
      )}
      {theta > 0.5 && (
        <AbsoluteFill style={{ ...m }}>
          <AbsoluteFill style={{ background: CREAM }} />
          <AbsoluteFill style={{ background: "radial-gradient(ellipse at 45% 45%, rgba(255,255,255,.18) 0%, rgba(0,0,0,0) 55%, rgba(60,50,30,.16) 100%)" }} />
          <Face />
          {/* Joe's soft shadow falls on the cream only */}
          <Joe style={{ transform: "translate(18px, 16px)", opacity: 0.42 }} filter="brightness(0) blur(16px)" />
        </AbsoluteFill>
      )}
      {streakO > 0 && (
        <div style={{ position: "absolute", left: cx, top: cy - 5, width: 1500, height: 10, transformOrigin: "0 50%",
          transform: `rotate(${streakA - 90}deg)`, opacity: streakO, filter: "blur(4px)",
          background: "linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(235,232,224,.9) 20%, rgba(235,232,224,.6) 60%, rgba(255,255,255,0) 100%)" }} />
      )}
      {flap > 0.3 && (
        <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
          <defs><filter id="ddblur" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation={16} /></filter></defs>
          {flap < 29 && <path d={sector(360 - flap - 14, 360 - flap * 0.5)} fill="#000" opacity={0.55 * (1 - flap / 30) + 0.15} filter="url(#ddblur)" />}
          <path d={sector(360 - flap, 360)} fill="#050605" />
          <g transform={`translate(${pt.x} ${pt.y}) rotate(${fa - 90}) scale(1 ${Math.abs(s) < 0.04 ? 0.04 : s})`}>
            <text x={0} y={0} textAnchor="middle" dominantBaseline="central" fontFamily={F.serif} fontStyle="italic" fontSize={84}
              fill="#f1ecdf" opacity={flap / 30 > 0.12 ? 1 : flap / 3.6}>dial</text>
          </g>
        </svg>
      )}
      {hand > 0 && <div style={{ position: "absolute", left: cx - 1.8, top: 0, width: 3.6, height: cy, background: HANDC, opacity: hand }} />}
      <Front />
      <Joe />
    </AbsoluteFill>
  );
};
