// Blow away: Joe turns to fine coloured dust that streams off with swirl and leaves the empty room, copied from
// ref/21-blow-away. Frames are precomputed by tools/blow-away-particles.py (lossless RGBA in output space:
// remaining Joe + dust) into media/blow-away/; here they sit on the clean plate. The panel stays on (chrome show).
import React from "react";
import { AbsoluteFill, Img } from "remotion";
import { Backdrop, MEDIA, useAbs, TIMELINE, fr } from "../lib";

const _bw = TIMELINE.find((x) => x.id === "blow-away")!;
const FIRST = fr(_bw.start), LAST = fr(_bw.end) - 1;

const BlowAway: React.FC<{ dur: number }> = () => {
  const abs = useAbs();
  const n = Math.max(FIRST, Math.min(LAST, abs));
  return (
    <AbsoluteFill>
      <Backdrop />
      <Img src={`${MEDIA}/blow-away/${String(n).padStart(5, "0")}.png`} style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920 }} />
    </AbsoluteFill>
  );
};
export default BlowAway;
