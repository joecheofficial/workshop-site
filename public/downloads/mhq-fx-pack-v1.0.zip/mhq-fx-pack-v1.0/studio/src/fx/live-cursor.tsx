// 01 Live cursor: a "Claude" multiplayer cursor flies in, clicks above-left of Joe's head and drags a gold
// selection box over his head and chest. 8 handles + a live "w × h" readout, cream outline on Joe, a red snap
// guide flashes once, then the box keeps tracking him while the cursor leaves. Timing from ref/01-live-cursor.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Joe, head, useAbs, F, clamp, easeOut, easeInOut } from "../lib";

const GOLD = "#c9b56c";
const TAG_BG = "#1c3626";
const TAG_LINE = "#e9e4d4";

/** Tracking selection rect (output px) at absolute frame a. */
const track = (a: number) => {
  const h = head(Math.round(a));
  // ref proportions (face ~170 px wide): box 287 x 451 = 1.69 x 2.65 face widths, centred on the face,
  // top edge just above the hair. Medium shot: Joe's face ~246 px -> ~415 x 650, right handles clear the panel.
  const w = 1.69 * h.w;
  const hh = 2.65 * h.w + Math.sin(a * 0.9) * 3;
  let x0 = h.cx - w / 2;
  x0 = Math.min(x0, 730 - w);
  const y0 = h.top - 14;
  return { x0, y0, w, h: hh };
};

const Cursor: React.FC<{ x: number; y: number; o: number }> = ({ x, y, o }) => (
  <svg width={70} height={100} viewBox="-2 -2 21 31" style={{ position: "absolute", left: x - 6.6, top: y - 6.6, opacity: o, overflow: "visible",
    filter: "drop-shadow(0 3px 5px rgba(0,0,0,.45))" }}>
    <path d="M0 0 L0 23.2 L5.6 17.8 L9.4 26.6 L13.1 25 L9.4 16.4 L16.6 16.4 Z" fill="#ffffff" stroke="#151515" strokeWidth={1.25} strokeLinejoin="round" />
  </svg>
);

const Ring: React.FC<{ x: number; y: number; t: number }> = ({ x, y, t }) => {
  if (t < 0 || t > 1) return null;
  const r = 26 + 16 * easeOut(t);
  return (
    <div style={{ position: "absolute", left: x - r, top: y - r, width: r * 2, height: r * 2, borderRadius: "50%",
      border: "2.5px solid rgba(236,232,220,0.85)", opacity: interpolate(t, [0, 0.35, 1], [0.95, 0.8, 0]) }} />
  );
};

const LiveCursor: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const tr = track(abs);

  // --- drag: click at 3.5, box grows to full by 8 ---
  const CLICK = 3.5, DRAG_END = 8;
  const p = interpolate(f, [CLICK, DRAG_END], [0, 1], { ...clamp, easing: easeOut });
  const dragging = f >= CLICK;
  const bw = tr.w * p, bh = tr.h * p;
  const br = { x: tr.x0 + bw, y: tr.y0 + bh };

  // --- cursor path ---
  const P0 = { x: 52, y: 1000 };
  const startTL = track(abs - f + CLICK);
  const toTL = interpolate(f, [0.4, CLICK], [0, 1], { ...clamp, easing: easeInOut });
  let cx: number, cy: number;
  if (!dragging) {
    cx = P0.x + (startTL.x0 + 8 - P0.x) * toTL;
    cy = P0.y + (startTL.y0 + 2 - P0.y) * toTL;
  } else {
    const settle = interpolate(f, [DRAG_END - 1, DRAG_END + 3], [0, 1], clamp);
    cx = br.x - 16 * settle;
    cy = br.y - 30 * settle;
  }
  // exit: drift down-right and fade
  const ex = interpolate(f, [23.5, 27.5], [0, 1], { ...clamp, easing: easeInOut });
  cx += 70 * ex; cy += 90 * ex;
  const curO = interpolate(f, [25.5, 27.5], [1, 0], clamp);

  // tag follows with a small lag
  const lagF = Math.max(0, f - 0.6);
  const tagOff = { x: interpolate(f, [0, 2.5, 4.5, 8, 11], [4, 0, 58, 60, 50], clamp), y: interpolate(f, [0, 2.5, 4.5, 8, 11], [130, 126, 52, 54, 90], clamp) };
  let tx: number, ty: number;
  {
    // recompute cursor position at lagged frame (cheap re-run of the same formulas)
    const a2 = abs - (f - lagF);
    const tr2 = track(a2);
    const p2 = interpolate(lagF, [CLICK, DRAG_END], [0, 1], { ...clamp, easing: easeOut });
    if (lagF < CLICK) {
      const k = interpolate(lagF, [0.4, CLICK], [0, 1], { ...clamp, easing: easeInOut });
      tx = P0.x + (startTL.x0 + 8 - P0.x) * k; ty = P0.y + (startTL.y0 + 2 - P0.y) * k;
    } else {
      const s2 = interpolate(lagF, [DRAG_END - 1, DRAG_END + 3], [0, 1], clamp);
      tx = tr2.x0 + tr2.w * p2 - 16 * s2; ty = tr2.y0 + tr2.h * p2 - 30 * s2;
    }
    const ex2 = interpolate(lagF, [23.5, 27.5], [0, 1], { ...clamp, easing: easeInOut });
    tx += 70 * ex2 + tagOff.x; ty += 90 * ex2 + tagOff.y;
  }

  // --- outline on Joe: inside the box while dragging, then whole body ---
  const fullOutline = f >= 6.5 && f < 26.5;
  const clipOutline = f >= 4.5 && f < 6.5;
  const outO = interpolate(f, [24.5, 26.5], [1, 0], clamp);

  // --- handles + label ---
  const hs = interpolate(f, [6.5, 7.5, 10], [0, 12, 23], { ...clamp, easing: easeOut });
  const labO = interpolate(f, [8.5, 10], [0, 1], clamp);
  const labS = interpolate(f, [8.5, 10.5], [0.86, 1], { ...clamp, easing: easeOut });
  const label = `${Math.round(tr.w)} × ${Math.round(tr.h)}`;

  // --- snap guide (red, once) ---
  const gO = interpolate(f, [16.5, 17.5, 19.5, 21.5], [0, 0.95, 0.55, 0], clamp);
  const gx = head(abs).cx - 8;

  const handles = dragging && hs > 0.5 ? [
    [tr.x0, tr.y0], [tr.x0 + bw / 2, tr.y0], [br.x, tr.y0],
    [tr.x0, tr.y0 + bh / 2], [br.x, tr.y0 + bh / 2],
    [tr.x0, br.y], [tr.x0 + bw / 2, br.y], [br.x, br.y],
  ] : [];

  return (
    <AbsoluteFill>
      {clipOutline && (
        <AbsoluteFill style={{ clipPath: `inset(${tr.y0}px ${1080 - br.x}px ${1920 - br.y}px ${tr.x0}px)` }}>
          <Joe outline />
        </AbsoluteFill>
      )}
      {fullOutline && <Joe outline style={{ opacity: outO }} />}

      {gO > 0 && <div style={{ position: "absolute", left: gx - 1, top: 0, width: 2.2, height: 1920, background: "#e2687f", opacity: gO,
        boxShadow: "0 0 4px rgba(226,104,127,.6)" }} />}

      {dragging && p > 0.02 && (
        <div style={{ position: "absolute", left: tr.x0, top: tr.y0, width: bw, height: bh,
          border: `${f < DRAG_END ? 2.6 : 3.2}px solid ${GOLD}`, boxSizing: "border-box",
          boxShadow: "0 0 0 0.5px rgba(0,0,0,.25)" }} />
      )}
      {handles.map(([x, y], i) => (
        <div key={i} style={{ position: "absolute", left: x - hs / 2, top: y - hs / 2, width: hs, height: hs, boxSizing: "border-box",
          background: "#fdfbf4", border: `${hs > 16 ? 2.6 : 1.8}px solid ${GOLD}`, boxShadow: "0 1px 3px rgba(0,0,0,.35)" }} />
      ))}
      {labO > 0 && (
        <div style={{ position: "absolute", left: tr.x0 + tr.w / 2, top: tr.y0 - 22, transform: `translate(-50%,-100%) scale(${labS})`,
          transformOrigin: "50% 100%", opacity: labO, background: GOLD, borderRadius: 5, padding: "4px 30px 5px",
          fontFamily: F.mono, fontSize: 31, fontWeight: 500, letterSpacing: 0.5, color: "#231d10", whiteSpace: "nowrap",
          boxShadow: "0 2px 8px rgba(0,0,0,.3)" }}>{label}</div>
      )}

      <Ring x={startTL.x0} y={startTL.y0} t={(f - CLICK) / 6} />
      <Ring x={br.x - 16} y={br.y - 30} t={(f - 12.5) / 6} />

      {curO > 0 && (
        <>
          <Cursor x={cx} y={cy} o={curO} />
          <div style={{ position: "absolute", left: tx, top: ty, opacity: curO, background: TAG_BG, border: `2px solid ${TAG_LINE}`,
            borderRadius: 12, padding: "5px 18px 7px", fontFamily: F.ui, fontWeight: 600, fontSize: 34, letterSpacing: -0.3,
            color: "#f4f1e8", whiteSpace: "nowrap", boxShadow: "0 3px 10px rgba(0,0,0,.35)" }}>Claude</div>
        </>
      )}
    </AbsoluteFill>
  );
};
export default LiveCursor;
