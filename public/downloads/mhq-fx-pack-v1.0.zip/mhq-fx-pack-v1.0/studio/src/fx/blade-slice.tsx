// Blade slice, measured from ref/12-blade-slice at 30 fps (block matching on the lamp above the cut and the clock below it):
// 0.00-0.48 s  nothing
// 0.49 s       the WHOLE picture is cut along a straight line through his mouth (line at -13 deg, rising to the right).
//              The top piece jumps up-right, the bottom piece down-left, both along a -20 deg vector (so the pieces also
//              separate a little: a crisp black gap opens). Ref offset per piece: 40 px, drifting linearly to 59 px by 0.82 s.
// 0.85 s       snaps back (one in-between frame at ~40 %), then the whole frame punches in 5 % and settles by 0.99 s.
// Medium shot (23 Nov): sizes scaled 1.45x (Joe's face ~246 px vs the ref's ~170), the cut line goes through his
// mouth from the head track (chin - 0.3 face widths).
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { Backdrop, Joe, W, H, useAbs, head } from "../lib";

const K = 1.45; // ref -> our head scale
// cut line through his mouth (output px): y = Y0 + SLOPE * x
const SLOPE = -Math.tan((13 * Math.PI) / 180);
// motion direction of the top piece (up-right), from the measured shift (38,-14)
const ANG = (19 * Math.PI) / 180; // measured 20.2; 19 keeps the gap a touch finer at our scale
const DIR = { x: Math.cos(ANG), y: -Math.sin(ANG) };

/** The normal frame (room + Joe), clipped to the frame: a shifted piece shows black where it has slid away from
 *  the edge, exactly like the reference (its top piece leaves a black strip on the left). */
const Frame: React.FC<{ abs: number }> = ({ abs }) => (
  <AbsoluteFill style={{ overflow: "hidden" }}>
    <Backdrop />
    <Joe at={abs} />
  </AbsoluteFill>
);

const BladeSlice: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const hm = head(abs - f + 12); // where his mouth is when the blade hits (fixed for the cut)
  const MOUTH = { x: hm.cx, y: hm.chin - 0.3 * hm.w };
  const lineY = (x: number) => MOUTH.y + SLOPE * (x - MOUTH.x);
  // per-piece offset in ref px
  let d = 0;
  if (f >= 12 && f <= 20) d = 38 + ((f - 12) / 8) * 16 + 1.5; // 39.5 -> 55.5 (measured 38..55 over 0.49..0.82 s)
  else if (f === 21) d = 22; // one in-between frame on the way back
  const zoom = f === 22 ? 1.05 : f === 23 ? 1.03 : f === 24 ? 1.01 : 1;
  if (d === 0 && zoom === 1) return null; // plain Scene underneath
  if (d === 0) {
    return (
      <AbsoluteFill style={{ background: "#000", transform: `scale(${zoom})`, transformOrigin: "50% 50%" }}>
        <Frame abs={abs} />
      </AbsoluteFill>
    );
  }
  const off = d * K;
  const X0 = -400, X1 = W + 400;
  const top = `polygon(${X0}px ${-400}px, ${X1}px ${-400}px, ${X1}px ${lineY(X1)}px, ${X0}px ${lineY(X0)}px)`;
  const bot = `polygon(${X0}px ${lineY(X0)}px, ${X1}px ${lineY(X1)}px, ${X1}px ${H + 400}px, ${X0}px ${H + 400}px)`;
  const piece = (clip: string, sx: number) => (
    <AbsoluteFill style={{ transform: `translate(${sx * DIR.x * off}px, ${sx * DIR.y * off}px)` }}>
      <AbsoluteFill style={{ clipPath: clip, overflow: "visible" }}>
        <Frame abs={abs} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
  return (
    <AbsoluteFill style={{ background: "#050505", overflow: "hidden" }}>
      {piece(bot, -1)}
      {piece(top, 1)}
    </AbsoluteFill>
  );
};
export default BladeSlice;
