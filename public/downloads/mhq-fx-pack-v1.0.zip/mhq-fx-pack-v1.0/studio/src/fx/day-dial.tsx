// 03 Day dial: see day-dial-face.tsx for the model. The reverse-wipe exit finishes inside predict-keys.tsx.
import React from "react";
import { useCurrentFrame } from "remotion";
import { DayDialScene } from "./day-dial-face";

const DayDial: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  return <DayDialScene T={f} />;
};
export default DayDial;
