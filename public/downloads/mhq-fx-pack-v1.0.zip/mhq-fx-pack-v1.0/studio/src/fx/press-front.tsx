// Press front: full-screen newspaper front page (chrome hidden), copied from ref/19-press-front.
// Entry (ref frames 1-2): the page is already up on frame 0, a touch big (~1.05) with the italic deck heavier,
// and settles to 1.0 in ~3 frames; then holds while the halftone photo stays live. Hard cut out (next: paper tear).
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { useAbs, clamp, easeOut } from "../lib";
import { PressPage, Grain } from "./press-front-page";

const PressFront: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  const abs = useAbs();
  const s = interpolate(f, [0, 3], [1.05, 1], { ...clamp, easing: easeOut });
  const y = interpolate(f, [0, 3], [14, 0], { ...clamp, easing: easeOut });
  const bold = interpolate(f, [0, 1.5], [1, 0], clamp);
  return (
    <AbsoluteFill style={{ background: "#e9e1cd" }}>
      <AbsoluteFill style={{ transform: `translateY(${y}px) scale(${s})`, transformOrigin: "50% 30%" }}>
        <PressPage at={abs} boldDeck={bold} />
        <Grain />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
export default PressFront;
