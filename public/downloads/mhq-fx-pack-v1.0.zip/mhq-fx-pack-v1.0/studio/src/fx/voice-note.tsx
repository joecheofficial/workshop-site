// Voice note, measured from ref/16-voice-note + the 30 fps video (ref px; same frame width as ours, so UI sizes are 1:1,
// moved down by Y0 so it sits in the room above Joe's head like the ref sits above his).
// 0.00 s  nothing
// 0.04 s  cream voice bubble + round avatar pop out of the avatar corner (scale about (731,181): .67 -> .91 -> 1.015 -> 1)
//         dark play button, 23 waveform bars (6 px, 11.8 px pitch), the played part dark green, a dark-gold playhead
//         that runs left to right (28 % -> 100 % by 0.46 s), "0:00", gold send circle with an up arrow.
// 0.08 s  "Voice note" pill grows out from its left edge under the bubble (text clipped while it grows), full by 0.2 s.
// 0.36 s  send button pressed: light ring around it, button dips (to 0.53 s).
// 0.60 s  bubble + avatar fly off up-right (ease in), "Delivered ✓" pill pops in above "Voice note" where the bubble was.
// 0.72 s  both pills fade out in two frames. Joe keeps talking underneath the whole time.
import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame, Easing } from "remotion";
import { F, clamp } from "../lib";

const Y0 = 312; // our y offset vs the ref layout (medium shot: label ends ~0.3 face widths above his hair, like the ref)
const GREEN = "rgb(20,49,35)";
const CREAM = "rgb(238,235,222)";
const GOLD = "rgb(196,165,88)";
const BARS = [68, 108, 102, 90, 97, 91, 65, 74, 83, 76, 33, 72, 106, 96, 76, 91, 58, 84, 104, 80, 59, 36, 30];
const ANCHOR = { x: 731, y: 181 + Y0 };

const VoiceNote: React.FC<{ dur: number }> = () => {
  const f = useCurrentFrame();
  const t = f / 25;
  if (f < 1) return null;

  // entry scale (measured samples at 30 fps, resampled)
  const s = interpolate(t, [0.0, 0.04, 0.08, 0.12, 0.16, 0.2], [0.0, 0.67, 0.91, 1.015, 1.008, 1], clamp);
  const progress = interpolate(t, [0.04, 0.46], [0.32, 1], clamp);
  const press = interpolate(t, [0.34, 0.38, 0.5, 0.55], [0, 1, 1, 0], clamp);
  // exit (bubble + avatar): up and to the right, accelerating, gone after 0.70 s
  const ex = interpolate(t, [0.56, 0.6, 0.64, 0.68, 0.72], [0, 0.05, 0.21, 0.55, 1], clamp);
  const exX = ex * 560, exY = -ex * 640;
  const bubbleOn = t < 0.71;

  // pills
  const pillW = interpolate(t, [0.07, 0.1, 0.135, 0.167, 0.2], [48, 126, 132, 182, 208], clamp);
  const pillsOpacity = interpolate(t, [0.7, 0.735, 0.765], [1, 0.5, 0], clamp);
  const delivered = interpolate(t, [0.58, 0.6, 0.64, 0.68], [0, 0.65, 1.04, 1], clamp);

  const wave0 = 161, pitch = 11.8, waveEnd = wave0 + (BARS.length - 1) * pitch + 6;
  const headX = wave0 + progress * (waveEnd - wave0);

  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {bubbleOn && (
        <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920,
          transform: `translate(${exX}px, ${exY}px) scale(${s})`, transformOrigin: `${ANCHOR.x}px ${ANCHOR.y}px` }}>
          {/* bubble */}
          <div style={{ position: "absolute", left: 35, top: 40 + Y0, width: 598, height: 140, borderRadius: 30, background: CREAM,
            boxShadow: "0 10px 28px rgba(0,0,0,.38), 0 1px 0 rgba(255,255,255,.6) inset", border: "1px solid rgba(255,255,255,.55)" }}>
            {/* play */}
            <div style={{ position: "absolute", left: 24, top: 30, width: 80, height: 80, borderRadius: 40, background: GREEN }}>
              <svg width={80} height={80} viewBox="0 0 80 80" style={{ position: "absolute", left: 0, top: 0 }}>
                <path d="M31 24 L58 40 L31 56 Z" fill={CREAM} stroke={CREAM} strokeWidth={3} strokeLinejoin="round" />
              </svg>
            </div>
            {/* waveform */}
            {BARS.map((h, i) => {
              const x = wave0 + i * pitch - 35;
              const played = wave0 + i * pitch + 3 <= headX;
              return <div key={i} style={{ position: "absolute", left: x, top: 70 - h / 2, width: 6, height: h, borderRadius: 3,
                background: played ? "rgb(25,52,35)" : "rgb(185,185,172)" }} />;
            })}
            {/* playhead */}
            <div style={{ position: "absolute", left: headX - 35 - 1.5, top: 10, width: 3.5, height: 120, borderRadius: 2, background: "rgb(160,138,52)" }} />
            {/* timer */}
            <div style={{ position: "absolute", left: 417, top: 46, fontFamily: F.ui, fontSize: 38, fontWeight: 500, letterSpacing: -0.4,
              color: "rgb(28,46,28)", lineHeight: "48px", fontVariantNumeric: "tabular-nums" }}>0:00</div>
            {/* send */}
            <div style={{ position: "absolute", left: 509 - 36 + 36, top: 34, width: 72, height: 72 }}>
              {press > 0 && <div style={{ position: "absolute", left: -9, top: -9, width: 90, height: 90, borderRadius: 45,
                border: `4px solid rgba(255,255,255,${0.55 * press})`, boxShadow: `0 0 0 3px rgba(120,120,110,${0.25 * press})`, boxSizing: "border-box" }} />}
              <div style={{ position: "absolute", left: 0, top: 0, width: 72, height: 72, borderRadius: 36, background: GOLD,
                transform: `scale(${1 - 0.08 * press})`, filter: `brightness(${1 - 0.12 * press})` }}>
                <svg width={72} height={72} viewBox="0 0 72 72">
                  <path d="M36 54 L36 20 M22 33 L36 19 L50 33" fill="none" stroke="rgb(20,47,31)" strokeWidth={5.5} strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
            </div>
          </div>
          {/* avatar */}
          <div style={{ position: "absolute", left: 687 - 40, top: 138 + Y0 - 40, width: 80, height: 80, borderRadius: 40, overflow: "hidden",
            boxShadow: "0 0 0 2.5px rgba(20,32,24,.85), 0 6px 14px rgba(0,0,0,.35)" }}>
            <Img src={staticFile("voice-note/avatar.png")} style={{ width: 80, height: 80 }} />
          </div>
        </div>
      )}
      {/* "Delivered ✓" pill (right-aligned with the Voice note pill, where the bubble's bottom was) */}
      {delivered > 0 && (
        <div style={{ position: "absolute", right: 1080 - 634, top: 139 + Y0, height: 40, opacity: pillsOpacity,
          transform: `scale(${delivered})`, transformOrigin: "100% 50%" }}>
          <div style={{ height: 40, padding: "0 15px", borderRadius: 20, background: CREAM, display: "flex", alignItems: "center", gap: 7,
            fontFamily: F.ui, fontSize: 24, fontWeight: 500, color: "rgb(33,49,32)", boxShadow: "0 4px 12px rgba(0,0,0,.3)", whiteSpace: "nowrap" }}>
            Delivered
            <svg width={20} height={20} viewBox="0 0 20 20"><path d="M3.5 10.5 L8 15 L16.5 5.5" fill="none" stroke="rgb(70,96,58)" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" /></svg>
          </div>
        </div>
      )}
      {/* "Voice note" pill */}
      {t >= 0.07 && (
        <div style={{ position: "absolute", left: 425, top: 193 + Y0, width: pillW, height: 48, borderRadius: 24, background: CREAM,
          overflow: "hidden", opacity: pillsOpacity, boxShadow: "0 4px 12px rgba(0,0,0,.3)" }}>
          <div style={{ position: "absolute", left: 23, top: 0, height: 48, lineHeight: "48px", fontFamily: F.ui, fontSize: 31, fontWeight: 600,
            letterSpacing: -0.4, color: "rgb(33,49,32)", whiteSpace: "nowrap" }}>Voice note</div>
        </div>
      )}
    </AbsoluteFill>
  );
};
export default VoiceNote;
