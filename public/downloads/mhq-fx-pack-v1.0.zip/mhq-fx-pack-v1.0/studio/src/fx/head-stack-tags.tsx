// Head stack tags (shared by head-stack.tsx and the first frame of rack-focus.tsx, where the last tags fly out on the left).
// Copied from ref/13-head-stack (10 fps frames + 30 fps video):
//  - small off-white mono name tags (ref 128x34 px, r 5, bold mono word + small mono word on one baseline, grey bottom edge)
//  - they DROP from above the frame, straight down, with a strong vertical motion blur (~1600 ref px/s), land on their slot,
//    over-rotate a little and settle. Five stack on his head (alternating left/right, tilted -3..-6 deg),
//    three stack beside him on the left, tilted ~-20 deg.
//  - exit (0.82 s on): every tag tilts further CCW and the whole pile is flung to the left with a smear along the tags,
//    the left pile drops down-left out of frame. At 1.12 s (next effect's first frame) the last smear leaves on the left edge.
import React from "react";
import { AbsoluteFill, interpolate, Easing } from "remotion";
import { F, head, clamp } from "../lib";

export const K = 1.45; // ref px -> our px (medium shot: Joe's face ~246 px vs the ref's ~170)

type TagDef = { big: string; small: string; land: number; dx: number; slot: number; rot: number; side: "head" | "left" };
// land = local frame (25 fps) it hits its slot; dx = ref px offset from the head centre; slot = 0 bottom
export const TAGS: TagDef[] = [
  { big: "Press", small: "front", land: 5, dx: -9, slot: 0, rot: -5, side: "head" },
  { big: "Blade", small: "slice", land: 7, dx: 17, slot: 1, rot: -5.5, side: "head" },
  { big: "Day", small: "dial", land: 9, dx: 0, slot: 0, rot: -20, side: "left" },
  { big: "Orbit", small: "ring", land: 9, dx: -16, slot: 2, rot: -4, side: "head" },
  { big: "Banknote", small: "", land: 12, dx: 12, slot: 3, rot: -6, side: "head" },
  { big: "Dolly", small: "zoom", land: 12, dx: -8, slot: 1, rot: -19, side: "left" },
  { big: "Live", small: "cursor", land: 14, dx: -13, slot: 4, rot: -7, side: "head" },
  { big: "Voice", small: "note", land: 16, dx: -4, slot: 2, rot: -21, side: "left" },
];

export const Tag: React.FC<{ big: string; small: string }> = ({ big, small }) => (
  <div style={{ display: "inline-flex", alignItems: "baseline", height: 34 * K, boxSizing: "border-box", padding: `0 ${10 * K}px`,
    paddingTop: 6.5 * K, borderRadius: 5.5 * K, whiteSpace: "nowrap",
    background: "linear-gradient(#f4f3ed, #e9e8e0)", border: `${0.7 * K}px solid rgba(40,40,30,.18)`,
    boxShadow: `0 ${1.2 * K}px 0 #aeada4, 0 ${2.6 * K}px ${5 * K}px rgba(0,0,0,.38)`,
    fontFamily: `ui-monospace, ${F.mono}`, color: "#222b25" }}>
    <span style={{ fontSize: 21 * K, fontWeight: 650, letterSpacing: -0.4 * K, lineHeight: 1 }}>{big}</span>
    {small && <span style={{ fontSize: 12 * K, fontWeight: 500, marginLeft: 4 * K, lineHeight: 1 }}>{small}</span>}
  </div>
);

/** SVG blur filters: x-blur at a few strengths (applied in a rotated frame to smear along any direction). */
const SIGMAS = [3, 6, 10, 16, 24, 34, 48];
export const BlurDefs: React.FC = () => (
  <svg width={0} height={0} style={{ position: "absolute" }}>
    <defs>
      {SIGMAS.map((s) => (
        <filter key={s} id={`hs-bx${s}`} x="-60%" y="-200%" width="220%" height="500%" colorInterpolationFilters="sRGB">
          <feGaussianBlur stdDeviation={`${s} 0.01`} />
        </filter>
      ))}
    </defs>
  </svg>
);
const pickSigma = (s: number) => (s < 1.5 ? 0 : SIGMAS.reduce((a, b) => (Math.abs(b - s) < Math.abs(a - s) ? b : a)));

/** A tag at (x,y) with rotation rot, smeared by `blur` px along direction `dir` (deg, screen space). */
const Placed: React.FC<{ x: number; y: number; rot: number; blur: number; dir: number; children: React.ReactNode }> = ({ x, y, rot, blur, dir, children }) => {
  const s = pickSigma(blur);
  return (
    <div style={{ position: "absolute", left: x, top: y, width: 0, height: 0 }}>
      <div style={{ position: "absolute", left: 0, top: 0, transform: `rotate(${dir}deg)`, filter: s ? `url(#hs-bx${s})` : undefined }}>
        <div style={{ position: "absolute", left: 0, top: 0, transform: `rotate(${rot - dir}deg) translate(-50%, -50%)`, transformOrigin: "0 0" }}>
          {children}
        </div>
      </div>
    </div>
  );
};

const SPACING = 33.5; // ref px between tag centres in a pile (tags touch)
const FALL_V = 66 * K; // px per frame (ref ~1650 px/s)

/** All tags at local frame f of the head-stack window (f may run past the window for the rack-focus hand-off). */
export const HeadStackTags: React.FC<{ f: number; abs: number }> = ({ f, abs }) => {
  const hb = head(Math.min(abs, 430));
  const hx = hb.cx + 2, htop = hb.top - 3; // hair top
  // head pile: bottom tag centre sits 21 ref px above the head top
  const headBase = { x: hx, y: htop - 15 * K };
  // left pile: beside his face on the left, like the ref (medium shot: there is room again)
  const leftBase = { x: hb.cx - 0.95 * hb.w, y: hb.top + 0.95 * (hb.chin - hb.top) };
  // exit (whole piles): keyframes in local frames
  const ex = (kf: number[], vals: number[]) => interpolate(f, kf, vals, { ...clamp, easing: Easing.in(Easing.quad) });
  const hOffX = interpolate(f, [20.5, 22.5, 25, 28, 30], [0, -100, -300, -560, -780], clamp); // frame-relative: ref pile lands 43% into the room left of him
  const hOffY = interpolate(f, [20.5, 22.5, 25, 28, 30], [0, -12, 220, 250, 262], clamp);
  const hRot = interpolate(f, [20.5, 22.5, 25, 28, 30], [0, -12, -32, -44, -50], clamp);
  const hBlur = interpolate(f, [20.5, 22.5, 25, 28, 30], [0, 7, 22, 30, 30].map((v) => v * K), clamp);
  const lOffX = ex([20.5, 22.5, 25], [0, -14, -260].map((v) => v * K));
  const lOffY = ex([20.5, 22.5, 25], [0, 16, 330].map((v) => v * K));
  const lBlur = interpolate(f, [20.5, 22.5, 25], [0, 6, 26].map((v) => v * K), clamp);
  const lRot = interpolate(f, [20.5, 22.5, 25], [0, -4, -18], clamp);

  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <BlurDefs />
      {TAGS.map((t, i) => {
        const left = t.side === "left";
        const base = left ? leftBase : headBase;
        // pile direction ("up" of a pile tilted by the pile angle)
        const pileAng = left ? -20 : 0;
        const ux = Math.sin((pileAng * Math.PI) / 180), uy = -Math.cos((pileAng * Math.PI) / 180);
        const sx = base.x + t.dx * K + ux * t.slot * SPACING * K;
        const sy = base.y + uy * t.slot * SPACING * K;
        let x = sx, y = sy, rot = t.rot, blur = 0, dir = 90;
        if (f < t.land) {
          // falling: straight down from above the frame (the left pile has far further to fall, so it falls faster)
          const k = t.land - f;
          const v = left ? 175 : FALL_V;
          y = sy - v * k;
          if (y < -60 * K) return null;
          x = sx - (left ? 65 * k : 0); // left pile slides in along its own -20 deg tilt, clear of his face
          rot = left ? t.rot * 0.75 : 0;
          blur = (left ? 13 : 11) * K; dir = left ? 70 : 90;
        } else {
          // landed: small drop-in overshoot then settle
          const g = f - t.land;
          const settle = Math.exp(-g / 1.6) * Math.cos(g * 1.4);
          y = sy + 3 * K * settle;
          rot = t.rot + (t.rot * 0.9) * settle;
          blur = g < 1 ? 4 * K : 0;
          dir = 90;
        }
        // exit
        if (f > 20.5) {
          if (left) { x += lOffX; y += lOffY; rot += lRot; blur = lBlur; dir = rot + 8; }
          else {
            // pile rotates about its centre while flying left
            const cx = headBase.x, cy = headBase.y - 2 * SPACING * K;
            const a = (hRot * Math.PI) / 180;
            const rx = x - cx, ry = y - cy;
            x = cx + rx * Math.cos(a) - ry * Math.sin(a) + hOffX;
            y = cy + rx * Math.sin(a) + ry * Math.cos(a) + hOffY;
            rot += hRot * 0.85; blur = hBlur; dir = rot + 4;
          }
        }
        if (x < -400 || y > 2300) return null;
        return (
          <Placed key={i} x={x} y={y} rot={rot} blur={blur} dir={dir}>
            <Tag big={t.big} small={t.small} />
          </Placed>
        );
      })}
    </AbsoluteFill>
  );
};
