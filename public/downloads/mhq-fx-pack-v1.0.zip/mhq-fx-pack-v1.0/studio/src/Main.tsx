import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame } from "remotion";
import { Scene, TIMELINE, fr, AbsFrame } from "./lib";
import { Panel, Title } from "./chrome";
import { FX } from "./fx/registry";

// Each effect renders INSIDE its own Sequence (local frame 0 = its start) on top of the normal Scene.
// An effect that changes Joe or the room draws its own full picture (it can use <Scene/>, <Backdrop/>, <Joe/>).
// chrome "hide" = the panel and title are not drawn during that effect (full-screen moments).
export const Main: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / 25;
  const cur = TIMELINE.find((it) => t >= it.start && t < it.end);
  const cta = TIMELINE.find((it) => it.id === "comment-drop")!;
  return (
    <AbsFrame.Provider value={f}>
    <AbsoluteFill style={{ background: "#000" }}>
      <Scene />
      {TIMELINE.map((it) => {
        const Comp = FX[it.id];
        if (!Comp) return null;
        const from = fr(it.start), dur = Math.max(1, fr(it.end) - from);
        return (
          <Sequence key={it.id} from={from} durationInFrames={dur} layout="none">
            <AbsoluteFill><Comp dur={dur} /></AbsoluteFill>
          </Sequence>
        );
      })}
      {cur?.chrome !== "hide" && (
        <>
          <Panel goldFrom={fr(cta.start + 2.6)} />
          <Title until={fr(2.4)} />
        </>
      )}
    </AbsoluteFill>
    </AbsFrame.Provider>
  );
};
