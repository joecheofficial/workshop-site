---
name: mhq-fx-pack
description: Put the 20 MHQ video effects (live cursor, clone row, day dial, predict keys, orbit ring, code body, post wall, letter dive, comment drop, layer explode, sketch words, blade slice, head stack, rack focus, banknote, voice note, impact frame, dolly zoom, press front, paper tear, blow away) on the user's own talking-head video. Use for "add the effects to my video", "fx pack", "retime the effects", "only use some effects".
---

# MHQ FX Pack

Folder layout: `make.sh` (whole run), `config.json` (the user's words and numbers), `tools/` (Python + Swift
helpers), `studio/` (Remotion project: `src/Main.tsx`, `src/lib.tsx`, `src/chrome.tsx`, one `src/fx/<id>.tsx` per effect,
`src/timeline.json`).

## Run it
1. Check: macOS, `ffmpeg`, `node` 18+, `swiftc` (Xcode command line tools), Python 3 with numpy, pillow, scipy,
   fonttools. If the default python3 lacks them, use `PY=/path/to/python3 ./make.sh`. Ask before installing anything.
2. Fill `config.json` with the user: first/last name, role, brand, Instagram handle (no @), comment keyword,
   headline, dateline, banknote number + title, posts_total (their real post count; never invent numbers).
3. `./make.sh <video>` -> `out/fx-video.mp4`. Steps: normalise to 1080x1920 25 fps -> Apple Vision person matte
   (`tools/seg.swift`) -> cut-out PNGs in `media/cut` -> head track (`tools/track.py` -> `studio/src/track.json`) ->
   empty background plate (`tools/studio-plate.py`) -> timeline (`tools/timeline.py`) -> per-frame media
   (`tools/rebuild-media.sh`) -> Remotion render with `media/` served on 127.0.0.1:8790 -> original audio muxed back.
4. Look at the result before saying it is done: `cd studio && node stills.mjs ../out/check <frame> <frame>...`
   (the media server must be running: `cd media && python3 -m http.server 8790 --bind 127.0.0.1`).

## Retime to the words
Get word times (e.g. `whisper` with word timestamps, or any transcript with timings). Each item in
`studio/src/timeline.json` has `start`/`end` in seconds; set each effect's start on the word that names it,
end = next start. Keep `comment-drop` (the keyword call to action) where the user says the keyword.
Then re-run only the last steps: `bash tools/rebuild-media.sh`, then the render + mux lines at the end of make.sh.

## Keep only some effects
Delete items from `studio/src/timeline.json` and stretch the others to fill the gaps. The effects with media
(code-body, impact-frame, banknote, press-front, paper-tear, blow-away) are read by `tools/rebuild-media.sh`:
if you remove one, remove its line there too. `chrome: "hide"` = full-screen moment, the list panel is hidden.

## Limits
- Mac only (Apple Vision). A still camera and a plain background give the cleanest cut-out.
- The look (green list panel, title boxes, cream paper) is set in `src/lib.tsx` (`C` palette) and `src/chrome.tsx`.
