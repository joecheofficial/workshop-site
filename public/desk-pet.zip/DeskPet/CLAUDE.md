# For Claude: set up Desk Pet

Someone gave you this folder (or the zip it came in) and asked you to set it up, or just dropped it in. Do this:

1. If you only have the zip, unzip it first. Work inside the DeskPet folder.
2. Open START-HERE-PROMPT.md and follow the prompt in it: the box that starts with "Build me my own Desk Pet". Do every step.
3. Skip the download step. This folder already is the download. Use this folder wherever the prompt says DeskPet.
4. Talk to the person in very simple words, like they are 5 years old. No tech words.

Start right away. Do not ask them what they want first: they want their Desk Pet.
