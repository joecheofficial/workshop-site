# Make your own Desk Pet (a cute puppy for your Mac)

A little puppy sits on your screen and watches Claude work for you. You pick the dog: 10 breeds to choose from.
It types while Claude works, cheers when Claude is done, waves when Claude needs you, and naps when you walk away.

**You need two things:**
- A Mac.
- Claude Code. It comes with the Claude app. You need a paid Claude plan (Pro or more).

It does not work in normal Claude chat. It does not work in ChatGPT.

## Way 1: the easy way

1. Get the Claude app for Mac at claude.com/download. Log in.
2. Click **Code** at the top.
3. Drag the **DeskPet** folder into the chat. (The zip works too.)
4. Type **set it up** and press Enter.

Claude does the rest.

## Way 2: the Terminal way

1. Open Terminal.
2. Type `claude` and press Enter.
3. Copy everything in the box below, paste it in, and press Enter.

Does Terminal say `command not found: claude`? Then Claude Code is not set up yet. Use Way 1. Or paste this into Terminal, press Enter, then open a new Terminal window: `curl -fsSL https://claude.ai/install.sh | bash`

```text
Build me my own Desk Pet: a free Mac app where a cute puppy sits on my screen and reacts to Claude Code. It types while Claude works, cheers when Claude is done, waves when Claude needs me, and naps when I walk away. Go step by step. Talk to me in very simple words, like I am 5 years old. No tech words. Tell me what you are doing and why.

1. Check this is a Mac on macOS 13 or newer (sw_vers). If it isn't, stop and tell me Desk Pet only works on a Mac for now.

2. Check Apple's free command line tools are installed (xcode-select -p). If they aren't, run xcode-select --install, tell me to click Install in the window that pops up, and wait until I say it's done.

3. Download https://workshop.mastermindshq.business/desk-pet.zip and unzip it into a folder called DeskPet in my home folder.

4. Let me pick my dog.
   - Run: open shared/looks.html (it shows all 10 dogs with a number). Ask me: "Which dog do you want? Tell me the number or the name."
   - Then ask me, one at a time: "What's your dog's name?" and "What's your first name, so your dog can say hi?" and "What colour collar?" (suggest red, blue, pink, green or purple).
   - Write my answers into shared/avatar.js: look (use the key from the list at the top of the file, like golden or pug), petName, yourName, collar as #RRGGBB. Keep the comment block at the top.
   - Run: open shared/preview.html (it shows my dog in every mood). Ask me if I like it. If I want another dog or colour, update avatar.js and open the preview again, until I say it looks good.

5. Before you build it, read README.md, macos/build.sh and claude-code/install-hooks.sh, and tell me in one or two simple sentences what they do. Then run: bash macos/build.sh
   If the build fails, read the error, fix only what's needed to make it build, and run it again. Don't change what the app does.

6. Connect my pet to Claude Code, so it can see when you are working: run bash claude-code/install-hooks.sh
   Tell me: "From your next message, your dog reacts. Your dog only sees whether Claude is busy, done, or waiting. It never sees what you write."

7. At the end, tell me in simple words:
   - Your dog is at the bottom right of your screen. Drag it anywhere you like. Click it to say hi.
   - Give Claude any job and watch your dog type. When Claude is done, it cheers.
   - The little paw at the top of your screen has the menu: hide your dog, put it back, open at login, quit.
   - Want a different dog? Ask Claude to change shared/avatar.js in the DeskPet folder, then run bash macos/build.sh again.
   - Want to remove it? Quit it from the paw menu. Delete "Desk Pet" from Applications. Then run bash claude-code/install-hooks.sh --remove

Only touch the DeskPet folder, the app in Applications, and the hooks in ~/.claude/settings.json. The app never sends anything off my Mac.
```

That's it. Your own Claude sets up your dog and builds the app on your Mac. If something goes wrong, Claude reads the error and fixes it.
