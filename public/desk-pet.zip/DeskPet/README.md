# Desk Pet

A cute puppy that sits on your Mac screen and reacts to Claude Code. Pick from 10 dogs.

| Claude is... | Your pet... |
|---|---|
| working | types on a little laptop |
| done | cheers for 20 seconds |
| waiting for you | waves at you |
| (you walked away 3 min) | curls up for a nap, wakes up and stretches when you are back |
| (23:00 to 6:00, 1 quiet minute) | sleeps |

Click it to say hi (it tells you how many jobs Claude finished today). Double-click for a belly rub. Stroke it with the mouse for hearts. Drag it anywhere.
The paw menu has treats, a ball, outfits (party hat, bow, sunglasses, bandana) and walking on/off. Now and then a butterfly visits.

## Files

- `shared/avatar.js` your dog: which breed, its name, your name, collar colour
- `shared/looks.html` all 10 dogs to pick from
- `shared/pet.html`, `cartoon.js`, `mood.js` what you see, and the rules for each mood
- `shared/preview.html` your pet in every mood
- `macos/` the Mac app (`bash macos/build.sh` builds, installs and starts it)
- `claude-code/install-hooks.sh` adds 4 small Claude Code hooks. Each one writes one line to
  `~/Library/Application Support/DeskPet/claude.json` (busy, done or waiting, plus the time). Your pet reads that file.
  It never sees what you write to Claude. `--remove` takes the hooks out again.
  The app also checks WHEN Claude's chat files in `~/.claude/projects` last changed (never what is in them), so it
  reacts right away in the Claude app's Code tab and in Terminal, even in a chat that was open before setup.
- `tests/` checks for the mood rules, the hooks and the jobs counter

Nothing leaves your Mac. No accounts, no tracking.

Made by Masterminds HQ. MIT licence, see LICENSE.
