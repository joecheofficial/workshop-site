# Desk Pet

A cartoon of you that sits on your Mac screen and reacts to Claude Code.

| Claude is... | Your pet... |
|---|---|
| working | types on a little laptop |
| done | cheers for 20 seconds |
| waiting for you | waves at you |
| (you walked away 10 min) | naps |
| (it is 23:00 to 6:00) | sleeps |

Click it to say hi (it tells you how many jobs Claude finished today). Drag it anywhere.

## Files

- `shared/avatar.js` your cartoon (filled in by your own Claude from a photo or 5 questions)
- `shared/pet.html`, `cartoon.js`, `mood.js` what you see, and the rules for each mood
- `shared/preview.html` your pet in every mood
- `macos/` the Mac app (`bash macos/build.sh` builds, installs and starts it)
- `claude-code/install-hooks.sh` adds 4 small Claude Code hooks. Each one writes one line to
  `~/Library/Application Support/DeskPet/claude.json` (busy, done or waiting, plus the time). Your pet reads that file.
  It never sees what you write to Claude. `--remove` takes the hooks out again.
- `tests/` checks for the mood rules, the hooks and the jobs counter

Nothing leaves your Mac. No accounts, no tracking.

Made by Masterminds HQ. The cartoon drawing comes from Posture Coach, built on Ravi the Ravioli by Yahia ElSaman (MIT). See LICENSE.
