// swiftc -parse-as-library ../macos/Sources/Core.swift CounterTests.swift -o counter-tests && ./counter-tests
import Foundation

@main
struct CounterTests {
    static func main() {
        var n = 0
        func check(_ ok: Bool, _ name: String) { if !ok { print("FAIL - \(name)"); exit(1) }; n += 1; print("ok - \(name)") }
        let day1 = Date(timeIntervalSince1970: 1_800_000_000)
        let t1 = Int(day1.timeIntervalSince1970)
        var c = DoneCounter(day: DoneCounter.today(day1), count: 0, lastAt: 0)
        _ = c.observe(state: "working", at: t1, now: day1)
        check(c.count == 0, "working is not a finished job")
        _ = c.observe(state: "done", at: t1 + 10, now: day1)
        check(c.count == 1, "done counts once")
        _ = c.observe(state: "done", at: t1 + 10, now: day1)
        check(c.count == 1, "same done is not counted twice")
        _ = c.observe(state: "done", at: t1 + 90, now: day1)
        check(c.count == 2, "a new done counts again")
        let day2 = day1.addingTimeInterval(86_400)
        _ = c.observe(state: "done", at: t1 + 90, now: day2)
        check(c.count == 0 && c.day == DoneCounter.today(day2), "new day starts at 0")
        _ = c.observe(state: "done", at: Int(day2.timeIntervalSince1970) + 5, now: day2)
        check(c.count == 1, "first job of the new day")

        // Signals: hooks, another Mac, and chat-file activity (Claude app or Terminal, no setup)
        let n0 = 2_000_000_000
        var s = Signal.combine(hook: nil, remote: nil, chatAt: n0 - 2, now: n0)
        check(s.state == "working", "chat changing, no hooks = working (Claude app chat)")
        s = Signal.combine(hook: nil, remote: nil, chatAt: n0 - 30, now: n0)
        check(s.state == "idle", "chat quiet for 30 s, no hooks = idle")
        s = Signal.combine(hook: ("done", n0 - 1), remote: nil, chatAt: n0, now: n0)
        check(s.state == "done", "chat file written just after Stop hook does not hide the cheer")
        s = Signal.combine(hook: ("needs", n0 - 5), remote: nil, chatAt: n0 - 6, now: n0)
        check(s.state == "needs", "hook news newer than chat activity wins")
        s = Signal.combine(hook: ("working", n0 - 100), remote: ("done", n0 - 1), chatAt: nil, now: n0)
        check(s.state == "done" && s.at == n0 - 1, "newer news from the other Mac wins")
        check(Store.parse(Data("{\"state\":\"needs\",\"at\":5}".utf8))! == ("needs", 5), "reads the other Mac's file")

        // Activity: newest chat file time, only file dates, nested subagent chats too
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("pet-act-\(getpid())")
        let sub = tmp.appendingPathComponent("proj/chat1/subagents", isDirectory: true)
        try! FileManager.default.createDirectory(at: sub, withIntermediateDirectories: true)
        let a = tmp.appendingPathComponent("proj/chat1.jsonl"), b = sub.appendingPathComponent("agent.jsonl")
        try! Data("x".utf8).write(to: a); try! Data("x".utf8).write(to: b)
        try! FileManager.default.setAttributes([.modificationDate: Date(timeIntervalSince1970: 1_000)], ofItemAtPath: a.path)
        try! FileManager.default.setAttributes([.modificationDate: Date(timeIntervalSince1970: 2_000)], ofItemAtPath: b.path)
        check(Activity.lastChange(in: tmp) == 2_000, "finds the newest chat file, including subagents")
        check(Activity.lastChange(in: tmp.appendingPathComponent("nope")) == nil, "no Claude folder = no signal")
        try? FileManager.default.removeItem(at: tmp)
        print("\(n) passed")
    }
}
