// swiftc -parse-as-library ../macos/Sources/Core.swift CounterTests.swift -o counter-tests && ./counter-tests
import Foundation

@main
struct CounterTests {
    static func main() {
        var n = 0
        func check(_ ok: Bool, _ name: String) { if !ok { print("FAIL - \(name)"); exit(1) }; n += 1; print("ok - \(name)") }
        let day1 = Date(timeIntervalSince1970: 1_800_000_000)
        let t1 = Int(day1.timeIntervalSince1970)
        var c = DoneCounter(day: DoneCounter.today(day1), count: 0, lastAt: 0)
        _ = c.observe(state: "working", at: t1, now: day1)
        check(c.count == 0, "working is not a finished job")
        _ = c.observe(state: "done", at: t1 + 10, now: day1)
        check(c.count == 1, "done counts once")
        _ = c.observe(state: "done", at: t1 + 10, now: day1)
        check(c.count == 1, "same done is not counted twice")
        _ = c.observe(state: "done", at: t1 + 90, now: day1)
        check(c.count == 2, "a new done counts again")
        let day2 = day1.addingTimeInterval(86_400)
        _ = c.observe(state: "done", at: t1 + 90, now: day2)
        check(c.count == 0 && c.day == DoneCounter.today(day2), "new day starts at 0")
        _ = c.observe(state: "done", at: Int(day2.timeIntervalSince1970) + 5, now: day2)
        check(c.count == 1, "first job of the new day")
        print("\(n) passed")
    }
}
