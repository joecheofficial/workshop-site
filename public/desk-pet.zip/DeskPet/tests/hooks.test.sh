#!/bin/bash
# bash tests/hooks.test.sh  (installs the hooks into a throwaway settings file, twice, then removes them)
set -euo pipefail
cd "$(dirname "$0")/.."
T="$(mktemp -d)"; export DESK_PET_SETTINGS="$T/settings.json"
echo '{"model":"opus","hooks":{"Stop":[{"hooks":[{"type":"command","command":"echo mine"}]}]}}' > "$DESK_PET_SETTINGS"
bash claude-code/install-hooks.sh >/dev/null
bash claude-code/install-hooks.sh >/dev/null   # twice = still one copy
python3 - "$DESK_PET_SETTINGS" <<'PY'
import json,sys
d=json.load(open(sys.argv[1])); h=d["hooks"]
assert d["model"]=="opus"
for e,s in (("UserPromptSubmit","working"),("PostToolUse","working"),("Stop","done"),("Notification","needs")):
    ours=[x for g in h[e] for x in g["hooks"] if "DeskPet/pet-hook.sh" in x["command"]]
    assert len(ours)==1 and ours[0]["command"].endswith(s), (e,ours)
n=[g for g in h["Notification"] if any("DeskPet" in x["command"] for x in g["hooks"])][0]
assert "permission_prompt" in n["matcher"] and "idle_prompt" not in n["matcher"], "waves only for real questions"
assert any(x["command"]=="echo mine" for g in h["Stop"] for x in g["hooks"]), "kept your own Stop hook"
print("ok - install keeps your settings and adds 4 hooks once")
PY
bash claude-code/install-hooks.sh --remove >/dev/null
python3 - "$DESK_PET_SETTINGS" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
assert "DeskPet" not in json.dumps(d) and d["hooks"]["Stop"][0]["hooks"][0]["command"]=="echo mine" and d["model"]=="opus"
print("ok - remove takes out only Desk Pet's hooks")
PY
# the hook writes the file the app reads
HOME="$T" sh claude-code/pet-hook.sh needs
python3 -c "import json,sys;d=json.load(open('$T/Library/Application Support/DeskPet/claude.json'));assert d['state']=='needs' and d['at']>0;print('ok - hook writes claude.json')"
# optional mirror for a pet on another Mac
echo "$T/mirror.json" > "$T/Library/Application Support/DeskPet/mirror-to.txt"
HOME="$T" sh claude-code/pet-hook.sh done
python3 -c "import json;d=json.load(open('$T/mirror.json'));assert d['state']=='done';print('ok - mirror copy for a pet on another Mac')"
rm -rf "$T"
