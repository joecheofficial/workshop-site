// The cartoon of you. Drawing code from Posture Coach (built on Ravi the Ravioli, MIT). Reads window.AVATAR from avatar.js.
(() => {
"use strict";
const reduced = matchMedia("(prefers-reduced-motion: reduce)");
function squircle(a, n, scallop){
  const pts = [], N = 300;
  for (let i = 0; i < N; i++){
    const t = i / N * Math.PI * 2, c = Math.cos(t), s = Math.sin(t);
    let x = a * Math.sign(c) * Math.pow(Math.abs(c), 2/n), y = a * Math.sign(s) * Math.pow(Math.abs(s), 2/n);
    if (scallop){ const f = 1 + scallop.amp * (0.5 + 0.5 * Math.cos(scallop.k * t)); x *= f; y *= f; }
    pts.push([90 + x, 84 + y]);
  }
  return "M" + pts.map(p => p[0].toFixed(1) + " " + p[1].toFixed(1)).join("L") + "Z";
}
const BODY = squircle(42.5, 4.2, { amp:0.03, k:24 });
const PILLOW = squircle(29, 3.2);
const FORKS = (() => {
  let d = "";
  for (let j = 0; j < 24; j++){
    const t = (2*j + 1) * Math.PI / 24, c = Math.cos(t), s = Math.sin(t);
    const bx = 42 * Math.sign(c) * Math.pow(Math.abs(c), 2/4.2), by = 42 * Math.sign(s) * Math.pow(Math.abs(s), 2/4.2);
    d += `M${(90 + bx*.83).toFixed(1)} ${(84 + by*.83).toFixed(1)}L${(90 + bx*.92).toFixed(1)} ${(84 + by*.92).toFixed(1)}`;
  }
  return d;
})();
const EYES_OPEN = `<circle cx="77" cy="80" r="4.3" class="f-fill"/><circle cx="78.4" cy="78.5" r="1.3" fill="#fff"/><circle cx="103" cy="80" r="4.3" class="f-fill"/><circle cx="104.4" cy="78.5" r="1.3" fill="#fff"/>`;
const EYES_SHUT = `<path class="f-line" d="M73 80.5 Q77 83 81 80.5 M99 80.5 Q103 83 107 80.5"/>`;
const EYES_CALM = `<path class="f-line" d="M73 81 Q77 77 81 81 M99 81 Q103 77 107 81"/>`;
const FACES = {
  smile:{ eyes:EYES_OPEN, mouth:`<path class="f-line" d="M83 93 Q90 100.5 97 93"/>`, blink:true },
  grin:{ eyes:EYES_OPEN, mouth:`<path class="f-fill" d="M81 92 Q90 107 99 92 Z"/><path class="f-teeth" d="M82.4 93 Q90 96.6 97.6 93 L97 95 Q90 98 83 95 Z"/>`, blink:true },
  neutral:{ eyes:EYES_OPEN, mouth:`<path class="f-line" d="M85 96 L95 96"/>`, blink:true },
  tuck:{ eyes:EYES_OPEN, mouth:`<path class="f-line" d="M86 94.5 L94 94.5"/><path class="f-chin" d="M82.5 100.5 Q90 104.5 97.5 100.5"/>` },
  effort:{ eyes:`<path class="f-line" d="M73 77 L79.5 80 L73 83 M107 77 L100.5 80 L107 83"/>`, mouth:`<path class="f-line" d="M84 96.5 Q90 93.5 96 96.5"/>` },
  calm:{ eyes:EYES_CALM, mouth:`<path class="f-line" d="M85 94 Q90 98.5 95 94"/>` },
  unimpressed:{ eyes:`<path class="f-fill" d="M72.7 79 A4.3 4.3 0 0 0 81.3 79 Z M98.7 79 A4.3 4.3 0 0 0 107.3 79 Z"/><path class="f-line" d="M71.5 79 L82.5 79 M97.5 79 L108.5 79 M71.5 72 L82.5 71 M97.5 71 L108.5 72"/>`, mouth:`<path class="f-line" d="M84 96.5 L96 95"/>` },
  shh:{ eyes:EYES_CALM, mouth:`<circle cx="90" cy="96" r="2.8" class="f-fill"/>` },
  // Desk Pet faces
  focus:{ eyes:`<g transform="translate(0 2.5)">${EYES_OPEN}</g>`, mouth:`<path class="f-line" d="M86 95 Q90 97 94 95"/>`, blink:true },
  sleep:{ eyes:EYES_SHUT, mouth:`<ellipse cx="90" cy="96" rx="2.6" ry="3.2" class="f-fill"/>` },
  worried:{ eyes:`${EYES_OPEN}<path class="f-line" d="M71 73.5 L82 69.5 M109 73.5 L98 69.5"/>`, mouth:`<path class="f-line" d="M84 97 Q90 92.5 96 97"/>`, blink:true },
};
const BASE = { armL:[[38,110],[34,128]], armR:[[142,110],[146,128]], legL:[[70,152],[68,177]], legR:[[110,152],[112,177]], dx:0, dy:0, rot:0, sx:1, sy:1, ex:0, ey:0 };
const SEAT = { legL:[[58,146],[60,178]], legR:[[122,146],[120,178]] };
const HIPS = { armL:[[30,108],[50,122]], armR:[[150,108],[130,122]] };
const POSES = {
  idle:   { p:3.2, A:{}, B:{ dy:-1.6, sy:1.012 }, face:"smile" },
  wave:   { p:0.9, A:{ armR:[[152,78],[160,52]] }, B:{ armR:[[152,78],[171,60]] }, face:"grin" },
  cheer:  { p:0.75, A:{ armL:[[36,72],[28,48]], armR:[[144,72],[152,48]] }, B:{ armL:[[33,67],[21,42]], armR:[[147,67],[159,42]], dy:-7, legL:[[70,146],[68,170]], legR:[[110,146],[112,170]] }, face:"grin" },
  crossed:{ p:3.5, A:{ armL:[[44,112],[112,110]], armR:[[136,108],[68,106]] }, B:{ dy:-1 }, face:"unimpressed" },
  shh:    { p:3.4, A:{ armR:[[136,114],[97,99]] }, B:{ dy:-1 }, face:"shh" },
  tuck:   { p:3.0, A:{ ...HIPS }, B:{ sy:.95, dy:1.5 }, face:"neutral", faceB:"tuck" },
  arch:   { p:3.2, chair:true, A:{ ...SEAT, armL:[[28,62],[58,40]], armR:[[152,62],[122,40]] }, B:{ sy:.95, dy:-2, ey:-3, armL:[[25,57],[58,36]], armR:[[155,57],[122,36]] }, face:"smile", faceB:"effort" },
  walk:   { p:0.72, A:{ dy:-2, armL:[[44,108],[50,124]], armR:[[138,110],[134,128]], legL:[[72,142],[71,165]] }, B:{ dy:-2, armL:[[37,110],[31,126]], armR:[[136,108],[130,124]], legR:[[108,142],[109,165]] }, face:"smile" },
  squeeze:{ p:2.6, A:{ armL:[[26,92],[26,66]], armR:[[154,92],[154,66]] }, B:{ armL:[[36,100],[34,74]], armR:[[144,100],[146,74]], sx:.97 }, face:"smile", faceB:"effort" },
  doorway:{ p:3.0, A:{ armL:[[24,86],[20,58]], armR:[[156,86],[160,58]] }, B:{ armL:[[21,84],[15,58]], armR:[[159,84],[165,58]], sx:1.04, sy:1.04, dy:2 }, face:"calm" },
  tilt:   { p:3.4, A:{ rot:-10, armR:[[146,66],[124,42]] }, B:{ rot:-4, armR:[[148,70],[128,44]] }, face:"calm" },
  reach:  { p:3.0, A:{ armL:[[44,62],[50,28]], armR:[[136,62],[130,28]], dy:-3, sy:1.04 }, B:{ rot:-8 }, face:"smile" },
  twist:  { p:3.2, chair:true, A:{ ...SEAT, armL:[[60,112],[116,106]], armR:[[150,100],[146,80]], ex:5, rot:3 }, B:{ armL:[[30,100],[34,80]], armR:[[120,112],[64,106]], ex:-5, rot:-3 }, face:"smile" },
  wrist:  { p:2.4, A:{ armL:HIPS.armL, armR:[[158,92],[177,84]], ex:4 }, B:{ armR:[[158,92],[177,100]] }, face:"neutral" },
  gaze:   { p:4.0, A:{ armR:[[146,82],[113,67]], ex:-3, ey:-1 }, B:{ ex:3 }, face:"smile" },
  lunge:  { p:3.0, A:{ ...HIPS, dy:4, legL:[[62,146],[52,177]], legR:[[114,152],[128,178]] }, B:{ dy:8, legL:[[59,150],[49,177]], legR:[[117,156],[131,178]] }, face:"smile", faceB:"effort" },
  type:   { p:0.34, A:{ armL:[[50,120],[80,131]], armR:[[130,122],[101,134]], ey:2 }, B:{ armL:[[50,122],[79,134]], armR:[[130,120],[100,131]], ey:2 }, face:"focus" },
  sleep:  { p:4.2, A:{ rot:5, dy:2 }, B:{ rot:5, dy:3.5, sy:.975 }, face:"sleep" },
  call:   { p:0.6, A:{ armR:[[152,78],[160,50]], armL:[[36,96],[56,84]] }, B:{ armR:[[152,78],[173,58]], armL:[[36,96],[56,84]], dy:-3 }, face:"worried" },
  calf:   { p:1.6, A:{ ...HIPS }, B:{ dy:-8, legL:[[70,146],[69,170]], legR:[[110,146],[111,170]] }, face:"smile" },
};
for (const P of Object.values(POSES)){ P._A = { ...BASE, ...P.A }; P._B = { ...P._A, ...P.B }; }
const lerp = (a, b, k) => a + (b - a) * k;
const lerpPt = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k)];
const pts = (...ps) => ps.map(p => p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" ");
/* ---------- the cartoon: built from shared/avatar.js (your Claude fills it in from a photo or a few questions) ---------- */
const AV_DEFAULT = { name:"Pet", skin:"#E0AC85", hair:{ style:"short", color:"#3B2A22" }, beard:{ style:"none", color:"#3B2A22" },
  glasses:"none", shirt:{ style:"tee", color:"#2F5D8A" }, pants:"#36414F", shoes:"#241F19" };
const AV = (() => {
  const a = Object.assign({}, AV_DEFAULT, window.AVATAR || {});
  a.hair = Object.assign({}, AV_DEFAULT.hair, (window.AVATAR || {}).hair);
  a.beard = Object.assign({}, AV_DEFAULT.beard, (window.AVATAR || {}).beard);
  a.shirt = Object.assign({}, AV_DEFAULT.shirt, (window.AVATAR || {}).shirt);
  const hex = v => typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v);
  for (const [o, k] of [[a,"skin"],[a,"pants"],[a,"shoes"],[a.hair,"color"],[a.beard,"color"],[a.shirt,"color"]]) if (!hex(o[k])) o[k] = null;
  a.skin = a.skin || AV_DEFAULT.skin; a.pants = a.pants || AV_DEFAULT.pants; a.shoes = a.shoes || AV_DEFAULT.shoes;
  a.hair.color = a.hair.color || AV_DEFAULT.hair.color; a.beard.color = a.beard.color || a.hair.color; a.shirt.color = a.shirt.color || AV_DEFAULT.shirt.color;
  a.name = String(a.name || "Pet").slice(0, 14);
  return a;
})();
const CURLS = [[66,50,7],[73,42,8],[82,37,8.5],[92,35,8.5],[102,37,8.5],[111,42,8],[117,50,7],[62,58,5],[121,58,5],[78,44,6],[96,41,6],[108,46,6]];
const CAP = "M60 64 Q58 36 90 35 Q122 36 120 64 Q116 52 106 48 Q90 52 74 48 Q64 52 60 64 Z";
const HAIR_BACK = {   // drawn behind the head
  long:"M58 62 Q54 40 90 36 Q126 40 122 62 L126 104 Q118 110 110 104 L112 78 L68 78 L70 104 Q62 110 54 104 Z",
  wavy:"M58 62 Q54 40 90 36 Q126 40 122 62 Q128 76 122 90 Q116 96 112 88 L68 88 Q64 96 58 90 Q52 76 58 62 Z",
  ponytail:"M112 52 Q132 58 128 84 Q124 96 118 90 Q124 72 108 60 Z",
};
const HAIR_FRONT = {  // drawn over the head
  curly:  CURLS.map(([x,y,r]) => `<circle cx="${x}" cy="${y}" r="${r}"/>`).join(""),
  short:  `<path d="${CAP}"/>`,
  buzz:   `<path d="${CAP}" opacity=".55"/>`,
  long:   `<path d="M60 66 Q58 36 90 35 Q122 36 120 66 Q112 50 96 47 Q88 54 70 52 Q63 56 60 66 Z"/>`,
  wavy:   `<path d="M60 66 Q58 36 90 35 Q122 36 120 66 Q114 52 102 50 Q96 56 86 51 Q76 56 66 54 Q62 58 60 66 Z"/>`,
  bun:    `<circle cx="90" cy="31" r="9.5"/><path d="${CAP}"/>`,
  ponytail:`<path d="${CAP}"/>`,
  bald:   `<path d="M60 70 Q59 60 63 56 L64 68 Z M120 70 Q121 60 117 56 L116 68 Z"/>`,
  none:   ``,
};
const BEARD = {
  none:"",
  stubble:`<path class="r-beard" style="opacity:.32" d="M63 72 Q64 85 72 91 Q81 98 90 98 Q99 98 108 91 Q116 85 117 72 Q113 86 104 88 Q90 92 76 88 Q67 86 63 72 Z"/><path class="r-beard" style="opacity:.45" d="M80 76.5 Q90 72.5 100 76.5 Q90 75 80 76.5 Z"/>`,
  full:`<path class="r-beard" d="M62 70 Q62 88 72 95 Q81 103 90 103 Q99 103 108 95 Q118 88 118 70 Q114 86 104 87 Q97 82 90 83 Q83 82 76 87 Q66 86 62 70 Z"/><path class="r-beard" d="M79 77 Q90 72 101 77 Q90 76 79 77 Z"/>`,
  moustache:`<path class="r-beard" d="M78 77.5 Q90 71.5 102 77.5 Q96 79 90 77 Q84 79 78 77.5 Z"/>`,
};
const GLASSES = {
  none:"",
  round:`<g class="r-glasses"><circle cx="77" cy="66" r="7.6"/><circle cx="103" cy="66" r="7.6"/><path d="M84.6 66 Q90 63 95.4 66 M69.4 65 L62 63 M110.6 65 L118 63"/></g>`,
  square:`<g class="r-glasses"><rect x="68.5" y="59.5" width="17" height="13" rx="3"/><rect x="94.5" y="59.5" width="17" height="13" rx="3"/><path d="M85.5 65 Q90 62.5 94.5 65 M68.5 64 L62 62.5 M111.5 64 L118 62.5"/></g>`,
};
const SHIRT = {
  collar:`<path class="r-shirt" d="M80 95 Q90 99 100 95 L115 100 Q123 103 123 113 L121 133 Q90 137 59 133 L57 113 Q57 103 65 100 Z"/><path class="r-collar" d="M80 95 L90 106 L100 95 M90 106 V133"/><circle class="r-button" cx="90" cy="115" r="1.3"/><circle class="r-button" cx="90" cy="124" r="1.3"/>`,
  tee:`<path class="r-shirt" d="M80 95 Q90 103 100 95 L115 100 Q123 103 123 113 L121 133 Q90 137 59 133 L57 113 Q57 103 65 100 Z"/><path class="r-collar" d="M81 95.5 Q90 103 99 95.5"/>`,
  hoodie:`<path class="r-shirt" d="M80 95 Q90 103 100 95 L115 100 Q123 103 123 113 L121 133 Q90 137 59 133 L57 113 Q57 103 65 100 Z"/><path class="r-collar" d="M70 99 Q90 112 110 99 M86 104 V116 M94 104 V116"/><path class="r-collar" d="M78 123 H102"/>`,
};
const pick = (table, key, fallback) => table[key] != null ? table[key] : table[fallback];
const RAVI_SVG = `
<ellipse class="r-shadow" cx="90" cy="186" rx="44" ry="5"/>
<g class="r-chair" style="display:none"><path d="M56 26 H124 M58 26 V44 M122 26 V44"/><path d="M38 128 H142"/><path d="M46 129 L43 190 M134 129 L137 190"/></g>
<g class="r-legs"><polyline class="r-limb r-pants" data-k="legL"/><polyline class="r-limb r-pants" data-k="legR"/><ellipse class="r-shoe" data-k="shoeL" rx="7.5" ry="4.2"/><ellipse class="r-shoe" data-k="shoeR" rx="7.5" ry="4.2"/></g>
<g class="r-upper">
  ${HAIR_BACK[AV.hair.style] ? `<path class="r-hair-back" d="${HAIR_BACK[AV.hair.style]}"/>` : ""}
  ${pick(SHIRT, AV.shirt.style, "tee")}
  <rect class="r-neck" x="83" y="88" width="14" height="10" rx="4"/>
  <ellipse class="r-ear" cx="60" cy="69" rx="5" ry="7"/><ellipse class="r-ear" cx="120" cy="69" rx="5" ry="7"/>
  <path class="r-head" d="M61 64 Q61 40 90 40 Q119 40 119 64 Q119 82 108 91 Q99 98 90 98 Q81 98 72 91 Q61 82 61 64 Z"/>
  ${pick(BEARD, AV.beard.style, "none")}
  <g class="r-hair">${pick(HAIR_FRONT, AV.hair.style, "short")}</g>
  <path class="r-brow" d="M70 59.5 Q76 56.5 82 59 M98 59 Q104 56.5 110 59.5"/>
  <g class="r-face" transform="translate(0 -14)"><circle class="f-cheek" cx="68" cy="88" r="4.6"/><circle class="f-cheek" cx="112" cy="88" r="4.6"/><g class="r-eyes"></g><g class="r-mouth"></g></g>
  ${pick(GLASSES, AV.glasses, "none")}
  <polyline class="r-limb r-sleeve" data-k="armL"/><polyline class="r-limb r-sleeve" data-k="armR"/>
  <circle class="r-hand" data-k="handL" r="4.6"/><circle class="r-hand" data-k="handR" r="4.6"/>
</g>`;
const live = new Set();
function makeRavi(host, pose = "idle"){
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  host.appendChild(svg);
  svg.setAttribute("viewBox", "0 0 180 200");
  svg.setAttribute("class", "ravi");
  svg.setAttribute("aria-hidden", "true");
  svg.innerHTML = RAVI_SVG;
  for (const [k, v] of [["--skin", AV.skin], ["--hair", AV.hair.color], ["--stubble", AV.beard.color], ["--shirt", AV.shirt.color], ["--pants", AV.pants], ["--shoe", AV.shoes]]) svg.style.setProperty(k, v);
  const q = k => svg.querySelector(`[data-k="${k}"]`);
  return { svg, pose, t0:performance.now(), seed:Math.random()*4000, faceKey:"", eyeKey:"",
    upper:svg.querySelector(".r-upper"), chair:svg.querySelector(".r-chair"), eyes:svg.querySelector(".r-eyes"), mouth:svg.querySelector(".r-mouth"),
    armL:q("armL"), armR:q("armR"), legL:q("legL"), legR:q("legR"), handL:q("handL"), handR:q("handR"), shoeL:q("shoeL"), shoeR:q("shoeR") };
}
function setPose(inst, pose, { animate = true } = {}){
  if (!POSES[pose]) pose = "idle";
  if (inst.pose !== pose){ inst.pose = pose; inst.t0 = performance.now(); }
  if (animate) live.add(inst); else live.delete(inst);
  drawRavi(inst, performance.now(), animate ? null : 0.85);
}
function drawRavi(inst, now, fixedK){
  const P = POSES[inst.pose];
  const k = fixedK != null ? fixedK : (reduced.matches ? 0 : 0.5 - 0.5 * Math.cos(2 * Math.PI * ((now - inst.t0) / (P.p * 1000))));
  const A = P._A, B = P._B;
  const dx = lerp(A.dx, B.dx, k), dy = lerp(A.dy, B.dy, k), rot = lerp(A.rot, B.rot, k), sx = lerp(A.sx, B.sx, k), sy = lerp(A.sy, B.sy, k);
  inst.upper.setAttribute("transform", `translate(${dx.toFixed(2)} ${dy.toFixed(2)}) rotate(${rot.toFixed(2)} 90 128) translate(90 128) scale(${sx.toFixed(3)} ${sy.toFixed(3)}) translate(-90 -128)`);
  const eL = lerpPt(A.armL[0], B.armL[0], k), hL = lerpPt(A.armL[1], B.armL[1], k);
  const eR = lerpPt(A.armR[0], B.armR[0], k), hR = lerpPt(A.armR[1], B.armR[1], k);
  inst.armL.setAttribute("points", pts([61,105], eL, hL));
  inst.armR.setAttribute("points", pts([119,105], eR, hR));
  inst.handL.setAttribute("cx", hL[0].toFixed(1)); inst.handL.setAttribute("cy", hL[1].toFixed(1));
  inst.handR.setAttribute("cx", hR[0].toFixed(1)); inst.handR.setAttribute("cy", hR[1].toFixed(1));
  const kL = lerpPt(A.legL[0], B.legL[0], k), fL = lerpPt(A.legL[1], B.legL[1], k);
  const kR = lerpPt(A.legR[0], B.legR[0], k), fR = lerpPt(A.legR[1], B.legR[1], k);
  inst.legL.setAttribute("points", pts([74 + dx, 132 + dy], kL, fL));
  inst.legR.setAttribute("points", pts([106 + dx, 132 + dy], kR, fR));
  inst.shoeL.setAttribute("cx", (fL[0] - 3).toFixed(1)); inst.shoeL.setAttribute("cy", (fL[1] + 1.5).toFixed(1));
  inst.shoeR.setAttribute("cx", (fR[0] + 3).toFixed(1)); inst.shoeR.setAttribute("cy", (fR[1] + 1.5).toFixed(1));
  inst.chair.style.display = P.chair ? "" : "none";
  const faceName = (P.faceB && k > 0.5) ? P.faceB : P.face;
  const F = FACES[faceName];
  const blinking = F.blink && fixedK == null && !reduced.matches && ((now + inst.seed) % 4300) < 140;
  const fk = faceName + (blinking ? "-b" : "");
  if (fk !== inst.faceKey){ inst.faceKey = fk; inst.eyes.innerHTML = blinking ? EYES_SHUT : F.eyes; inst.mouth.innerHTML = F.mouth; }
  const ek = lerp(A.ex, B.ex, k).toFixed(1) + "," + lerp(A.ey, B.ey, k).toFixed(1);
  if (ek !== inst.eyeKey){ inst.eyeKey = ek; inst.eyes.setAttribute("transform", `translate(${ek.replace(","," ")})`); }
}
(function frame(now){
  for (const inst of live) drawRavi(inst, now);
  requestAnimationFrame(frame);
})(performance.now());
window.Cartoon = { POSES, FACES, EYES_SHUT, makeRavi, setPose, AV };
})();
