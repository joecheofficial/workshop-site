// Your pet: a little puppy, drawn from the choices in avatar.js (no images anywhere).
// Every pose is a CSS class on one SVG, so moods can switch smoothly. Open looks.html to see every dog.
(() => {
"use strict";

// Ready-made dogs. avatar.js picks one with `look`, and can change any single value on top.
// Each breed has its own shape, not just its own colour: ears, face markings, fluff and tail.
const LOOKS = {
  golden:    { label: "Golden Retriever", fur: "#E8AE6C", light: "#FFF4E4", ear: "#B9763C", ears: "floppy" },
  lab:       { label: "Chocolate Lab",    fur: "#8A5733", light: "#D9B08C", ear: "#5E3519", ears: "floppy" },
  dalmatian: { label: "Dalmatian",        fur: "#FFFFFF", light: "#FFFFFF", ear: "#2D2B2E", ears: "floppy", patch: "#2D2B2E" },
  beagle:    { label: "Beagle",           fur: "#D59A57", light: "#FFFFFF", ear: "#6E4425", ears: "floppy", blaze: true },
  corgi:     { label: "Corgi",            fur: "#E59A4E", light: "#FFFFFF", ear: "#C77A30", ears: "pointy", blaze: true },
  husky:     { label: "Husky",            fur: "#7F8996", light: "#FFFFFF", ear: "#5F6873", ears: "pointy", blaze: true, eyes: "blue" },
  shiba:     { label: "Shiba Inu",        fur: "#DB8742", light: "#FFF3E3", ear: "#C06F2E", ears: "pointy", tail: "curl" },
  pug:       { label: "Pug",              fur: "#E9C79A", light: "#F3DDBB", ear: "#3A302B", ears: "fold", mask: "#3A302B", tail: "curl" },
  frenchie:  { label: "French Bulldog",   fur: "#8F8D96", light: "#E6E2EC", ear: "#7A7881", ears: "bat" },
  poodle:    { label: "Poodle",           fur: "#F4EDE4", light: "#FFFFFF", ear: "#E6D8C6", ears: "fluffy", topknot: true },
};
const IRIS = { dark: null, blue: "#5AA6E0", amber: "#E0A23A", green: "#7FB24A" };
const EARS = ["floppy", "pointy", "fold", "bat", "fluffy"];

const AV = (() => {
  const a = window.AVATAR || {};
  const q = new URLSearchParams(location.search).get("look");      // looks.html shows each dog this way
  const key = LOOKS[q] ? q : LOOKS[a.look] ? a.look : "golden";
  const look = LOOKS[key], hex = v => /^#[0-9a-f]{6}$/i.test(v || "") ? v : null;
  return {
    look: key, label: look.label,
    fur: hex(a.fur) || look.fur, light: hex(a.light) || look.light, ear: hex(a.ear) || look.ear,
    ears: EARS.includes(a.ears) ? a.ears : look.ears,
    eyes: IRIS.hasOwnProperty(a.eyes) ? a.eyes : (look.eyes || "dark"),
    patch: a.patch === "none" ? null : hex(a.patch) || look.patch || null,
    mask: look.mask || null,
    blaze: !!look.blaze, topknot: !!look.topknot, tail: look.tail || "wag",
    collar: hex(a.collar) || "#E4572E",
    petName: String(a.petName || "").slice(0, 14),
    name: String(a.yourName || "").slice(0, 14),          // what your pet calls you
    sound: "Woof!",
  };
})();

const CSS = `
.pet{overflow:visible}
.pet .ink{fill:#1A231F}
.pet .ol{stroke:#1A231F;stroke-width:2.6;stroke-linejoin:round;stroke-linecap:round}
.pet .fur{fill:var(--fur)}
.pet .light{fill:var(--light)}
.pet .earc{fill:var(--ear)}
.pet .line{fill:none;stroke:#1A231F;stroke-width:2.6;stroke-linecap:round;stroke-linejoin:round}
.pet .thin{fill:none;stroke:#1A231F;stroke-width:1.4;stroke-linecap:round;opacity:.75}
.pet .shadow{fill:#1A231F;opacity:.1}
.pet .cheek{fill:#E4572E;opacity:.28}
.pet .inner{fill:#F2A7B0}
.pet *{transform-box:view-box}
.pet .tail{transform-origin:114px 178px}
.pet.t-curl .tail{animation-duration:2.4s}
.pet .leg-l{transform-origin:79.5px 146px;transition:transform .35s ease}
.pet .leg-r{transform-origin:100.5px 146px;transition:transform .35s ease}
.pet .head{transform-origin:90px 78px;transition:transform .45s ease}
.pet .flop-l{transform-origin:58px 52px}
.pet .flop-r{transform-origin:122px 52px}
.pet .eyes-open{transform-origin:90px 76px;transition:transform .3s}
.pet .all{transform-origin:90px 190px}
.pet .lie,.pet .lie-paws,.pet .laptop,.pet .eyes-happy,.pet .eyes-shut,.pet .m-open,.pet .m-sleep,.pet .brows,
.pet .ear-floppy,.pet .ear-pointy,.pet .ear-fold,.pet .ear-bat,.pet .ear-fluffy{display:none}
.pet.e-floppy .ear-floppy,.pet.e-pointy .ear-pointy,.pet.e-fold .ear-fold,.pet.e-bat .ear-bat,.pet.e-fluffy .ear-fluffy{display:inline}
/* idle: slow wag, blinking */
.pet .tail{animation:wag 1.6s ease-in-out infinite}
.pet .eyes-open{animation:blink 4.6s infinite}
.pet .flop-l{animation:flopl 5s ease-in-out infinite}
.pet .flop-r{animation:flopr 5s ease-in-out infinite}
/* typing on its laptop */
.pet.p-type .laptop{display:inline}
.pet.p-type .leg-l,.pet.p-type .leg-r{display:none}
.pet.p-type .head{transform:translateY(3px) rotate(-3deg)}
.pet.p-type .eyes-open{transform:translateY(3px)}
.pet.p-type .tp-l{animation:tap .32s ease-in-out infinite alternate}
.pet.p-type .tp-r{animation:tap .32s ease-in-out .16s infinite alternate}
/* cheering */
.pet.p-cheer .all{animation:hop .55s ease-in-out infinite}
.pet.p-cheer .leg-l{transform:rotate(122deg)}
.pet.p-cheer .leg-r{transform:rotate(-122deg)}
.pet.p-cheer .eyes-open{display:none}
.pet.p-cheer .eyes-happy,.pet.p-cheer .m-open{display:inline}
.pet.p-cheer .m-smile{display:none}
.pet.p-cheer .tail,.pet.p-wag .tail,.pet.p-wave .tail{animation-duration:.32s}
/* calling you */
.pet.p-call .m-open,.pet.p-call .brows,.pet.p-wave .m-open{display:inline}
.pet.p-call .m-smile,.pet.p-wave .m-smile{display:none}
.pet.p-call .leg-r,.pet.p-wave .leg-r{animation:wave .5s ease-in-out infinite alternate}
.pet.p-call .head{animation:bob .5s ease-in-out infinite alternate}
.pet.p-tilt .head{transform:rotate(-13deg)}
/* napping */
.pet.p-sleep .sit,.pet.p-sleep .eyes-open,.pet.p-sleep .m-smile{display:none}
.pet.p-sleep .lie,.pet.p-sleep .lie-paws,.pet.p-sleep .eyes-shut,.pet.p-sleep .m-sleep{display:inline}
.pet.p-sleep .head{transform:translate(-26px,72px) scale(.9) rotate(-6deg)}
.pet.p-sleep .lie-body{transform-origin:100px 190px;animation:breathe 3.2s ease-in-out infinite}
@keyframes wag{0%,100%{transform:rotate(-9deg)}50%{transform:rotate(11deg)}}
@keyframes blink{0%,92%,100%{transform:scaleY(1)}95%{transform:scaleY(.1)}}
@keyframes flopl{0%,80%,100%{transform:rotate(0)}88%{transform:rotate(7deg)}}
@keyframes flopr{0%,84%,100%{transform:rotate(0)}91%{transform:rotate(-7deg)}}
@keyframes tap{from{transform:translateY(0)}to{transform:translateY(-4px)}}
@keyframes hop{0%,100%{transform:translateY(0)}45%{transform:translateY(-16px)}}
@keyframes wave{from{transform:rotate(-105deg)}to{transform:rotate(-138deg)}}
@keyframes bob{from{transform:translateY(0)}to{transform:translateY(-3px)}}
@keyframes breathe{0%,100%{transform:scaleY(1)}50%{transform:scaleY(1.035)}}
@media (prefers-reduced-motion: reduce){.pet *{animation:none!important}}
`;

function eye(cx){
  const iris = IRIS[AV.eyes];
  if (!iris) return `<ellipse cx="${cx}" cy="76" rx="5.6" ry="6.6" class="ink"/><circle cx="${cx + 2.2}" cy="73.3" r="2.1" fill="#fff"/>`;
  return `<ellipse cx="${cx}" cy="76" rx="6.2" ry="7.2" fill="${iris}" stroke="#1A231F" stroke-width="1.6"/>` +
    `<ellipse cx="${cx}" cy="76.5" rx="2.6" ry="5" class="ink"/><circle cx="${cx + 2.2}" cy="73" r="1.9" fill="#fff"/>`;
}

function svg(){
  return `
<g class="all">
  <ellipse class="shadow" cx="90" cy="192" rx="50" ry="6"/>
  <g class="sit">
    <g class="tail">
      ${AV.tail === "curl"
        ? `<path d="M114 176 C142 178 152 150 136 144 C125 140 124 156 134 156" fill="none" stroke="#1A231F" stroke-width="13" stroke-linecap="round"/>
           <path d="M114 176 C142 178 152 150 136 144 C125 140 124 156 134 156" fill="none" stroke="var(--fur)" stroke-width="8" stroke-linecap="round"/>`
        : `<path d="M114 178 Q150 178 147 146" fill="none" stroke="#1A231F" stroke-width="13" stroke-linecap="round"/>
           <path d="M114 178 Q150 178 147 146" fill="none" stroke="var(--fur)" stroke-width="8" stroke-linecap="round"/>`}
    </g>
    <path class="fur ol" d="M58 188 C50 158 60 120 90 116 C120 120 130 158 122 188 Z"/>
    <ellipse class="fur ol" cx="64" cy="176" rx="17" ry="13"/>
    <ellipse class="fur ol" cx="116" cy="176" rx="17" ry="13"/>
    <ellipse class="light ol" cx="57" cy="188" rx="12" ry="5.5"/>
    <ellipse class="light ol" cx="123" cy="188" rx="12" ry="5.5"/>
    <ellipse class="light" cx="90" cy="160" rx="16" ry="22"/>
    ${AV.patch ? `<circle cx="70" cy="146" r="4.5" fill="var(--patch)"/><circle cx="113" cy="162" r="5.5" fill="var(--patch)"/><circle cx="66" cy="172" r="3.5" fill="var(--patch)"/>` : ""}
    <g class="leg-l"><rect class="fur ol" x="72" y="140" width="15" height="46" rx="7.5"/><ellipse class="light ol" cx="79.5" cy="186" rx="9" ry="5.5"/></g>
    <g class="leg-r"><rect class="fur ol" x="93" y="140" width="15" height="46" rx="7.5"/><ellipse class="light ol" cx="100.5" cy="186" rx="9" ry="5.5"/></g>
    <path d="M66 122 Q90 135 114 122" fill="none" stroke="var(--collar)" stroke-width="6.5" stroke-linecap="round"/>
    <circle cx="90" cy="132" r="4.8" fill="#E8B04B" stroke="#1A231F" stroke-width="1.6"/>
  </g>
  <g class="lie">
    <path d="M150 184 Q178 180 168 158" fill="none" stroke="#1A231F" stroke-width="12" stroke-linecap="round"/>
    <path d="M150 184 Q178 180 168 158" fill="none" stroke="var(--fur)" stroke-width="7" stroke-linecap="round"/>
    <g class="lie-body">
      <path class="fur ol" d="M40 190 C32 162 70 150 110 152 C150 154 166 172 158 190 Z"/>
      <ellipse class="fur ol" cx="136" cy="178" rx="19" ry="13"/>
      ${AV.patch ? `<circle cx="112" cy="166" r="5" fill="var(--patch)"/><circle cx="140" cy="172" r="4" fill="var(--patch)"/>` : ""}
    </g>
  </g>
  <g class="head">
    <g class="ear-pointy">
      <path class="earc ol" d="M50 66 Q42 30 56 12 Q76 24 86 44 Z"/><path class="light" d="M57 56 Q52 34 59 24 Q71 32 77 45 Z"/>
      <path class="earc ol" d="M130 66 Q138 30 124 12 Q104 24 94 44 Z"/><path class="light" d="M123 56 Q128 34 121 24 Q109 32 103 45 Z"/>
    </g>
    <g class="ear-bat">
      <path class="earc ol" d="M52 60 C34 34 42 8 58 12 C72 16 82 34 82 44 Z"/><path class="inner" d="M57 52 C46 34 50 20 59 22 C67 25 74 36 75 44 Z"/>
      <path class="earc ol" d="M128 60 C146 34 138 8 122 12 C108 16 98 34 98 44 Z"/><path class="inner" d="M123 52 C134 34 130 20 121 22 C113 25 106 36 105 44 Z"/>
    </g>
    <ellipse class="fur ol" cx="90" cy="78" rx="46" ry="40"/>
    ${AV.patch ? `<ellipse cx="108" cy="75" rx="12.5" ry="12" fill="var(--patch)"/>` : ""}
    ${AV.blaze ? `<path class="light" d="M83 90 Q85 62 90 44 Q95 62 97 90 Z"/>` : ""}
    ${AV.topknot ? `<g class="fur ol"><circle cx="70" cy="46" r="12"/><circle cx="110" cy="46" r="12"/><circle cx="80" cy="34" r="12"/><circle cx="100" cy="34" r="12"/><circle cx="90" cy="38" r="13"/></g>` : ""}
    <g class="ear-floppy">
      <path class="earc ol flop-l" d="M56 50 C38 50 30 84 38 102 C46 112 58 98 62 76 C64 62 62 52 56 50 Z"/>
      <path class="earc ol flop-r" d="M124 50 C142 50 150 84 142 102 C134 112 122 98 118 76 C116 62 118 52 124 50 Z"/>
    </g>
    <g class="ear-fold">
      <path class="earc ol flop-l" d="M50 52 Q58 38 74 42 Q70 56 60 64 Q54 62 50 52 Z"/>
      <path class="earc ol flop-r" d="M130 52 Q122 38 106 42 Q110 56 120 64 Q126 62 130 52 Z"/>
    </g>
    <g class="ear-fluffy earc ol">
      <g class="flop-l"><circle cx="45" cy="72" r="12"/><circle cx="41" cy="90" r="11.5"/><circle cx="47" cy="106" r="10.5"/></g>
      <g class="flop-r"><circle cx="135" cy="72" r="12"/><circle cx="139" cy="90" r="11.5"/><circle cx="133" cy="106" r="10.5"/></g>
    </g>
    <ellipse cx="90" cy="96" rx="19" ry="14" fill="${AV.mask || "var(--light)"}"/>
    <g class="eyes-open">${eye(72)}${eye(108)}</g>
    <path class="line eyes-happy" d="M65 79 Q72 70 79 79 M101 79 Q108 70 115 79"/>
    <path class="line eyes-shut" d="M65 77 Q72 82 79 77 M101 77 Q108 82 115 77"/>
    <path class="line brows" d="M64 63 L78 59 M102 59 L116 63"/>
    <ellipse class="cheek" cx="61" cy="90" rx="6.5" ry="4"/><ellipse class="cheek" cx="119" cy="90" rx="6.5" ry="4"/>
    <path class="ink" d="M83 89 Q90 85.5 97 89 Q96.5 94 90 95.5 Q83.5 94 83 89 Z"/><ellipse cx="87.5" cy="88.6" rx="2" ry="1.1" fill="#fff" opacity=".7"/>
    <path class="line m-smile" d="M90 95.5 V99 M82.5 98.5 Q86 103 90 99 Q94 103 97.5 98.5"${AV.mask ? ' style="stroke:#F3DDBB"' : ""}/>
    <g class="m-open"><path class="ink" d="M82.5 99 Q90 114 97.5 99 Q90 102 82.5 99 Z"/><path d="M85.5 104.5 Q90 113 94.5 104.5 Q90 106.5 85.5 104.5 Z" fill="#E4572E"/></g>
    <path class="line m-sleep" d="M86 100.5 Q90 102.5 94 100.5"${AV.mask ? ' style="stroke:#F3DDBB"' : ""}/>
  </g>
  <g class="lie-paws"><ellipse class="light ol" cx="50" cy="190" rx="11" ry="5.5"/><ellipse class="light ol" cx="76" cy="191" rx="11" ry="5.5"/></g>
  <g class="laptop">
    <rect x="48" y="146" width="84" height="44" rx="5" fill="#3C4350" stroke="#1A231F" stroke-width="2.4"/>
    <circle cx="90" cy="168" r="5" fill="#D97757"/>
    <path d="M38 189 H142 L136 197 H44 Z" fill="#A9B1BD" stroke="#1A231F" stroke-width="2.4" stroke-linejoin="round"/>
    <ellipse class="light ol tp-l" cx="74" cy="146" rx="9" ry="6"/>
    <ellipse class="light ol tp-r" cx="106" cy="146" rx="9" ry="6"/>
  </g>
</g>`;
}

function makePet(host, pose = "idle"){
  if (!document.getElementById("pet-css")){
    const s = document.createElement("style"); s.id = "pet-css"; s.textContent = CSS; document.head.appendChild(s);
  }
  const el = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  el.setAttribute("viewBox", "0 0 180 200");
  el.setAttribute("aria-label", AV.petName ? `${AV.petName}, your desk pet` : "Your desk pet");
  el.innerHTML = svg();
  for (const [k, v] of [["--fur", AV.fur], ["--light", AV.light], ["--ear", AV.ear], ["--patch", AV.patch || "none"], ["--collar", AV.collar]]) el.style.setProperty(k, v);
  host.appendChild(el);
  const inst = { el, pose: "" };
  setPose(inst, pose);
  return inst;
}

// poses: idle | type | cheer | call | sleep | wave | tilt | wag
function setPose(inst, pose){
  inst.pose = pose;
  inst.el.setAttribute("class", `pet e-${AV.ears} t-${AV.tail} p-${pose}`);
}

window.Cartoon = { LOOKS, AV, makePet, setPose };
})();
