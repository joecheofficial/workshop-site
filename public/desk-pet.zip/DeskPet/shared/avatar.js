// Your dog. Desk Pet draws it from these choices (no image is stored anywhere).
// Change a value, then run `bash macos/build.sh` again. Open looks.html to see every dog, preview.html for every mood.
//
// look       golden | lab | dalmatian | beagle | corgi | husky | shiba | pug | frenchie | poodle
// petName    your dog's name, up to 14 letters
// yourName   what your dog calls you when you click it, up to 14 letters ("" = just "Hi!")
// collar     collar colour as #RRGGBB
//
// Optional, to change one thing on top of the breed:
//   fur, light (face, tummy and paws), ear   colours as #RRGGBB
//   ears       floppy | pointy | fold | bat | fluffy
//   eyes       dark | blue | amber | green
//   patch      #RRGGBB for an eye patch and spots, or "none"
window.AVATAR = {
  look: "golden",
  petName: "Biscuit",
  yourName: "",
  collar: "#E4572E",
};
