// What your pet is doing right now. Pure rules, no screen code, so tests can check them.
//
// The app sends, every second:
//   claude  { state: "working" | "done" | "needs" | "idle", at: unix seconds }  (written by the Claude Code hooks)
//   now     unix seconds
//   hour    0-23, your local time
//   away    seconds since you last touched the mouse or keyboard
//   done    how many jobs Claude finished today
(function (root) {
  "use strict";
  const MIN = 60;
  const RULES = {
    doneShowFor: 20,          // cheer for 20 seconds after Claude finishes
    waveFor: 12,              // wave and woof once for 12 seconds when Claude needs you...
    needsShowFor: 5 * MIN,    // ...then sit and look at you quietly, for up to 5 minutes
    workingMax: 30 * MIN,     // no news for 30 minutes = Claude is not working any more
    sleepyAfter: 3 * MIN,     // you left the computer 3 minutes ago = nap (even while Claude works)
    nightSleepyAfter: MIN,    // at night it dozes off after 1 quiet minute
    nightFrom: 23, nightTo: 6,
  };

  function decide(st, name) {
    st = st || {};
    const c = st.claude || {}, now = st.now || 0, age = c.at ? now - c.at : Infinity;
    const night = st.hour >= RULES.nightFrom || st.hour < RULES.nightTo;
    const seen = st.seenNeedsAt && st.seenNeedsAt >= c.at;   // you clicked the pet: it knows you saw it
    if (c.state === "needs" && !seen && age < RULES.waveFor)
      return { mood: "needs", pose: "call", say: "Claude needs you!", sayMs: 6000 };
    if (c.state === "needs" && !seen && age < RULES.needsShowFor)
      return { mood: "waiting", pose: "idle", say: "" };
    if (c.state === "done" && age < RULES.doneShowFor)
      return { mood: "done", pose: "cheer", say: "Done! Go have a look.", sayMs: 8000 };
    const away = st.away || 0;
    if (night && away >= RULES.nightSleepyAfter)
      return { mood: "night", pose: "sleep", say: "" };
    if (away >= RULES.sleepyAfter)
      return { mood: "sleep", pose: "sleep", say: "" };
    if (c.state === "working" && age < RULES.workingMax)
      return { mood: "working", pose: "type", say: "Claude is on it...", sayMs: 4000 };
    return { mood: "idle", pose: "idle", say: "" };
  }

  function pokeLine(st, name) {
    const n = (st && st.done) || 0;
    const hi = name && name !== "Pet" ? `Hi ${name}! ` : "Hi! ";
    if (n === 0) return hi + "Give Claude a job and watch me work.";
    if (n === 1) return hi + "Claude finished 1 job today.";
    return hi + `Claude finished ${n} jobs today.`;
  }

  // Fake states for preview.html and the tests.
  function demo(kind) {
    const now = Math.floor(Date.now() / 1000);
    const base = { now, hour: 14, away: 0, done: 7, claude: { state: "idle", at: now - 3600 } };
    if (kind === "working") base.claude = { state: "working", at: now - 5 };
    if (kind === "done") base.claude = { state: "done", at: now - 2 };
    if (kind === "needs") base.claude = { state: "needs", at: now - 2 };
    if (kind === "sleep") base.away = 20 * MIN;
    if (kind === "night") { base.hour = 1; base.away = 5 * MIN; }
    return base;
  }

  const api = { decide, pokeLine, demo, RULES };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.PetMood = api;
})(typeof window !== "undefined" ? window : globalThis);
