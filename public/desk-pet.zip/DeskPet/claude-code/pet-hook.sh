#!/bin/sh
# Claude Code calls this when Claude starts working, finishes, or needs you.
# It writes one tiny file on your Mac that your Desk Pet reads. Nothing leaves your computer.
dir="$HOME/Library/Application Support/DeskPet"
mkdir -p "$dir"
printf '{"state":"%s","at":%s}\n' "${1:-idle}" "$(date +%s)" > "$dir/claude.json.tmp" && mv "$dir/claude.json.tmp" "$dir/claude.json"
# Optional: if your pet lives on another Mac, mirror-to.txt names a file that Mac can read. Most people never have it.
if [ -f "$dir/mirror-to.txt" ]; then
  m="$(head -n 1 "$dir/mirror-to.txt")"
  cp "$dir/claude.json" "$m.tmp" 2>/dev/null && chmod 644 "$m.tmp" && mv "$m.tmp" "$m"   # readable by the web server
fi
exit 0
