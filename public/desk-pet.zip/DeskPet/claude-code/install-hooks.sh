#!/bin/bash
# Adds Desk Pet's hooks to Claude Code (~/.claude/settings.json), keeping everything already there.
#   bash claude-code/install-hooks.sh            add the hooks (safe to run twice)
#   bash claude-code/install-hooks.sh --remove   take them out again
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Library/Application Support/DeskPet"
mkdir -p "$DEST"
cp "$HERE/pet-hook.sh" "$DEST/pet-hook.sh"
chmod +x "$DEST/pet-hook.sh"
SETTINGS="${DESK_PET_SETTINGS:-$HOME/.claude/settings.json}"
mkdir -p "$(dirname "$SETTINGS")"
[ -f "$SETTINGS" ] && cp "$SETTINGS" "$SETTINGS.before-desk-pet"
/usr/bin/python3 - "$SETTINGS" "$DEST/pet-hook.sh" "${1:-}" <<'PY'
import json, os, sys
path, hook, mode = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    with open(path) as f: data = json.load(f)
except FileNotFoundError:
    data = {}
hooks = data.setdefault("hooks", {})
def ours(group):
    return any("DeskPet/pet-hook.sh" in h.get("command", "") for h in group.get("hooks", []))
# working: you sent a message, or Claude just used a tool; done: Claude finished;
# needs: Claude asks you something (a permission or a form). Not the "you haven't typed in a while" reminder.
ASKS = "permission_prompt|elicitation_dialog|elicitation_url_dialog|agent_needs_input"
for event, state in (("UserPromptSubmit", "working"), ("PostToolUse", "working"), ("Stop", "done"), ("Notification", "needs")):
    groups = [g for g in hooks.get(event, []) if not ours(g)]
    if mode != "--remove":
        g = {"hooks": [{"type": "command", "command": f'"{hook}" {state}', "timeout": 5}]}
        if event == "Notification": g = {"matcher": ASKS, **g}
        groups.append(g)
    if groups: hooks[event] = groups
    else: hooks.pop(event, None)
if not hooks: data.pop("hooks", None)
tmp = path + ".tmp"
with open(tmp, "w") as f: json.dump(data, f, indent=2); f.write("\n")
os.replace(tmp, path)
print("Removed Desk Pet's Claude Code hooks." if mode == "--remove" else "Your pet is now connected to Claude Code. It reacts the next time you give Claude a job.")
PY
