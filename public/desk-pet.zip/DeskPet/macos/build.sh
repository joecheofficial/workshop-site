#!/bin/bash
# Builds "Desk Pet.app" from macos/Sources and the shared pet page, installs it in Applications and starts it.
#   bash macos/build.sh               build, install, start
#   bash macos/build.sh --no-install  just build (into macos/build/Desk Pet.app)
set -euo pipefail
cd "$(dirname "$0")"
SHARED="../shared"
INSTALL=1
[ "${1:-}" = "--no-install" ] && INSTALL=0

if ! command -v swiftc >/dev/null 2>&1; then
  echo "Swift isn't installed yet. Run this, accept the prompt, then run build.sh again:"
  echo "  xcode-select --install"
  exit 1
fi

echo "Building Desk Pet..."
rm -rf build
APP="build/Desk Pet.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/shared"

# a universal app: runs natively on Apple silicon and Intel Macs
for arch in arm64 x86_64; do
  swiftc -O -swift-version 5 -parse-as-library \
    -target "$arch-apple-macos13.0" \
    Sources/Core.swift Sources/App.swift \
    -o "build/DeskPet-$arch" \
    -framework AppKit -framework WebKit -framework ServiceManagement
done
lipo -create build/DeskPet-arm64 build/DeskPet-x86_64 -output "$APP/Contents/MacOS/DeskPet"
rm build/DeskPet-arm64 build/DeskPet-x86_64

cp Info.plist "$APP/Contents/"
cp "$SHARED/pet.html" "$SHARED/avatar.js" "$SHARED/cartoon.js" "$SHARED/mood.js" "$APP/Contents/Resources/shared/"
iconutil -c icns Resources/AppIcon.iconset -o "$APP/Contents/Resources/AppIcon.icns"
codesign --force --sign - "$APP" >/dev/null 2>&1 || true

if [ "$INSTALL" = 0 ]; then
  echo "Built $(pwd)/$APP"
  exit 0
fi

osascript -e 'quit app "Desk Pet"' >/dev/null 2>&1 || pkill -x DeskPet 2>/dev/null || true
sleep 0.8

DEST="/Applications"
if [ ! -w "$DEST" ]; then DEST="$HOME/Applications"; mkdir -p "$DEST"; fi
rm -rf "$DEST/Desk Pet.app"
cp -R "$APP" "$DEST/"
open "$DEST/Desk Pet.app"

echo ""
echo "Done. Your Desk Pet is on your screen (bottom right). Look for the little paw in your menu bar too."
echo "Installed at $DEST/Desk Pet.app"
