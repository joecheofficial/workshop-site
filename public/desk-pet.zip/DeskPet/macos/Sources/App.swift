// Desk Pet for macOS: a puppy that sits on your screen and reacts to Claude Code.
// The window and menu live here. What the pet does is decided in shared/mood.js.
// Nothing leaves your Mac: the app reads one small file the Claude Code hooks write, and checks WHEN
// Claude's chat files last changed (never what is in them), so it reacts in the Claude app and in Terminal.

import AppKit
import WebKit
import ServiceManagement

let WEB_URL = "https://workshop.mastermindshq.business/giveaways/desk-pet"
let PET_SIZE = NSSize(width: 190, height: 220)

// MARK: - The pet window

final class PetPanel: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}

/// Sits on top of the web view: drag moves the pet, click pokes it, right-click opens the menu.
final class Grabber: NSView {
    var onPoke: (() -> Void)?
    var onMoved: (() -> Void)?
    var rightMenu: NSMenu?
    private var start = NSPoint.zero
    private var origin = NSPoint.zero
    private var dragged = false

    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
    override func mouseDown(with e: NSEvent) {
        start = NSEvent.mouseLocation; origin = window?.frame.origin ?? .zero; dragged = false
    }
    override func mouseDragged(with e: NSEvent) {
        let p = NSEvent.mouseLocation
        let dx = p.x - start.x, dy = p.y - start.y
        if abs(dx) + abs(dy) > 3 { dragged = true }
        window?.setFrameOrigin(NSPoint(x: origin.x + dx, y: origin.y + dy))
    }
    override func mouseUp(with e: NSEvent) {
        if dragged { onMoved?() } else { onPoke?() }
    }
    override func rightMouseDown(with e: NSEvent) {
        if let m = rightMenu { NSMenu.popUpContextMenu(m, with: e, for: self) }
    }
}

// MARK: - App

@MainActor
final class PetApp: NSObject, NSApplicationDelegate, NSMenuDelegate, WKScriptMessageHandler {
    var panel: PetPanel!
    var web: WKWebView!
    var statusItem: NSStatusItem!
    let menu = NSMenu()
    var timer: Timer?
    var ready = false
    var counter = DoneCounter.load()
    var hidden = UserDefaults.standard.bool(forKey: "hidden")
    var ticks = 0
    var chatAt: Int?
    var remote: (state: String, at: Int)?

    var sharedDir: URL { Bundle.main.resourceURL!.appendingPathComponent("shared", isDirectory: true) }

    func applicationDidFinishLaunching(_ n: Notification) {
        if let id = Bundle.main.bundleIdentifier,
           NSRunningApplication.runningApplications(withBundleIdentifier: id).count > 1 {
            NSApp.terminate(nil); return
        }
        try? FileManager.default.createDirectory(at: Store.dir, withIntermediateDirectories: true)
        let firstRun = !UserDefaults.standard.bool(forKey: "launchedBefore")
        if firstRun { UserDefaults.standard.set(true, forKey: "launchedBefore"); setOpenAtLogin(true) }

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem.button?.image = PetApp.menuIcon()
        statusItem.button?.toolTip = "Desk Pet"
        menu.delegate = self
        menu.autoenablesItems = false
        statusItem.menu = menu

        setupPanel()
        if !hidden { panel.orderFrontRegardless() }

        let t = Timer(timeInterval: 1, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
        t.tolerance = 0.3
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    func setupPanel() {
        let cfg = WKWebViewConfiguration()
        cfg.userContentController.add(self, name: "pet")
        cfg.websiteDataStore = .nonPersistent()
        let frame = NSRect(origin: .zero, size: PET_SIZE)
        web = WKWebView(frame: frame, configuration: cfg)
        web.setValue(false, forKey: "drawsBackground")
        web.autoresizingMask = [.width, .height]

        panel = PetPanel(contentRect: frame, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = .floating
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false

        let box = NSView(frame: frame)
        box.autoresizingMask = [.width, .height]
        box.addSubview(web)
        let grab = Grabber(frame: frame)
        grab.autoresizingMask = [.width, .height]
        grab.onPoke = { [weak self] in self?.js("Pet.poke()") }
        grab.onMoved = { [weak self] in self?.savePosition() }
        grab.rightMenu = menu
        box.addSubview(grab)
        panel.contentView = box

        panel.setFrameOrigin(savedOrigin())
        web.loadFileURL(sharedDir.appendingPathComponent("pet.html"), allowingReadAccessTo: sharedDir)
    }

    /// Bottom right, just above the Dock, unless you moved it before.
    func savedOrigin() -> NSPoint {
        let d = UserDefaults.standard
        if d.object(forKey: "petX") != nil {
            let p = NSPoint(x: d.double(forKey: "petX"), y: d.double(forKey: "petY"))
            if NSScreen.screens.contains(where: { $0.visibleFrame.insetBy(dx: -40, dy: -40).contains(p) }) { return p }
        }
        let vf = (NSScreen.main ?? NSScreen.screens[0]).visibleFrame
        return NSPoint(x: vf.maxX - PET_SIZE.width - 24, y: vf.minY + 12)
    }
    func savePosition() {
        UserDefaults.standard.set(Double(panel.frame.origin.x), forKey: "petX")
        UserDefaults.standard.set(Double(panel.frame.origin.y), forKey: "petY")
    }

    func js(_ code: String) { web.evaluateJavaScript(code, completionHandler: nil) }

    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        guard let s = m.body as? String, s.contains("\"ready\"") else { return }
        ready = true
        tick()
    }

    /// Every 2 seconds: when did a Claude chat last change, and (only if remote-url.txt exists) the other Mac's file.
    func refreshSignals() {
        let root = Activity.projects
        DispatchQueue.global(qos: .utility).async {
            let at = Activity.lastChange(in: root)
            DispatchQueue.main.async { self.chatAt = at }
        }
        guard let url = Store.remoteURL else { remote = nil; return }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 1.5)
        req.httpMethod = "GET"
        URLSession.shared.dataTask(with: req) { data, _, _ in
            let r = data.flatMap(Store.parse)
            DispatchQueue.main.async { if let r = r { self.remote = r } }
        }.resume()
    }

    @objc func tick() {
        if ticks % 2 == 0 { refreshSignals() }
        ticks += 1
        let now = Int(Date().timeIntervalSince1970)
        let claude: (state: String, at: Int)? = Signal.combine(hook: Store.readClaude(), remote: remote, chatAt: chatAt, now: now)
        if let c = claude, counter.observe(state: c.state, at: c.at) { counter.save() }
        guard ready, !hidden else { return }
        let hour = Calendar.current.component(.hour, from: Date())
        let away = Int(CGEventSource.secondsSinceLastEventType(.combinedSessionState, eventType: CGEventType(rawValue: ~0)!))
        let st: [String: Any] = [
            "claude": ["state": claude?.state ?? "idle", "at": claude?.at ?? 0],
            "now": now, "hour": hour, "away": away, "done": counter.count,
        ]
        if let data = try? JSONSerialization.data(withJSONObject: st), let json = String(data: data, encoding: .utf8) {
            js("Pet.update(\(json))")
        }
    }

    // MARK: menu

    static func menuIcon() -> NSImage {
        let img = NSImage(size: NSSize(width: 18, height: 18), flipped: false) { _ in
            NSColor.black.setFill(); NSColor.black.setStroke()
            // a paw: one big pad and four toes (template image, macOS tints it)
            NSBezierPath(ovalIn: NSRect(x: 5, y: 2.5, width: 8, height: 7)).fill()
            for (x, y) in [(2.2, 8.6), (5.4, 11.8), (9.6, 11.8), (12.8, 8.6)] {
                NSBezierPath(ovalIn: NSRect(x: x, y: y, width: 3.2, height: 3.8)).fill()
            }
            return true
        }
        img.isTemplate = true
        return img
    }

    func menuNeedsUpdate(_ m: NSMenu) {
        m.removeAllItems()
        let jobs = counter.count == 1 ? "1 job" : "\(counter.count) jobs"
        let info = NSMenuItem(title: "Claude finished \(jobs) today", action: nil, keyEquivalent: "")
        info.isEnabled = false
        m.addItem(info)
        m.addItem(.separator())
        m.addItem(item(hidden ? "Show my pet" : "Hide my pet", #selector(toggleHidden)))
        m.addItem(item("Put it back in the corner", #selector(resetPosition)))
        let login = item("Open at login", #selector(toggleLogin))
        login.state = isOpenAtLogin() ? .on : .off
        m.addItem(login)
        m.addItem(.separator())
        m.addItem(item("About Desk Pet", #selector(openWeb)))
        m.addItem(item("Quit Desk Pet", #selector(quit), key: "q"))
    }
    func item(_ title: String, _ action: Selector, key: String = "") -> NSMenuItem {
        let i = NSMenuItem(title: title, action: action, keyEquivalent: key)
        i.target = self
        return i
    }

    @objc func toggleHidden() {
        hidden.toggle()
        UserDefaults.standard.set(hidden, forKey: "hidden")
        if hidden { panel.orderOut(nil) } else { panel.orderFrontRegardless(); tick() }
    }
    @objc func resetPosition() {
        UserDefaults.standard.removeObject(forKey: "petX"); UserDefaults.standard.removeObject(forKey: "petY")
        panel.setFrameOrigin(savedOrigin())
        if hidden { toggleHidden() }
    }
    @objc func toggleLogin() { setOpenAtLogin(!isOpenAtLogin()) }
    @objc func openWeb() { if let u = URL(string: WEB_URL) { NSWorkspace.shared.open(u) } }
    @objc func quit() { NSApp.terminate(nil) }

    func isOpenAtLogin() -> Bool { SMAppService.mainApp.status == .enabled }
    func setOpenAtLogin(_ on: Bool) {
        do { if on { try SMAppService.mainApp.register() } else { try SMAppService.mainApp.unregister() } }
        catch { NSLog("DeskPet: open at login: %@", error.localizedDescription) }
    }
}

@main
struct Main {
    static func main() {
        let app = NSApplication.shared
        let delegate = MainActor.assumeIsolated { PetApp() }
        app.delegate = delegate
        app.setActivationPolicy(.accessory)
        app.run()
    }
}
