// Desk Pet: the small parts with no window code (file reading, the jobs counter), so tests can run them.

import Foundation

// MARK: - Files

enum Store {
    static var dir: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base.appendingPathComponent("DeskPet", isDirectory: true)
    }
    static var claudeFile: URL { dir.appendingPathComponent("claude.json") }

    /// What the hooks last wrote: {"state":"working","at":1761800000}
    static func readClaude() -> (state: String, at: Int)? {
        guard let data = try? Data(contentsOf: claudeFile),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let state = obj["state"] as? String else { return nil }
        let at = (obj["at"] as? NSNumber)?.intValue ?? 0
        return (state, at)
    }

    /// Optional: the address of another Mac's pet file (one line in remote-url.txt), for people whose
    /// Claude Code runs on a different Mac than the pet. Most people never have this file.
    static var remoteURL: URL? {
        guard let s = try? String(contentsOf: dir.appendingPathComponent("remote-url.txt"), encoding: .utf8) else { return nil }
        return URL(string: s.trimmingCharacters(in: .whitespacesAndNewlines))
    }
    static func parse(_ data: Data) -> (state: String, at: Int)? {
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let state = obj["state"] as? String else { return nil }
        return (state, (obj["at"] as? NSNumber)?.intValue ?? 0)
    }
}

// MARK: - Claude activity, with no setup

/// When any Claude Code chat on this Mac last changed, in the Claude app or in Terminal.
/// Claude saves every chat as a file in ~/.claude/projects while it works. We only look at WHEN a file
/// last changed, never inside it, so the pet still never sees what you write.
enum Activity {
    static var projects: URL {
        let env = ProcessInfo.processInfo.environment["CLAUDE_CONFIG_DIR"]
        let base = env.map { URL(fileURLWithPath: $0) } ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent(".claude")
        return base.appendingPathComponent("projects", isDirectory: true)
    }
    static func lastChange(in root: URL = projects) -> Int? {
        let fm = FileManager.default
        let keys: [URLResourceKey] = [.contentModificationDateKey, .isDirectoryKey]
        guard let folders = try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: keys) else { return nil }
        var newest: Date?
        func look(_ dir: URL, depth: Int) {
            guard let items = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys) else { return }
            for u in items {
                let v = try? u.resourceValues(forKeys: Set(keys))
                if v?.isDirectory == true { if depth > 0 { look(u, depth: depth - 1) }; continue }
                guard u.pathExtension == "jsonl", let d = v?.contentModificationDate else { continue }
                if newest == nil || d > newest! { newest = d }
            }
        }
        for f in folders { look(f, depth: 2) }   // project/chat.jsonl and project/chat/subagents/agent.jsonl
        return newest.map { Int($0.timeIntervalSince1970) }
    }
}

/// Puts the signals together: the hooks (best: they also know "done" and "needs"), another Mac's pet file,
/// and chat-file activity (works even in a chat that was open before the hooks were added).
enum Signal {
    static let busyFor = 8      // a chat file changed in the last 8 s = Claude is working
    static let quietAfter = 20  // nothing new for 20 s and no hook news = back to idle
    static func combine(hook: (state: String, at: Int)?, remote: (state: String, at: Int)?, chatAt: Int?, now: Int) -> (state: String, at: Int) {
        var best = hook ?? ("idle", 0)
        if let r = remote, r.at > best.at { best = r }
        guard let c = chatAt, c > best.at + 3 else { return best }
        if now - c <= busyFor { return ("working", c) }
        if now - c >= quietAfter { return ("idle", c) }
        return ("working", c)
    }
}

/// Counts Claude's finished jobs per day (kept in UserDefaults, only on this Mac).
struct DoneCounter {
    var day: String
    var count: Int
    var lastAt: Int

    static func today(_ now: Date = Date()) -> String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"; f.timeZone = .current
        return f.string(from: now)
    }
    static func load() -> DoneCounter {
        let d = UserDefaults.standard
        return DoneCounter(day: d.string(forKey: "doneDay") ?? today(), count: d.integer(forKey: "doneCount"), lastAt: d.integer(forKey: "doneLastAt"))
    }
    func save() {
        let d = UserDefaults.standard
        d.set(day, forKey: "doneDay"); d.set(count, forKey: "doneCount"); d.set(lastAt, forKey: "doneLastAt")
    }
    /// Call every tick. Counts each new "done" once, and starts again at 0 each day.
    mutating func observe(state: String, at: Int, now: Date = Date()) -> Bool {
        var changed = false
        let t = DoneCounter.today(now)
        if t != day { day = t; count = 0; changed = true }
        if state == "done" && at > lastAt {
            lastAt = at
            if DoneCounter.today(Date(timeIntervalSince1970: TimeInterval(at))) == day { count += 1 }
            changed = true
        }
        return changed
    }
}
