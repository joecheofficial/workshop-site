// Desk Pet: the small parts with no window code (file reading, the jobs counter), so tests can run them.

import Foundation

// MARK: - Files

enum Store {
    static var dir: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base.appendingPathComponent("DeskPet", isDirectory: true)
    }
    static var claudeFile: URL { dir.appendingPathComponent("claude.json") }

    /// What the hooks last wrote: {"state":"working","at":1761800000}
    static func readClaude() -> (state: String, at: Int)? {
        guard let data = try? Data(contentsOf: claudeFile),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let state = obj["state"] as? String else { return nil }
        let at = (obj["at"] as? NSNumber)?.intValue ?? 0
        return (state, at)
    }
}

/// Counts Claude's finished jobs per day (kept in UserDefaults, only on this Mac).
struct DoneCounter {
    var day: String
    var count: Int
    var lastAt: Int

    static func today(_ now: Date = Date()) -> String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"; f.timeZone = .current
        return f.string(from: now)
    }
    static func load() -> DoneCounter {
        let d = UserDefaults.standard
        return DoneCounter(day: d.string(forKey: "doneDay") ?? today(), count: d.integer(forKey: "doneCount"), lastAt: d.integer(forKey: "doneLastAt"))
    }
    func save() {
        let d = UserDefaults.standard
        d.set(day, forKey: "doneDay"); d.set(count, forKey: "doneCount"); d.set(lastAt, forKey: "doneLastAt")
    }
    /// Call every tick. Counts each new "done" once, and starts again at 0 each day.
    mutating func observe(state: String, at: Int, now: Date = Date()) -> Bool {
        var changed = false
        let t = DoneCounter.today(now)
        if t != day { day = t; count = 0; changed = true }
        if state == "done" && at > lastAt {
            lastAt = at
            if DoneCounter.today(Date(timeIntervalSince1970: TimeInterval(at))) == day { count += 1 }
            changed = true
        }
        return changed
    }
}
