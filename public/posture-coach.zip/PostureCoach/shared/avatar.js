// Your cartoon. Posture Coach draws it from these choices (no image is stored anywhere).
// Change a value, then run `bash macos/build.sh` again. Open preview.html to see every pose.
//
// name          shown on the home card, up to 14 letters
// skin          any colour as #RRGGBB
// hair.style    curly | short | buzz | long | wavy | bun | ponytail | bald
// hair.color    #RRGGBB
// beard.style   none | stubble | full | moustache
// beard.color   #RRGGBB (usually the hair colour, or grey)
// glasses       none | round | square
// shirt.style   tee | collar | hoodie
// shirt.color   #RRGGBB
// pants, shoes  #RRGGBB
window.AVATAR = {
  name: "Coach",
  skin: "#E0AC85",
  hair: { style: "short", color: "#3B2A22" },
  beard: { style: "none", color: "#3B2A22" },
  glasses: "none",
  shirt: { style: "tee", color: "#2F5D8A" },
  pants: "#36414F",
  shoes: "#241F19",
};
