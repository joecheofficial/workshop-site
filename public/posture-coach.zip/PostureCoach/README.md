# Posture Coach

A little cartoon of you that lives in your Mac's menu bar and gets you moving. Every 20 minutes it pops up at
the top right with a quick desk stretch: chin tucks, a doorway chest stretch, a lap around the room. Press
Start and it times your reps. Snooze it and it's back in five minutes.

**Your cartoon.** The coach is drawn from a few choices in `shared/avatar.js` (skin, hair, beard, glasses,
clothes, name). Give Claude Code a photo of yourself, or answer five questions, and it fills them in for you.
Open `shared/preview.html` to see your cartoon in every pose. No image is stored in the app.

**Claude Code mode.** If you build with Claude Code, your coach watches for it. When Claude starts working on
something and your next stretch is due within 8 minutes anyway, it gives it to you right then, while you'd
only be waiting. If Claude finishes mid-stretch, the card tells you, so you finish the stretch first and then
go and look.

![A stretch card while Claude works](docs/card-claude.png)

- **Never steals your typing.** The card shows up without taking the keyboard. Ctrl+Option+P (⌃⌥P) hands it
  over, and pressing it again gives the keyboard back.
- **Keyboard all the way.** Enter starts, D finishes, S snoozes, X skips, M tucks it into a small pill.
- **Knows when you're away.** Lock the screen or close the lid for 3+ minutes and the clock starts over.
- **In a meeting?** One switch holds any stretch until you're out.
- **Twelve moves** for neck, back, chest, wrists, hips, legs and eyes. Switch off the ones you don't want.

Mac only for now (macOS 13 or newer).

## Install

Works only in **Claude Code** on a Mac (paid Claude plan, Pro or higher). Two ways, both in `START-HERE-PROMPT.md`:

- **Way 1, no Terminal:** in the Claude desktop app's Code tab, drag in `posture-coach.zip` and ask Claude to follow `START-HERE-PROMPT.md`.
- **Way 2, Terminal:** type `claude` and paste the prompt from `START-HERE-PROMPT.md`.

By hand, in Terminal:

```bash
xcode-select --install          # once, if you don't have Apple's free command line tools yet
bash macos/build.sh             # builds Posture Coach, puts it in Applications and starts it
bash claude-code/install-hooks.sh   # optional: turns on Claude Code mode
```

Because you build it on your own Mac, macOS opens it without the "unidentified developer" warning.

## Claude Code mode, exactly

`claude-code/install-hooks.sh` adds two hooks to `~/.claude/settings.json` and keeps everything else in that
file (it saves a copy first, as `settings.json.before-posture-coach`):

- when you send Claude a prompt, it writes `{"state":"working"}` to
  `~/Library/Application Support/PostureCoach/claude.json`
- when Claude finishes, it writes `{"state":"idle"}`

That one small file is all Posture Coach reads. Nothing is sent anywhere. Switch it off any time with
**Stretch while Claude Code works** in the menu, or remove the hooks with
`bash claude-code/install-hooks.sh --remove`.

## Change it

- Your cartoon: `shared/avatar.js` (options listed at the top; preview with `shared/preview.html`)
- Moves and your coach's lines: `shared/moves.json`
- The drawing and the card: `shared/card.html`
- The timer and the logic: `macos/Sources/Core.swift`

Then run `bash macos/build.sh` again.

## Tests

```bash
cd macos/Tests
swiftc -O -parse-as-library ../Sources/Core.swift CoreTests.swift -o core-tests && ./core-tests ../../shared
```

68 checks over a simulated working day, including Claude Code mode.

## Credits

Posture Coach is built on **Ravi the Ravioli** by Yahia ElSaman
(github.com/yahiaelsamman/ravi-posture, MIT), which was itself inspired by Anthropic's "Tony the Rigatoni"
reel. The timer, the card and the stretches are his work; the build-your-own cartoon, Claude Code mode, the
lines and the rebrand are ours. See `LICENSE`.
