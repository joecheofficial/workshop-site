# Posture Coach

A little cartoon of you lives at the top of your Mac screen. Every 20 minutes it pops up and shows you a quick stretch. Like tucking your chin, or a walk around the room. Press Start and it counts for you. Press Snooze and it comes back in 5 minutes.

**Your cartoon looks like you.** Give Claude Code a photo of yourself. Or answer 5 quick questions. Claude picks your hair, skin, beard, glasses, clothes and name. Open `shared/preview.html` to see your cartoon. Your photo is not saved in the app.

**Stretch while Claude works.** If you use Claude Code, your coach can tell when Claude is busy. If a stretch is due soon anyway, you get it right then, while you wait. If Claude finishes while you stretch, the card tells you.

![A stretch card while Claude works](docs/card-claude.png)

- **It never takes over your typing.** Press Control + Option + P to use the card with your keyboard.
- **Keys:** Enter starts. D says done. S snoozes. X skips. M makes it small.
- **It knows when you walk away.** Lock your Mac for 3 minutes and the timer starts again.
- **In a meeting?** Flip one switch and it waits until you're done.
- **12 stretches** for your neck, back, chest, wrists, hips, legs and eyes. Turn off the ones you don't want.

Mac only (macOS 13 or newer).

## How to install

It only works in **Claude Code** on a Mac. You need a paid Claude plan (Pro or more). Both ways are in `START-HERE-PROMPT.md`:

- **Way 1, easy:** open the Claude app, click Code, drag in this folder, type "set it up" and press Enter.
- **Way 2, Terminal:** type `claude`, then paste the prompt from `START-HERE-PROMPT.md`.

Doing it by hand in Terminal:

```bash
xcode-select --install          # once, if you don't have Apple's free tools yet
bash macos/build.sh             # builds Posture Coach, puts it in Applications and opens it
bash claude-code/install-hooks.sh   # optional: stretch while Claude works
```

Because you build it on your own Mac, your Mac opens it without a scary warning.

## Claude Code mode, exactly

`claude-code/install-hooks.sh` adds two hooks to `~/.claude/settings.json` and keeps everything else in that
file (it saves a copy first, as `settings.json.before-posture-coach`):

- when you send Claude a prompt, it writes `{"state":"working"}` to
  `~/Library/Application Support/PostureCoach/claude.json`
- when Claude finishes, it writes `{"state":"idle"}`

That one small file is all Posture Coach reads. Nothing is sent anywhere. Switch it off any time with
**Stretch while Claude Code works** in the menu, or remove the hooks with
`bash claude-code/install-hooks.sh --remove`.

## Change it

- Your cartoon: `shared/avatar.js` (options listed at the top; preview with `shared/preview.html`)
- Moves and your coach's lines: `shared/moves.json`
- The drawing and the card: `shared/card.html`
- The timer and the logic: `macos/Sources/Core.swift`

Then run `bash macos/build.sh` again.

## Tests

```bash
cd macos/Tests
swiftc -O -parse-as-library ../Sources/Core.swift CoreTests.swift -o core-tests && ./core-tests ../../shared
```

68 checks over a simulated working day, including Claude Code mode.

## Credits

Posture Coach is built on **Ravi the Ravioli** by Yahia ElSaman
(github.com/yahiaelsamman/ravi-posture, MIT), which was itself inspired by Anthropic's "Tony the Rigatoni"
reel. The timer, the card and the stretches are his work; the build-your-own cartoon, Claude Code mode, the
lines and the rebrand are ours. See `LICENSE`.
