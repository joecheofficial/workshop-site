#!/bin/bash
# Adds Posture Coach's two hooks to Claude Code (~/.claude/settings.json), keeping everything already there.
#   bash claude-code/install-hooks.sh            add the hooks (safe to run twice)
#   bash claude-code/install-hooks.sh --remove   take them out again
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Library/Application Support/PostureCoach"
mkdir -p "$DEST"
cp "$HERE/posture-hook.sh" "$DEST/posture-hook.sh"
chmod +x "$DEST/posture-hook.sh"
SETTINGS="$HOME/.claude/settings.json"
mkdir -p "$HOME/.claude"
[ -f "$SETTINGS" ] && cp "$SETTINGS" "$SETTINGS.before-posture-coach"
/usr/bin/python3 - "$SETTINGS" "$DEST/posture-hook.sh" "${1:-}" <<'PY'
import json, os, sys
path, hook, mode = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    with open(path) as f: data = json.load(f)
except FileNotFoundError:
    data = {}
hooks = data.setdefault("hooks", {})
def ours(group):
    return any("PostureCoach/posture-hook.sh" in h.get("command", "") for h in group.get("hooks", []))
for event, state in (("UserPromptSubmit", "working"), ("Stop", "idle")):
    groups = [g for g in hooks.get(event, []) if not ours(g)]
    if mode != "--remove":
        groups.append({"hooks": [{"type": "command", "command": f'"{hook}" {state}', "timeout": 5}]})
    if groups: hooks[event] = groups
    else: hooks.pop(event, None)
if not hooks: data.pop("hooks", None)
tmp = path + ".tmp"
with open(tmp, "w") as f: json.dump(data, f, indent=2); f.write("\n")
os.replace(tmp, path)
print("Removed Posture Coach's Claude Code hooks." if mode == "--remove" else "Claude Code mode is on: your coach will time stretches around Claude's work.")
PY
