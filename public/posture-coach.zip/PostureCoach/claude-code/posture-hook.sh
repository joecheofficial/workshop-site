#!/bin/sh
# Claude Code calls this when you send a prompt ("working") and when Claude finishes ("idle").
# Posture Coach reads the file and, if a stretch is close anyway, gives it to you while Claude works.
# It writes one tiny file on your Mac. Nothing leaves your computer.
dir="$HOME/Library/Application Support/PostureCoach"
mkdir -p "$dir"
printf '{"state":"%s","at":%s}\n' "${1:-idle}" "$(date +%s)" > "$dir/claude.json.tmp" && mv "$dir/claude.json.tmp" "$dir/claude.json"
exit 0
