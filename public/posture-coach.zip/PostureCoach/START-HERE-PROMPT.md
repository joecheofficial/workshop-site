# Make your own Posture Coach (a cartoon of you)

**You need two things:**
- A Mac.
- Claude Code. It comes with the Claude app. You need a paid Claude plan (Pro or more).

It does not work in normal Claude chat. It does not work in ChatGPT.

## Way 1: the easy way

1. Get the Claude app for Mac at claude.com/download. Log in.
2. Click **Code** at the top.
3. Drag the **PostureCoach** folder into the chat. (The zip works too.)
4. Type **set it up** and press Enter.

Claude does the rest.

## Way 2: the Terminal way

1. Open Terminal.
2. Type `claude` and press Enter.
3. Copy everything in the box below, paste it in, and press Enter.

Does Terminal say `command not found: claude`? Then Claude Code is not set up yet. Use Way 1. Or paste this into Terminal, press Enter, then open a new Terminal window: `curl -fsSL https://claude.ai/install.sh | bash`

```
Build me my own Posture Coach: a free Mac app where a cartoon of me pops up every 20 minutes with a quick desk stretch. Go step by step. Talk to me in very simple words, like I am 5 years old. No tech words. Tell me what you are doing and why.

1. Check this is a Mac on macOS 13 or newer (sw_vers). If it isn't, stop and tell me Posture Coach only works on a Mac for now.

2. Check Apple's free command line tools are installed (xcode-select -p). If they aren't, run xcode-select --install, tell me to click Install in the window that pops up, and wait until I say it's done.

3. Download https://workshop.mastermindshq.business/posture-coach.zip and unzip it into a folder called PostureCoach in my home folder.

4. Make my cartoon. Ask me: "Do you want the coach to look like you? Drag a photo of yourself into this window and press Enter. Or type 'describe' and I will ask you 5 quick questions."
   - With a photo: look at it and pick my look using ONLY the options listed at the top of shared/avatar.js: skin colour, hair style and hair colour, beard, glasses, the colour of clothes I'd usually wear, and shirt style. Then ask me what name the coach should show (my first name is fine).
   - With 'describe': ask me one at a time about my hair (style and colour), skin tone, beard or no beard, glasses or not, and my favourite colour to wear. Then the name.
   - Write my choices into shared/avatar.js. Keep the comment block at the top, use only the listed options, and colours as #RRGGBB. Don't copy or save my photo anywhere.
   - Run: open shared/preview.html (it shows my cartoon in every stretch pose). Ask me if I like it. If I want changes, update avatar.js and open the preview again, until I say it looks good.

5. Before you build it, read README.md, macos/build.sh and claude-code/install-hooks.sh, and tell me in one or two simple sentences what they do. Then run: bash macos/build.sh
   If the build fails, read the error, fix only what's needed to make it build, and run it again. Don't change what the app does.

6. Ask me: "Do you want a stretch while Claude is busy working for you? You only get one if a stretch is due soon anyway." If I say yes, run: bash claude-code/install-hooks.sh

7. At the end, tell me in simple words:
   - Look at the top right of your screen. Your cartoon's little face is there. Click it, then click "Stretch now" to try it.
   - Press Control + Option + P to use the card with your keyboard. Enter starts a stretch. S snoozes. X skips.
   - Want it every day? Click the little face and turn on "Open at login".
   - Want to change your cartoon? Ask Claude to change shared/avatar.js in the PostureCoach folder, then run bash macos/build.sh again.
   - Want to remove it? Quit it from the little face menu. Delete "Posture Coach" from Applications. If you said yes to the Claude stretch, also run bash claude-code/install-hooks.sh --remove

Only touch the PostureCoach folder, the app in Applications, and (if I said yes) the hooks in ~/.claude/settings.json. The app never sends anything off my Mac.
```

That's it. Your own Claude makes your cartoon and builds the app on your Mac. If something goes wrong, Claude reads the error and fixes it.
