#!/bin/bash
# Builds "Posture Coach.app" from macos/Sources and the shared card, installs it in Applications and starts it.
#   bash macos/build.sh             build, install, start
#   bash macos/build.sh --no-install  just build (into macos/build/Posture Coach.app); used by GitHub Actions
set -euo pipefail
cd "$(dirname "$0")"
SHARED="../shared"
INSTALL=1
[ "${1:-}" = "--no-install" ] && INSTALL=0

if ! command -v swiftc >/dev/null 2>&1; then
  echo "Swift isn't installed yet. Run this, accept the prompt, then run build.sh again:"
  echo "  xcode-select --install"
  exit 1
fi

echo "Building Posture Coach..."
rm -rf build
APP="build/Posture Coach.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/shared"

# a universal app: runs natively on Apple silicon and Intel Macs
for arch in arm64 x86_64; do
  swiftc -O -swift-version 5 -parse-as-library \
    -target "$arch-apple-macos13.0" \
    Sources/Core.swift Sources/App.swift \
    -o "build/PostureCoach-$arch" \
    -framework AppKit -framework WebKit -framework ServiceManagement -framework Carbon
done
lipo -create build/PostureCoach-arm64 build/PostureCoach-x86_64 -output "$APP/Contents/MacOS/PostureCoach"
rm build/PostureCoach-arm64 build/PostureCoach-x86_64

cp Info.plist "$APP/Contents/"
cp -R "$SHARED/card.html" "$SHARED/avatar.js" "$SHARED/moves.json" "$SHARED/fonts" "$APP/Contents/Resources/shared/"
iconutil -c icns Resources/AppIcon.iconset -o "$APP/Contents/Resources/AppIcon.icns"
codesign --force --sign - "$APP" >/dev/null 2>&1 || true

if [ "$INSTALL" = 0 ]; then
  echo "Built $(pwd)/$APP"
  exit 0
fi

osascript -e 'quit app "Posture Coach"' >/dev/null 2>&1 || pkill -x PostureCoach 2>/dev/null || true
sleep 0.8

DEST="/Applications"
if [ ! -w "$DEST" ]; then DEST="$HOME/Applications"; mkdir -p "$DEST"; fi
rm -rf "$DEST/Posture Coach.app"
cp -R "$APP" "$DEST/"
open "$DEST/Posture Coach.app"

echo ""
echo "Done. Posture Coach is running: look for the little face in your menu bar."
echo "Installed at $DEST/Posture Coach.app"
