# Posture Coach for macOS

A menu-bar app (Swift, AppKit, WKWebView) for macOS 13 or later, built on Ravi the Ravioli by Yahia ElSaman.

- `Sources/Core.swift`: the clock, move picking, tally, Claude Code mode and what the card shows. Foundation only.
- `Sources/App.swift`: menu-bar item, the floating panel holding `shared/card.html`, ⌃⌥P, login item,
  sleep/lock/wake, dark mode, system sounds.
- `build.sh`: builds a universal `Posture Coach.app` (Apple silicon and Intel), copies it to Applications and
  starts it. `--no-install` only builds it into `macos/build/`.

Settings and the tally live in `~/Library/Application Support/PostureCoach/state.json`; Claude Code mode reads
`claude.json` in the same folder.
